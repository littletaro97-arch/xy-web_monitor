# xy-monitor 文档说明

为了避免 Windows 解压时遇到历史中文文件名兼容问题，本包只保留必要说明文档，旧版本长中文文件名文档未放入压缩包。

主要查看：
- 根目录 `README.md`
- 根目录 `CHANGELOG.md`
- `docs/v0.6.7_update_notes.md`
