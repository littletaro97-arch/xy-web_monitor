# -*- coding: utf-8 -*-
"""xy-monitor local web dashboard v0.7.4.

Local-only web UI for links.txt, state.json, history.jsonl and runtime_status.json.
In v0.6.3 the dashboard is the single entry point: it starts and controls the long-running monitor process.
It binds to 127.0.0.1 only and does not change Windows system settings.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime
from html import escape
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urlparse

import link_manager

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
CONFIG_FILE = ROOT / "config.json"
DATA_DIR = ROOT / "data"
LOGS_DIR = ROOT / "logs"
STATE_FILE = DATA_DIR / "state.json"
HISTORY_FILE = DATA_DIR / "history.jsonl"
RUN_META_FILE = DATA_DIR / "run_meta.json"
RUNTIME_STATUS_FILE = DATA_DIR / "runtime_status.json"
MONITOR_LOCK_FILE = DATA_DIR / "monitor.lock"
CONTROL_FILE = DATA_DIR / "monitor_control.json"
LAST_ROUND_DEBUG = LOGS_DIR / "last_round_debug.json"
WEB_RUN_LOG = LOGS_DIR / "web_background_monitor.log"
HOST = "127.0.0.1"
PORT = 8765
PROGRAM_VERSION = "v0.7.4"
MONITOR_LOCK_STALE_SECONDS = 15 * 60
RUNTIME_STALE_SECONDS = 20


def configure_console_utf8() -> None:
    """Prevent Windows GBK console/log redirection from crashing on Unicode text."""
    import os
    import sys
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


configure_console_utf8()

RUN_LOCK = threading.Lock()
RUNNING = False
LAST_RUN_MESSAGE = ""
LAST_RUN_STARTED_AT = ""
LAST_RUN_FINISHED_AT = ""
CURRENT_PROC: subprocess.Popen[str] | None = None
LAST_PAGE_HEARTBEAT_TS = time.time()
PAGE_CLOSE_GRACE_UNTIL = 0.0
SERVER_SHUTTING_DOWN = False
CLIENT_HEARTBEAT_TIMEOUT_SECONDS = 45
CLIENT_CLOSE_GRACE_SECONDS = 8

STATUS_LABELS = {
    "NORMAL": "可购买", "SOLD": "已售", "REMOVED": "下架/失效",
    "LOGIN_REQUIRED": "需要登录", "VERIFY_REQUIRED": "需要验证",
    "LOAD_FAILED": "加载失败", "UNKNOWN": "未知", "NETWORK_ERROR": "网络异常",
}
EVENT_LABELS = {
    "PRICE_DOWN": "降价", "PRICE_UP": "涨价", "TITLE_CHANGED": "标题变化",
    "SOLD": "已售", "REMOVED": "下架", "RECOVERED": "恢复可购买",
    "STATUS_CHANGED": "状态变化", "LOGIN_REQUIRED": "需要登录",
    "VERIFY_REQUIRED": "需要验证", "NOT_BUYABLE": "不可购买/异常", "NETWORK_ERROR": "网络异常",
}


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_dirs() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)
    link_manager.ensure_files()


def read_json(path: Path, default: Any) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def read_state() -> dict[str, Any]:
    data = read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def read_config() -> dict[str, Any]:
    data = read_json(CONFIG_FILE, {})
    return data if isinstance(data, dict) else {}


def write_config(config: dict[str, Any]) -> None:
    CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


NOTIFICATION_SWITCHES = [
    ("notification_enabled", "通知总开关", "关闭后所有 Windows 通知和兜底弹窗都不会出现。", True),
    ("notify_status_change", "变化通知总开关", "商品涨价、降价、已售、下架、恢复、登录/验证、网络异常等变化通知的总开关。", True),
    ("notify_price_up", "涨价通知", "价格高于上一次可信价格时提醒。", True),
    ("notify_price_down", "降价通知", "价格低于上一次可信价格时提醒。", True),
    ("notify_title_change", "标题变化通知", "商品标题与上一次可信标题不一致时提醒。", True),
    ("notify_sold", "已售通知", "商品从可购买变成已售时提醒。", True),
    ("notify_removed", "下架 / 恢复通知", "商品下架、失效或恢复正常时提醒。", True),
    ("notify_login_required", "登录失效通知", "检测到需要重新登录时提醒。", True),
    ("notify_verify_required", "安全验证通知", "检测到需要手动验证时提醒。", True),
    ("notify_network_errors", "断网 / 网络异常通知", "DNS 失败、断网、网络切换等情况会立刻提醒，不再默默当作正常检测。", True),
    ("notify_failures", "连续失败通知", "非网络类连续加载失败达到阈值后提醒。", True),
    ("notify_not_buyable", "不可购买 / 异常通知", "识别不到可购买证据时提醒；默认不会把普通断网当成商品异常。", True),
    ("notify_round_complete", "每轮检测完成整体报告", "每一轮全部商品检测结束后弹出汇总报告。", False),
    ("notification_popup_fallback", "重要通知桌面弹窗兜底", "涨价、降价、下架、断网等重要变化除 Toast 外，再弹出一个可见窗口，避免系统 Toast 被静默吞掉。", True),
    ("notification_add_open_button", "通知里显示打开商品按钮", "Toast 通知支持时，附带“打开商品页面”按钮。", True),
]

IMPORTANT_NOTIFICATION_KEYS = {
    "notification_enabled",
    "notify_status_change",
    "notify_price_up",
    "notify_price_down",
    "notify_network_errors",
    "notification_popup_fallback",
}



def notification_settings_payload() -> dict[str, Any]:
    config = read_config()
    master_enabled = bool(config.get("notification_enabled", True))
    payload: dict[str, Any] = {}
    for key, _title, _desc, default in NOTIFICATION_SWITCHES:
        if key == "notification_enabled":
            payload[key] = master_enabled
        elif not master_enabled:
            # 总开关关闭时，所有子开关在界面和保存逻辑上都视为关闭。
            payload[key] = False
        else:
            payload[key] = bool(config.get(key, default))
    return payload


def switch_card_html(
    key: str,
    title: str,
    desc: str,
    checked: bool,
    disabled: bool = False,
    extra_class: str = "",
    is_notification_child: bool = False,
) -> str:
    checked_attr = "checked" if checked else ""
    disabled_attr = "disabled" if disabled else ""
    data_child_attr = ' data-notification-child="1"' if is_notification_child else ""
    switch_id = f"{key}_switch"
    state = "已开启" if checked else "已关闭"
    classes = "switch-card"
    if extra_class:
        classes += " " + extra_class
    if disabled:
        classes += " switch-card-disabled"
    return (
        f'<label class="{escape(classes, quote=True)}" for="{escape(switch_id, quote=True)}">'
        f'<span class="switch-text"><b>{escape(title)}</b>'
        f'<small>{escape(desc)}</small>'
        f'<em>{state}</em></span>'
        f'<input id="{escape(switch_id, quote=True)}" type="checkbox" name="{escape(key, quote=True)}" value="1" {checked_attr} {disabled_attr}{data_child_attr}>'
        '<span class="switch-ui" aria-hidden="true"></span>'
        '</label>'
    )


def notification_settings_html() -> str:
    settings = notification_settings_payload()
    master_on = bool(settings.get("notification_enabled", True))
    primary_cards: list[str] = []
    advanced_cards: list[str] = []
    for key, title, desc, default in NOTIFICATION_SWITCHES:
        is_child = key != "notification_enabled"
        checked = bool(settings.get(key, default)) and (master_on or not is_child)
        disabled = is_child and not master_on
        card = switch_card_html(
            key,
            title,
            desc,
            checked,
            disabled=disabled,
            extra_class=("notification-master-card" if key == "notification_enabled" else "notification-child-card"),
            is_notification_child=is_child,
        )
        if key in IMPORTANT_NOTIFICATION_KEYS:
            primary_cards.append(card)
        else:
            advanced_cards.append(card)
    return (
        '<div class="settings-panel notification-panel" id="notification-panel">'
        '<div class="settings-panel-head"><span class="settings-kicker">通知</span><h3>提醒策略</h3><p>常用通知保留在外层；不常改的策略收进“更多通知策略”。所有更改仍然需要点击保存。</p></div>'
        '<form method="post" action="/notification_settings">'
        f'<div class="settings-grid notification-grid notification-main-grid">{"".join(primary_cards)}</div>'
        '<details class="notification-advanced"><summary><span>展开更多通知策略</span><small>标题变化、已售/下架、登录验证、连续失败、整体报告等</small></summary>'
        f'<div class="settings-grid notification-grid notification-advanced-grid">{"".join(advanced_cards)}</div>'
        '</details>'
        '<p class="hint">关闭“通知总开关”后，其余通知选项会立即变灰、不可更改，并自动全部关闭；重新开启总开关后，需要手动选择需要的子通知。</p>'
        '<p><button class="primary-action">保存通知设置</button></p>'
        '</form></div>'
    )


def browser_mode_settings_payload() -> dict[str, Any]:
    config = read_config()
    real_browser = not bool(config.get("headless", True))
    return {
        "real_browser": real_browser,
        "headless": not real_browser,
    }


def browser_mode_settings_html() -> str:
    settings = browser_mode_settings_payload()
    checked = "checked" if settings["real_browser"] else ""
    state = "已开启：检测时显示真实浏览器" if settings["real_browser"] else "已关闭：后台静默检测"
    return (
        '<div class="settings-panel">'
        '<div class="settings-panel-head"><span class="settings-kicker">显示</span><h3>检测窗口</h3><p>黑色命令行窗口默认隐藏；这里只控制是否显示真实浏览器。</p></div>'
        '<form method="post" action="/browser_mode_settings">'
        '<div class="settings-grid one">'
        '<label class="switch-card">'
        '<span class="switch-text"><b>真实浏览器检测</b>'
        '<small>开启后，检测闲鱼商品时会显示 Chromium 真实网页，方便处理登录、验证码和页面异常；关闭后使用“隐藏真实浏览器窗口”的静默模式，避免无头模式导致全部异常。</small>'
        f'<em>{state}</em></span>'
        f'<input type="checkbox" name="real_browser" value="1" {checked}>'
        '<span class="switch-ui" aria-hidden="true"></span>'
        '</label>'
        '</div>'
        '<p class="hint">切换开关后需要点击“保存浏览器显示设置”才会写入 config.json。若后台监控正在运行，新设置会在下一轮检测前生效。</p>'
        '<p><button class="primary-action">保存浏览器显示设置</button></p>'
        '</form></div>'
    )


def read_runtime_status() -> dict[str, Any]:
    data = read_json(RUNTIME_STATUS_FILE, {})
    return data if isinstance(data, dict) else {}


def read_lock_info() -> dict[str, Any]:
    data = read_json(MONITOR_LOCK_FILE, {})
    return data if isinstance(data, dict) else {}


def lock_age_seconds() -> float | None:
    try:
        return time.time() - MONITOR_LOCK_FILE.stat().st_mtime
    except Exception:
        return None


def lock_is_fresh() -> bool:
    age = lock_age_seconds()
    return age is not None and age <= MONITOR_LOCK_STALE_SECONDS


def runtime_age_seconds(runtime: dict[str, Any] | None = None) -> float | None:
    runtime = runtime if runtime is not None else read_runtime_status()
    try:
        ts = float(runtime.get("updated_ts") or 0)
    except Exception:
        ts = 0.0
    if ts <= 0:
        return None
    return max(0.0, time.time() - ts)


def process_exists(pid: Any) -> bool | None:
    """Return whether a PID is alive.

    None means the PID was missing/invalid or the platform check failed.  The
    dashboard uses this to distinguish a real running monitor from stale files
    left behind after closing the command window during a countdown.
    """
    try:
        pid_int = int(pid)
    except Exception:
        return None
    if pid_int <= 0:
        return None
    if pid_int == os.getpid():
        return True

    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            kernel32 = ctypes.windll.kernel32
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            SYNCHRONIZE = 0x00100000
            WAIT_TIMEOUT = 0x00000102
            WAIT_OBJECT_0 = 0x00000000
            WAIT_FAILED = 0xFFFFFFFF

            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid_int)
            if not handle:
                # ERROR_ACCESS_DENIED normally means a process exists but we do
                # not have permission to query it.
                return kernel32.GetLastError() == 5
            try:
                rc = kernel32.WaitForSingleObject(handle, 0)
                if rc == WAIT_TIMEOUT:
                    return True
                if rc == WAIT_OBJECT_0:
                    return False
                if rc == WAIT_FAILED:
                    return None
                return None
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return None

    try:
        os.kill(pid_int, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return None


def cleanup_stale_monitor_artifacts(reason: str = "startup") -> list[str]:
    """Clear stale lock/runtime files from an abruptly closed previous run.

    v0.6.0 used the lock file modification time as the only startup guard.  If
    the user closed the command window while monitor.py was in ROUND_DELAY, the
    lock and runtime countdown could remain fresh enough to block the next
    dashboard startup.  This function validates the recorded PID before trusting
    those files.
    """
    messages: list[str] = []
    runtime = read_runtime_status()
    runtime_age = runtime_age_seconds(runtime)
    runtime_running = bool(runtime.get("running"))
    runtime_pid = runtime.get("pid")

    lock_exists = MONITOR_LOCK_FILE.exists()
    lock = read_lock_info() if lock_exists else {}
    lock_pid = lock.get("pid")
    lock_age = lock_age_seconds()

    runtime_pid_alive = process_exists(runtime_pid)
    lock_pid_alive = process_exists(lock_pid)

    should_clear_lock = False
    if lock_exists:
        if lock_pid_alive is False:
            should_clear_lock = True
            messages.append(f"发现上次残留 monitor.lock，PID {lock_pid} 已不存在，已清理。")
        elif lock_pid_alive is None and runtime_running and runtime_age is not None and runtime_age > RUNTIME_STALE_SECONDS:
            should_clear_lock = True
            messages.append("发现上次残留 monitor.lock，运行状态已长时间未更新，已清理。")
        elif lock_age is not None and lock_age > MONITOR_LOCK_STALE_SECONDS:
            should_clear_lock = True
            messages.append("发现过期 monitor.lock，已清理。")

    if should_clear_lock:
        try:
            MONITOR_LOCK_FILE.unlink(missing_ok=True)
        except Exception as exc:
            messages.append(f"清理 monitor.lock 失败：{exc}")

    stale_runtime = False
    if runtime_running:
        if runtime_pid_alive is False:
            stale_runtime = True
        elif runtime_age is not None and runtime_age > RUNTIME_STALE_SECONDS:
            # If there is a live lock owner, keep trusting the real monitor.
            stale_runtime = not (lock_pid_alive is True)

    if stale_runtime:
        try:
            write_runtime_status_from_dashboard(
                running=False,
                mode=runtime.get("mode") or "loop",
                phase="IDLE",
                phase_label="空闲",
                last_message=f"检测到上次监控可能在等待期间异常退出，已清理旧倒计时并准备重新启动后台监控（{reason}）。",
                exit_code=0,
                delay_seconds=0,
                delay_remaining_seconds=0,
                delay_until_at="",
                delay_until_ts=0,
                next_round_remaining_seconds=0,
                next_round_at="",
                next_round_at_ts=0,
                manual_request_pending=False,
                finished_at=now_str(),
                recovered_from_stale_runtime=True,
                recovered_at=now_str(),
            )
            messages.append("已清理上次残留的 runtime_status 等待状态。")
        except Exception as exc:
            messages.append(f"清理 runtime_status 失败：{exc}")

    return messages


def format_elapsed(seconds: float | None) -> str:
    if seconds is None:
        return "-"
    seconds = max(0, int(round(seconds)))
    if seconds < 60:
        return f"{seconds} 秒前"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} 分钟前"
    hours = minutes // 60
    if hours < 24:
        return f"{hours} 小时前"
    days = hours // 24
    return f"{days} 天前"


def format_duration(seconds: float | int | None) -> str:
    """Human-friendly countdown text for the dashboard."""
    if seconds is None:
        return "-"
    seconds = max(0, int(round(float(seconds))))
    if seconds <= 0:
        return "即将开始"
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    parts: list[str] = []
    if days:
        parts.append(f"{days}天")
    if hours:
        parts.append(f"{hours}小时")
    if minutes:
        parts.append(f"{minutes}分")
    if secs or not parts:
        parts.append(f"{secs}秒")
    return "".join(parts)


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def write_runtime_status_from_dashboard(**fields: Any) -> None:
    runtime = read_runtime_status()
    runtime.update(fields)
    runtime["updated_at"] = now_str()
    runtime["updated_ts"] = time.time()
    runtime.setdefault("program_version", PROGRAM_VERSION)
    write_json_atomic(RUNTIME_STATUS_FILE, runtime)


def clear_monitor_lock_if_owned(pid: int | None) -> None:
    if not pid or not MONITOR_LOCK_FILE.exists():
        return
    lock = read_lock_info()
    if int(lock.get("pid") or -1) == int(pid):
        try:
            MONITOR_LOCK_FILE.unlink()
        except Exception:
            pass


def request_safe_stop_from_dashboard() -> None:
    """Ask monitor.py to stop at the next safe checkpoint instead of killing it immediately."""
    control = read_json(CONTROL_FILE, {})
    if not isinstance(control, dict):
        control = {}
    request_ts = time.time()
    control.update({
        "stop_requested": True,
        "stop_request_id": str(int(request_ts * 1000)),
        "stop_requested_at": now_str(),
        "stop_requested_ts": request_ts,
        "stop_source": "dashboard",
        "stop_reason": "dashboard_shutdown_or_stop_button",
    })
    write_json_atomic(CONTROL_FILE, control)


def stop_current_monitor_from_dashboard() -> str:
    global CURRENT_PROC, RUNNING, LAST_RUN_MESSAGE, LAST_RUN_FINISHED_AT
    with RUN_LOCK:
        proc = CURRENT_PROC
    if proc is None or proc.poll() is not None:
        with RUN_LOCK:
            RUNNING = False
            CURRENT_PROC = None
        return "当前没有由网页面板启动的后台监控进程。"

    pid = proc.pid
    forced = False
    return_code: int | None = None
    try:
        request_safe_stop_from_dashboard()
        try:
            return_code = proc.wait(timeout=90)
            message = "已安全停止网页面板管理的后台监控。"
        except subprocess.TimeoutExpired:
            forced = True
            proc.terminate()
            try:
                return_code = proc.wait(timeout=8)
                message = "安全停止等待超时，已终止后台监控。"
            except subprocess.TimeoutExpired:
                proc.kill()
                return_code = proc.wait(timeout=5)
                message = "后台监控未及时退出，已强制停止。"
    except Exception as exc:
        return f"停止失败：{exc}"

    clear_monitor_lock_if_owned(pid)
    try:
        write_runtime_status_from_dashboard(
            running=False,
            phase="STOPPED_BY_USER",
            phase_label="用户已停止",
            last_message=message,
            exit_code=130 if forced else (return_code if return_code is not None else 0),
            pid=pid,
            delay_seconds=0,
            delay_remaining_seconds=0,
            next_round_remaining_seconds=0,
            finished_at=now_str(),
        )
    except Exception:
        pass
    with RUN_LOCK:
        CURRENT_PROC = None
        RUNNING = False
        LAST_RUN_MESSAGE = message
        LAST_RUN_FINISHED_AT = now_str()
    return message


def web_process_running() -> bool:
    with RUN_LOCK:
        proc = CURRENT_PROC
        return bool(proc is not None and proc.poll() is None)


def record_page_heartbeat() -> None:
    global LAST_PAGE_HEARTBEAT_TS, PAGE_CLOSE_GRACE_UNTIL
    LAST_PAGE_HEARTBEAT_TS = time.time()
    PAGE_CLOSE_GRACE_UNTIL = 0.0


def mark_page_closing() -> None:
    global PAGE_CLOSE_GRACE_UNTIL
    PAGE_CLOSE_GRACE_UNTIL = time.time() + CLIENT_CLOSE_GRACE_SECONDS


def dashboard_client_watchdog(server: ThreadingHTTPServer) -> None:
    """Deprecated no-op watchdog.

    v0.7.2 used browser-page heartbeats to close the dashboard automatically
    when the tab seemed gone. In real use, Chromium/Edge can pause background
    timers when the tab is hidden, minimized, memory-saved, or the computer
    wakes from sleep. That made the command window close by itself and left
    the page frozen. v0.7.4 keeps heartbeat data for display only; stopping is
    now explicit via the dashboard close button, stop button, or command window.
    """
    while not SERVER_SHUTTING_DOWN:
        time.sleep(60)


def start_background_monitor(reason: str = "dashboard") -> str:
    """Start monitor.py in long-running loop mode if the dashboard does not already own one."""
    global RUNNING, LAST_RUN_MESSAGE, LAST_RUN_STARTED_AT, LAST_RUN_FINISHED_AT, CURRENT_PROC
    with RUN_LOCK:
        if CURRENT_PROC is not None and CURRENT_PROC.poll() is None:
            RUNNING = True
            return "后台长期监控已在运行。"
        CURRENT_PROC = None
        RUNNING = False

    cleanup_messages = cleanup_stale_monitor_artifacts(reason)

    # If another fresh monitor lock exists, do not start a second process.  But
    # only trust the lock when its recorded PID still exists.  This fixes the
    # case where the user exits during ROUND_DELAY and reopens the dashboard
    # before the old 15-minute lock timeout expires.
    if lock_is_fresh():
        lock = read_lock_info()
        pid = lock.get("pid") or "未知"
        alive = process_exists(pid)
        if alive is False:
            try:
                MONITOR_LOCK_FILE.unlink(missing_ok=True)
                cleanup_messages.append(f"启动前发现 PID {pid} 已退出，已清理残留锁。")
            except Exception as exc:
                return f"检测到残留监控锁但清理失败：{exc}"
        else:
            prefix = "；".join(cleanup_messages) + " " if cleanup_messages else ""
            return prefix + f"检测到已有监控进程或监控锁，暂不重复启动（PID: {pid}）。"

    with RUN_LOCK:
        RUNNING = True
        LAST_RUN_STARTED_AT = now_str()
        LAST_RUN_FINISHED_AT = ""
        LAST_RUN_MESSAGE = "网页面板已启动后台长期监控。"

    threading.Thread(target=background_monitor_worker, args=(reason,), daemon=True).start()
    prefix = "；".join(cleanup_messages) + " " if cleanup_messages else ""
    return prefix + "网页面板已启动后台长期监控。"


def background_monitor_worker(reason: str = "dashboard") -> None:
    global RUNNING, LAST_RUN_MESSAGE, LAST_RUN_FINISHED_AT, CURRENT_PROC
    cmd = [sys.executable, "-X", "utf8", str(APP_DIR / "monitor.py")]
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return_code: int | None = None
    try:
        with WEB_RUN_LOG.open("a", encoding="utf-8", errors="replace") as fh:
            fh.write("\n" + "=" * 70 + "\n")
            fh.write(f"[{now_str()}] Start background monitor ({reason}): {' '.join(cmd)}\n")
            fh.flush()
            popen_kwargs: dict[str, Any] = {
                "cwd": str(ROOT),
                "stdout": fh,
                "stderr": subprocess.STDOUT,
                "env": env,
            }
            # Windows: prevent the dashboard from flashing a new black console
            # window every time it starts monitor.py.  This is intentionally
            # scoped to the child monitor process only; the dashboard page still
            # opens normally for the user.
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
                popen_kwargs["startupinfo"] = startupinfo
                popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)

            proc = subprocess.Popen(cmd, **popen_kwargs)
            with RUN_LOCK:
                CURRENT_PROC = proc
                RUNNING = True
            return_code = proc.wait()
            fh.write(f"[{now_str()}] Background monitor exited with code {return_code}\n")
    except Exception as exc:
        LAST_RUN_MESSAGE = f"后台监控启动或运行失败：{exc}"
        try:
            WEB_RUN_LOG.write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
    finally:
        with RUN_LOCK:
            RUNNING = False
            CURRENT_PROC = None
            LAST_RUN_FINISHED_AT = now_str()
            if return_code is not None:
                LAST_RUN_MESSAGE = f"后台长期监控已退出，退出码 {return_code}。"


def request_immediate_round() -> str:
    """Ask the long-running monitor loop to run as soon as possible."""
    start_msg = start_background_monitor("manual_request")
    runtime = read_runtime_status()
    phase = str(runtime.get("phase") or "")
    control = read_json(CONTROL_FILE, {})
    if not isinstance(control, dict):
        control = {}
    request_ts = time.time()
    control.update({
        "immediate_round_requested": True,
        "request_id": str(int(request_ts * 1000)),
        "requested_at": now_str(),
        "requested_ts": request_ts,
        "source": "dashboard",
        "reason": "manual_run_now_button",
    })
    write_json_atomic(CONTROL_FILE, control)

    try:
        write_runtime_status_from_dashboard(
            manual_request_pending=True,
            manual_request_at=control["requested_at"],
            last_message="已收到手动检测请求：等待中的话会立刻开始下一轮；正在检测则本轮结束后马上再检测。",
        )
    except Exception:
        pass

    if phase == "ROUND_DELAY":
        return "已触发立即检测：当前下一轮等待会被提前结束，马上开始新一轮。"
    if runtime.get("running"):
        return "已触发立即检测：当前这一轮完成后，会立即再检测一轮并重新计算等待时间。"
    return start_msg + " 已发送立即检测请求。"


def monitor_busy() -> bool:
    runtime = read_runtime_status()
    age = runtime_age_seconds(runtime)
    runtime_recent_running = bool(runtime.get("running")) and age is not None and age <= RUNTIME_STALE_SECONDS
    return bool(web_process_running() or runtime_recent_running or lock_is_fresh())



def api_runtime_payload() -> dict[str, Any]:
    cleanup_stale_monitor_artifacts("status_check")
    runtime = read_runtime_status()
    lock = read_lock_info()
    age = runtime_age_seconds(runtime)
    lock_age = lock_age_seconds()
    runtime_recent = age is not None and age <= RUNTIME_STALE_SECONDS
    lock_fresh = lock_age is not None and lock_age <= MONITOR_LOCK_STALE_SECONDS
    runtime_flag_running = bool(runtime.get("running"))
    running = runtime_flag_running and runtime_recent
    stale_running = runtime_flag_running and not runtime_recent
    busy = bool(web_process_running() or running or lock_fresh)

    phase = str(runtime.get("phase") or "")
    if running:
        state_label = "监控运行中"
        state_class = "ok"
    elif phase == "ERROR":
        state_label = "上次检测出错"
        state_class = "bad"
    elif phase == "STOPPED_BY_USER":
        state_label = "用户已停止"
        state_class = "warn"
    elif phase == "LOGIN_REQUIRED":
        state_label = "需要重新登录"
        state_class = "bad"
    elif phase == "VERIFY_REQUIRED":
        state_label = "需要手动验证"
        state_class = "bad"
    elif stale_running:
        state_label = "可能异常 / 状态长时间未更新"
        state_class = "warn"
    elif lock_fresh:
        state_label = "已有监控锁（可能正在运行）"
        state_class = "warn"
    elif runtime:
        state_label = "空闲 / 上次检测已结束"
        state_class = "unknown"
    else:
        state_label = "空闲"
        state_class = "unknown"

    current_index = int(runtime.get("current_index") or 0)
    total = int(runtime.get("total") or 0)
    delay_remaining = int(runtime.get("delay_remaining_seconds") or 0)
    delay_seconds = int(runtime.get("delay_seconds") or 0)
    progress = 0
    progress_text = f"{current_index} / {total}"
    progress_label = "本轮检测进度"
    if running and phase == "ROUND_DELAY" and delay_seconds > 0:
        elapsed_delay = max(0, delay_seconds - delay_remaining)
        progress = max(0, min(100, round(elapsed_delay * 100 / delay_seconds)))
        progress_text = f"等待下一轮：已过 {format_duration(elapsed_delay)} / 共 {format_duration(delay_seconds)}"
        progress_label = "下一轮轮询等待进度"
    elif total > 0:
        progress = max(0, min(100, round(current_index * 100 / total)))

    if runtime_flag_running:
        last_update_text = format_elapsed(age)
    elif runtime.get("finished_at"):
        last_update_text = f"已结束：{runtime.get('finished_at')}"
    elif runtime.get("updated_at"):
        last_update_text = f"上次更新：{runtime.get('updated_at')}"
    else:
        last_update_text = "-"

    delay_seconds = int(runtime.get("delay_seconds") or 0)
    next_round_remaining = int(runtime.get("next_round_remaining_seconds") or 0)
    next_round_at = str(runtime.get("next_round_at") or "")
    mode = str(runtime.get("mode") or "")

    last_network_error_ts = 0.0
    try:
        last_network_error_ts = float(runtime.get("last_network_error_ts") or 0)
    except Exception:
        last_network_error_ts = 0.0
    network_alert_age = time.time() - last_network_error_ts if last_network_error_ts > 0 else 999999.0
    network_alert_active = bool(runtime.get("network_alert_active")) or network_alert_age <= 3600
    network_alert_text = ""
    if network_alert_active:
        reason = compact(runtime.get("last_network_error_reason") or "检测到网络异常", 110)
        when = runtime.get("last_network_error_at") or runtime.get("updated_at") or "刚刚"
        network_alert_text = f"{when} 发生网络异常：{reason}。程序已保留原有可信价格/状态，网络恢复后可点“立即检测一轮”。"
        if running and state_class == "ok":
            state_label = "刚刚发生网络异常"
            state_class = "warn"

    if running and phase == "ROUND_DELAY":
        next_round_text = f"{format_duration(next_round_remaining)}后"
        if next_round_at:
            next_round_text += f"（预计 {next_round_at}）"
    elif running and mode == "loop":
        next_round_text = "本轮结束后重新计算"
    elif mode == "once":
        next_round_text = "手动检测模式，无下一轮"
    elif runtime:
        next_round_text = "长期监控未运行"
    else:
        next_round_text = "-"

    return {
        "runtime": runtime,
        "lock": lock,
        "web_trigger_running": web_process_running(),
        "last_run_message": LAST_RUN_MESSAGE,
        "last_run_started_at": LAST_RUN_STARTED_AT,
        "last_run_finished_at": LAST_RUN_FINISHED_AT,
        "heartbeat_age_seconds": None if age is None else round(age, 1),
        "status_age_seconds": None if age is None else round(age, 1),
        "last_update_text": last_update_text,
        "lock_age_seconds": None if lock_age is None else round(lock_age, 1),
        "runtime_recent": runtime_recent,
        "lock_fresh": lock_fresh,
        "busy": busy,
        "state_label": state_label,
        "state_class": state_class,
        "progress_percent": progress,
        "progress_text": progress_text,
        "progress_label": progress_label,
        "delay_remaining_seconds": delay_remaining,
        "delay_remaining_text": format_duration(delay_remaining),
        "delay_seconds": delay_seconds,
        "next_round_remaining_seconds": next_round_remaining,
        "next_round_text": next_round_text,
        "next_round_at": next_round_at,
        "network_alert_active": network_alert_active,
        "network_alert_text": network_alert_text,
        "button_disabled": False,
        "generated_at": now_str(),
    }


def read_history(limit: int = 200) -> list[dict[str, Any]]:
    if not HISTORY_FILE.exists():
        return []
    try:
        lines = HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        return []
    rows: list[dict[str, Any]] = []
    for line in lines[-max(1, limit):]:
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                rows.append(obj)
        except Exception:
            rows.append({"time": "", "event": "BROKEN_HISTORY_LINE", "reason": line[:200]})
    return rows


def item_id(text: Any) -> str | None:
    return link_manager.extract_item_id(str(text or ""))



def api_items_payload() -> dict[str, Any]:
    """Return freshly rendered item rows for the auto-refreshing dashboard table.

    v0.6.2 wrote per-item check_count into state.json, but the HTML table was
    only rendered once when the page was opened. This endpoint lets the browser
    refresh the product rows without restarting or touching the monitor process.
    """
    links = link_manager.read_links()
    state = read_state()
    return {
        "rows": item_rows(),
        "link_count": len(links),
        "state_count": len(state),
        "updated_at": now_str(),
    }


def api_trends_payload() -> dict[str, Any]:
    """Return freshly rendered trend cards for the product trend board."""
    return {
        "html": trend_cards_html(),
        "updated_at": now_str(),
    }

def state_key_for_link(link: str) -> str:
    iid = item_id(link)
    return f"item:{iid}" if iid else "url:" + link.strip()


def state_display_quality(obj: dict[str, Any] | None) -> tuple[int, str]:
    """Rank dashboard state candidates.

    Short links can leave an old transient failure entry under the source URL,
    while a later successful run writes the real item entry under item:<id>.
    Prefer entries with real product identity/price/status over stale placeholders.
    """
    if not isinstance(obj, dict):
        return (-1, "")
    status = str(obj.get("status") or "")
    has_title = bool(obj.get("title"))
    has_price = obj.get("price") not in (None, "")
    trusted_statuses = {"NORMAL", "SOLD", "REMOVED"}
    meta_problem_statuses = {"LOGIN_REQUIRED", "VERIFY_REQUIRED"}
    untrusted_statuses = {"LOAD_FAILED", "UNKNOWN", "", "None"}

    score = 0
    if status in trusted_statuses:
        score += 100
    elif status in meta_problem_statuses:
        score += 70
    elif status in untrusted_statuses:
        score += 5
    else:
        score += 20
    if has_title:
        score += 25
    if has_price:
        score += 20
    if str(obj.get("state_key") or "").startswith("item:"):
        score += 8
    if obj.get("last_error_status") and status in untrusted_statuses:
        score -= 15
    checked = str(obj.get("last_checked") or obj.get("last_seen") or "")
    return (score, checked)


def find_state_for_link(link: str, state: dict[str, Any]) -> tuple[str | None, dict[str, Any] | None]:
    key = state_key_for_link(link)
    link_iid = item_id(link)
    seen_keys: set[str] = set()
    candidates: list[tuple[str, dict[str, Any]]] = []

    def add_candidate(k: Any, obj: Any) -> None:
        if not isinstance(k, str) or not isinstance(obj, dict) or k in seen_keys:
            return
        seen_keys.add(k)
        candidates.append((k, obj))

    # Exact current key and legacy source-url key are candidates, but no longer
    # return immediately: a previous断网/加载失败 may have left a stale placeholder.
    add_candidate(key, state.get(key))
    add_candidate(link, state.get(link))
    add_candidate("url:" + link.strip(), state.get("url:" + link.strip()))

    for k, obj in state.items():
        if not isinstance(obj, dict):
            continue
        urls = [str(obj.get("url") or ""), str(obj.get("resolved_url") or "")]
        if link in urls:
            add_candidate(str(k), obj)
            continue
        if link_iid:
            id_sources = [str(k), *urls]
            if any(item_id(x) == link_iid for x in id_sources):
                add_candidate(str(k), obj)

    if not candidates:
        return None, None

    # Prefer the most displayable product record. This fixes the case where a
    # source short-link failure entry existed before the later successful item
    # entry, causing the table to keep showing“未检测”.
    best_key, best_obj = max(candidates, key=lambda pair: state_display_quality(pair[1]))
    return best_key, best_obj


def history_matches(event: dict[str, Any], link: str, key: str | None) -> bool:
    if key and event.get("state_key") == key:
        return True
    urls = [str(event.get("url") or ""), str(event.get("resolved_url") or "")]
    if link in urls:
        return True
    iid = item_id(link)
    return bool(iid and any(item_id(u) == iid for u in urls))


def compact(value: Any, n: int = 80) -> str:
    s = " ".join(str(value or "").split())
    return s if len(s) <= n else s[: n - 1] + "…"


def price(value: Any) -> str:
    if value is None or value == "":
        return "-"
    try:
        f = float(value)
        return f"¥{int(f)}" if f.is_integer() else f"¥{f:.2f}"
    except Exception:
        return escape(str(value))


def badge(text: str, cls: str = "unknown") -> str:
    return f'<span class="badge {cls}">{escape(text)}</span>'


def status_badge(status: Any, is_buyable: Any = None) -> str:
    s = str(status or "未检测")
    label = STATUS_LABELS.get(s, s)
    if s == "NORMAL" and is_buyable is True:
        cls = "ok"
    elif s in {"SOLD", "REMOVED"} or is_buyable is False:
        cls = "bad"
    elif s in {"LOGIN_REQUIRED", "VERIFY_REQUIRED", "LOAD_FAILED", "UNKNOWN", "NETWORK_ERROR"}:
        cls = "warn"
    else:
        cls = "unknown"
    return badge(label, cls)


def event_badge(event: Any) -> str:
    e = str(event or "")
    label = EVENT_LABELS.get(e, e or "-")
    if e in {"PRICE_DOWN", "RECOVERED"}:
        cls = "ok"
    elif e in {"SOLD", "REMOVED", "NOT_BUYABLE"}:
        cls = "bad"
    elif e in {"PRICE_UP", "TITLE_CHANGED", "LOGIN_REQUIRED", "VERIFY_REQUIRED", "NETWORK_ERROR"}:
        cls = "warn"
    else:
        cls = "unknown"
    return badge(label, cls)


def price_delta(old_value: Any, new_value: Any) -> str:
    old = safe_float(old_value)
    new = safe_float(new_value)
    if old is None or new is None:
        return ""
    diff = new - old
    if abs(diff) < 0.000001:
        return ""
    sign = "+" if diff > 0 else "-"
    value = abs(diff)
    text = f"¥{int(value)}" if float(value).is_integer() else f"¥{value:.2f}"
    return f"{sign}{text}"


def is_network_event(event: dict[str, Any] | None) -> bool:
    return bool(isinstance(event, dict) and str(event.get("event") or "") == "NETWORK_ERROR")


def price_cell_html(st: dict[str, Any], events: list[dict[str, Any]]) -> str:
    current = price(st.get("price"))
    event = last_detection_event(events, st)
    delta_html = ""
    if event and str(event.get("event") or "") in {"PRICE_UP", "PRICE_DOWN"}:
        is_up = str(event.get("event")) == "PRICE_UP"
        cls = "up" if is_up else "down"
        label = "本次涨价" if is_up else "本次降价"
        delta = price_delta(event.get("old_price"), event.get("new_price"))
        if delta:
            delta_html = f'<div class="price-mini-delta {cls}">{escape(label)} {escape(delta)}</div>'
    if st.get("last_error_status") and st.get("last_network_error_at"):
        delta_html = '<div class="price-mini-delta warn">网络异常，沿用旧价</div>'
    return (
        '<div class="price-chip">'
        f'<strong>{current}</strong>'
        '<small>当前价格</small>'
        '</div>' + delta_html
    )


def same_detection_time(a: Any, b: Any, tolerance_seconds: int = 3) -> bool:
    da = parse_time_text(a)
    db = parse_time_text(b)
    if da and db:
        return abs((da - db).total_seconds()) <= tolerance_seconds
    return bool(str(a or "") and str(a or "") == str(b or ""))


def last_detection_event(events: list[dict[str, Any]], st: dict[str, Any]) -> dict[str, Any] | None:
    """Return the event that happened in the latest detection, not the latest historical change.

    history.jsonl only records changes.  If a product changed yesterday but the
    latest check had no change, the table should show “上次检测：无变化” instead
    of repeating yesterday's change badge.
    """
    last_checked = st.get("last_checked") or st.get("last_seen")
    if not last_checked:
        return None
    for event in reversed(events):
        if same_detection_time(event.get("time"), last_checked):
            return event
    return None


def detection_summary_html(st: dict[str, Any], events: list[dict[str, Any]]) -> str:
    event = last_detection_event(events, st)
    if event:
        e = str(event.get("event") or "")
        if e in {"PRICE_UP", "PRICE_DOWN"}:
            cls = "price-up-box" if e == "PRICE_UP" else "price-down-box"
            label = "涨价" if e == "PRICE_UP" else "降价"
            delta = price_delta(event.get("old_price"), event.get("new_price"))
            delta_part = f" <b>{escape(delta)}</b>" if delta else ""
            return (
                f'<div class="status-event {cls}">'
                f'<b>{label}</b>{delta_part}　'
                f'<span>{price(event.get("old_price"))} → {price(event.get("new_price"))}</span>'
                '</div>'
            )
        if e == "NETWORK_ERROR":
            return '<div class="status-event status-error">上次检测：网络异常，未覆盖旧价格/状态</div>'
        return f'<div class="status-event">上次检测：{event_badge(e)}</div>'

    if st.get("last_error_status"):
        reason = compact(st.get("last_error_reason") or st.get("last_error_status"), 40)
        return f'<div class="status-event status-error">上次检测失败：{escape(reason)}</div>'
    if int(st.get("check_count") or 0) <= 1:
        return '<div class="status-event status-base">上次检测：建立基准</div>'
    return '<div class="status-event status-stable">上次检测：无变化</div>'


def status_cell_html(st: dict[str, Any], events: list[dict[str, Any]]) -> str:
    reason = compact(st.get('buyability_reason'), 60)
    reason_html = f'<br><small>{escape(reason)}</small>' if reason else ''
    return f"{status_badge(st.get('status'), st.get('is_buyable'))}{detection_summary_html(st, events)}{reason_html}"


def parse_time_text(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            continue
    return None


def safe_float(value: Any) -> float | None:
    try:
        if value in (None, ""):
            return None
        return float(value)
    except Exception:
        return None


def status_segment_class(status: Any) -> str:
    status_text = str(status or "")
    if status_text == "NORMAL":
        return "seg-ok"
    if status_text in {"SOLD", "REMOVED"}:
        return "seg-bad"
    if status_text in {"LOGIN_REQUIRED", "VERIFY_REQUIRED", "LOAD_FAILED", "UNKNOWN"}:
        return "seg-warn"
    return "seg-unknown"


def price_event_class(event: Any) -> str:
    e = str(event or "")
    if e == "PRICE_UP":
        return "price-up"
    if e == "PRICE_DOWN":
        return "price-down"
    return "price-neutral"


def build_trend_data(link: str, state: dict[str, Any], hist: list[dict[str, Any]]) -> dict[str, Any]:
    key, st = find_state_for_link(link, state)
    st = st or {}
    iid = item_id(link) or item_id(st.get("resolved_url")) or "-"
    resolved = str(st.get("resolved_url") or link)
    title = str(st.get("title") or f"商品 {iid}")
    events = [h for h in hist if history_matches(h, link, key)]
    events.sort(key=lambda x: parse_time_text(x.get("time")) or datetime.min)

    snapshots: list[dict[str, Any]] = []
    if events:
        first = events[0]
        snapshots.append({
            "time": str(first.get("time") or st.get("first_checked") or ""),
            "price": first.get("old_price"),
            "status": first.get("old_status"),
            "event": "BASELINE",
            "reason": first.get("reason") or first.get("buyability_reason") or "",
        })
        for event in events:
            snapshots.append({
                "time": str(event.get("time") or ""),
                "price": event.get("new_price"),
                "status": event.get("new_status"),
                "event": event.get("event"),
                "reason": event.get("reason") or event.get("buyability_reason") or "",
                "old_price": event.get("old_price"),
                "new_price": event.get("new_price"),
                "old_status": event.get("old_status"),
                "new_status": event.get("new_status"),
            })

    current_time = str(st.get("last_checked") or st.get("last_seen") or st.get("last_changed") or st.get("first_checked") or "")
    current_snapshot = {
        "time": current_time,
        "price": st.get("price"),
        "status": st.get("status"),
        "event": "CURRENT",
        "reason": st.get("buyability_reason") or "",
    }
    if not snapshots:
        snapshots.append(current_snapshot)
    else:
        last = snapshots[-1]
        last_sig = (str(last.get("time") or ""), safe_float(last.get("price")), str(last.get("status") or ""))
        current_sig = (str(current_snapshot.get("time") or ""), safe_float(current_snapshot.get("price")), str(current_snapshot.get("status") or ""))
        if current_sig != last_sig:
            snapshots.append(current_snapshot)

    normalized: list[dict[str, Any]] = []
    for snap in snapshots:
        snap = dict(snap)
        snap["dt"] = parse_time_text(snap.get("time"))
        snap["price_value"] = safe_float(snap.get("price"))
        if normalized:
            prev = normalized[-1]
            same_time = str(prev.get("time") or "") == str(snap.get("time") or "")
            same_price = prev.get("price_value") == snap.get("price_value")
            same_status = str(prev.get("status") or "") == str(snap.get("status") or "")
            if same_time and same_price and same_status:
                if snap.get("event") not in (None, "", "CURRENT"):
                    prev["event"] = snap.get("event")
                    prev["reason"] = snap.get("reason") or prev.get("reason")
                continue
        normalized.append(snap)

    price_values = [snap["price_value"] for snap in normalized if snap.get("price_value") is not None]
    price_up_count = sum(1 for event in events if str(event.get("event") or "") == "PRICE_UP")
    price_down_count = sum(1 for event in events if str(event.get("event") or "") == "PRICE_DOWN")
    status_change_count = sum(1 for event in events if str(event.get("old_status") or "") != str(event.get("new_status") or ""))

    return {
        "link": link,
        "state_key": key,
        "item_id": iid,
        "title": title,
        "resolved_url": resolved,
        "current_price": st.get("price"),
        "current_status": st.get("status"),
        "is_buyable": st.get("is_buyable"),
        "last_checked": st.get("last_checked") or st.get("last_seen") or "-",
        "check_count": st.get("check_count"),
        "price_up_count": price_up_count,
        "price_down_count": price_down_count,
        "status_change_count": status_change_count,
        "event_count": len(events),
        "min_price": min(price_values) if price_values else None,
        "max_price": max(price_values) if price_values else None,
        "snapshots": normalized,
        "events": events,
    }


def render_trend_svg(data: dict[str, Any]) -> str:
    width = 860
    height = 240
    left = 72
    right = 18
    top = 18
    plot_height = 126
    band_gap = 18
    band_height = 24
    bottom = 44
    plot_width = width - left - right
    plot_y2 = top + plot_height
    band_y = plot_y2 + band_gap
    baseline_y = band_y + band_height + 10

    snaps = data.get("snapshots") or []
    prepared: list[dict[str, Any]] = []
    for idx, snap in enumerate(snaps):
        dt = snap.get("dt")
        ts = dt.timestamp() if isinstance(dt, datetime) else float(idx)
        prepared.append({**snap, "idx": idx, "ts": ts})

    if not prepared:
        return '<div class="muted">暂无可用历史数据。</div>'

    if len(prepared) == 1:
        prepared[0]["x"] = left + plot_width / 2
    else:
        x_values = [point["ts"] for point in prepared]
        x_min = min(x_values)
        x_max = max(x_values)
        if x_max <= x_min:
            x_max = x_min + max(1, len(prepared) - 1)
        for point in prepared:
            point["x"] = left + ((point["ts"] - x_min) / (x_max - x_min)) * plot_width

    price_points = [point for point in prepared if point.get("price_value") is not None]
    if price_points:
        y_values = [point["price_value"] for point in price_points]
        y_min = min(y_values)
        y_max = max(y_values)
        if y_max <= y_min:
            pad = max(1.0, y_min * 0.05 if y_min else 1.0)
            y_min -= pad
            y_max += pad
        else:
            pad = max((y_max - y_min) * 0.12, 1.0)
            y_min -= pad
            y_max += pad

        def y_for(price_value: float) -> float:
            return top + (y_max - price_value) / (y_max - y_min) * plot_height

        for point in price_points:
            point["y"] = y_for(point["price_value"])
    else:
        y_min = 0.0
        y_max = 1.0

    parts: list[str] = [
        f'<svg class="trend-svg" viewBox="0 0 {width} {height}" role="img" aria-label="商品价格与状态走势">'
    ]

    grid_levels = 4
    if price_points:
        for level in range(grid_levels + 1):
            ratio = level / grid_levels
            y = top + plot_height * ratio
            price_value = y_max - (y_max - y_min) * ratio
            parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width-right}" y2="{y:.1f}" class="grid-line" />')
            parts.append(f'<text x="{left-8}" y="{y+4:.1f}" text-anchor="end" class="axis-label">{escape(price(price_value))}</text>')
    else:
        parts.append(f'<text x="{left}" y="{top + plot_height / 2:.1f}" class="axis-label">暂无价格变化数据</text>')

    parts.append(f'<line x1="{left}" y1="{plot_y2:.1f}" x2="{width-right}" y2="{plot_y2:.1f}" class="axis-line" />')

    if price_points:
        path_cmds: list[str] = []
        for idx, point in enumerate(price_points):
            x = point["x"]
            y = point["y"]
            if idx == 0:
                path_cmds.append(f'M {x:.1f} {y:.1f}')
            else:
                prev = price_points[idx - 1]
                path_cmds.append(f'L {x:.1f} {prev["y"]:.1f}')
                path_cmds.append(f'L {x:.1f} {y:.1f}')
        parts.append(f'<path d="{" ".join(path_cmds)}" class="price-line" />')
        for point in price_points:
            event = str(point.get("event") or "")
            klass = price_event_class(event)
            title = escape(f"{point.get('time') or '-'} | 价格 {price(point.get('price_value'))} | 事件 {EVENT_LABELS.get(event, event or '当前')}" )
            parts.append(
                f'<circle cx="{point["x"]:.1f}" cy="{point["y"]:.1f}" r="4.5" class="price-dot {klass}"><title>{title}</title></circle>'
            )

    segment_end = width - right
    for idx, point in enumerate(prepared):
        x1 = point["x"] if len(prepared) > 1 else left
        if len(prepared) == 1:
            x2 = segment_end
        elif idx < len(prepared) - 1:
            x2 = prepared[idx + 1]["x"]
        else:
            x2 = segment_end
        if x2 < x1:
            x2 = x1
        status_value = str(point.get("status") or "未检测")
        label = STATUS_LABELS.get(status_value, status_value or "未检测")
        title = escape(f"{point.get('time') or '-'} | 状态 {label}")
        parts.append(
            f'<rect x="{x1:.1f}" y="{band_y:.1f}" width="{max(1.0, x2 - x1):.1f}" height="{band_height}" rx="4" class="status-seg {status_segment_class(status_value)}"><title>{title}</title></rect>'
        )

    status_change_events = []
    for point in prepared:
        old_status = str(point.get("old_status") or "")
        new_status = str(point.get("new_status") or point.get("status") or "")
        event_name = str(point.get("event") or "")
        if old_status and new_status and old_status != new_status:
            status_change_events.append(point)
        elif event_name in {"SOLD", "REMOVED", "RECOVERED", "STATUS_CHANGED", "LOGIN_REQUIRED", "VERIFY_REQUIRED", "NOT_BUYABLE"}:
            status_change_events.append(point)
    seen_status_markers: set[tuple[Any, Any, Any]] = set()
    for point in status_change_events:
        marker_key = (point.get("time"), point.get("old_status"), point.get("new_status") or point.get("status"))
        if marker_key in seen_status_markers:
            continue
        seen_status_markers.add(marker_key)
        x = point["x"]
        diamond_y = band_y - 7
        points_text = f"{x:.1f},{diamond_y-5:.1f} {x+5:.1f},{diamond_y:.1f} {x:.1f},{diamond_y+5:.1f} {x-5:.1f},{diamond_y:.1f}"
        old_label = STATUS_LABELS.get(str(point.get("old_status") or ""), str(point.get("old_status") or "-"))
        new_label = STATUS_LABELS.get(str(point.get("new_status") or point.get("status") or ""), str(point.get("new_status") or point.get("status") or "-"))
        title = escape(f"{point.get('time') or '-'} | 状态变化 {old_label} → {new_label}")
        parts.append(f'<line x1="{x:.1f}" y1="{top + plot_height + 2:.1f}" x2="{x:.1f}" y2="{band_y - 10:.1f}" class="status-link" />')
        parts.append(f'<polygon points="{points_text}" class="status-marker"><title>{title}</title></polygon>')

    last_label_x: float | None = None
    min_label_gap = 72.0
    for idx, point in enumerate(prepared):
        event = str(point.get("event") or "")
        label = EVENT_LABELS.get(event, "当前") if event not in {"BASELINE", "CURRENT", ""} else ("当前状态" if event == "CURRENT" else "基准")
        x = float(point["x"])
        parts.append(f'<line x1="{x:.1f}" y1="{band_y + band_height:.1f}" x2="{x:.1f}" y2="{baseline_y - 5:.1f}" class="tick-line" />')
        important = idx == 0 or idx == len(prepared) - 1 or event in {"PRICE_UP", "PRICE_DOWN", "SOLD", "REMOVED", "RECOVERED", "NOT_BUYABLE", "LOGIN_REQUIRED", "VERIFY_REQUIRED"}
        if important and (last_label_x is None or abs(x - last_label_x) >= min_label_gap):
            anchor = "middle"
            label_x = x
            if idx == 0:
                anchor = "start"
                label_x = max(x, left + 2)
            elif idx == len(prepared) - 1:
                anchor = "end"
                label_x = min(x, width - right - 2)
            parts.append(f'<text x="{label_x:.1f}" y="{baseline_y + 8:.1f}" text-anchor="{anchor}" class="tick-label">{escape(label)}</text>')
            last_label_x = x

    start_text = str(prepared[0].get("time") or "开始")
    end_text = str(prepared[-1].get("time") or "当前")
    parts.append(f'<text x="{left}" y="{height-8}" text-anchor="start" class="axis-label">{escape(start_text)}</text>')
    parts.append(f'<text x="{width-right}" y="{height-8}" text-anchor="end" class="axis-label">{escape(end_text)}</text>')
    parts.append('</svg>')
    return "".join(parts)


def trend_cards_html() -> str:
    links = link_manager.read_links()
    state = read_state()
    hist = read_history(100000)
    if not links:
        return '<div class="muted">暂无监控商品。添加链接后，这里会显示每个商品的价格趋势与状态时间带。</div>'

    cards: list[str] = []
    for link in links:
        data = build_trend_data(link, state, hist)
        iid = str(data.get("item_id") or "-")
        anchor_id = f'trend-item-{iid}'
        title = escape(compact(data.get("title") or f"商品 {iid}", 84))
        resolved_url = escape(str(data.get("resolved_url") or link), quote=True)
        check_count = data.get("check_count")
        check_text = str(check_count) if check_count not in (None, "") else "-"
        stats_html = (
            f'<div class="mini-stat"><b>{escape(str(data.get("price_up_count") or 0))}</b><span>涨价次数</span></div>'
            f'<div class="mini-stat"><b>{escape(str(data.get("price_down_count") or 0))}</b><span>降价次数</span></div>'
            f'<div class="mini-stat"><b>{escape(str(data.get("status_change_count") or 0))}</b><span>状态变动</span></div>'
            f'<div class="mini-stat"><b>{escape(str(check_text))}</b><span>检测次数</span></div>'
            f'<div class="mini-stat"><b>{escape(price(data.get("max_price")))}</b><span>最高价</span></div>'
            f'<div class="mini-stat"><b>{escape(price(data.get("min_price")))}</b><span>最低价</span></div>'
        )
        legend_html = (
            '<div class="trend-legend">'
            '<span><i class="legend-line"></i>价格阶梯线</span>'
            '<span><i class="legend-dot price-up"></i>涨价点</span>'
            '<span><i class="legend-dot price-down"></i>降价点</span>'
            '<span><i class="legend-diamond"></i>状态变动</span>'
            '<span><i class="legend-band seg-ok"></i>可购买</span>'
            '<span><i class="legend-band seg-bad"></i>已售/下架</span>'
            '<span><i class="legend-band seg-warn"></i>异常/待验证</span>'
            '</div>'
        )
        cards.append(
            '<article class="trend-card" id="' + escape(anchor_id, quote=True) + '">'
            '<div class="trend-head">'
            '<div>'
            f'<div class="trend-title"><a href="{resolved_url}" target="_blank">{title}</a></div>'
            f'<div class="muted">商品ID：<code>{escape(iid)}</code>　最近检查：{escape(str(data.get("last_checked") or "-"))}</div>'
            '</div>'
            '<div class="trend-head-meta">'
            f'<div>当前价格：<b>{escape(price(data.get("current_price")))}</b></div>'
            f'<div>当前状态：{status_badge(data.get("current_status"), data.get("is_buyable"))}</div>'
            '</div>'
            '</div>'
            f'<div class="mini-stats">{stats_html}</div>'
            f'<div class="trend-chart-wrap">{render_trend_svg(data)}</div>'
            f'{legend_html}'
            '</article>'
        )
    return "\n".join(cards)


def item_rows() -> str:
    links = link_manager.read_links()
    state = read_state()
    hist = read_history(5000)
    if not links:
        return '<tr><td colspan="9" class="muted">暂无链接。请在上方粘贴闲鱼分享文本或商品链接。</td></tr>'
    rows: list[str] = []
    for i, link in enumerate(links, 1):
        key, st = find_state_for_link(link, state)
        st = st or {}
        iid = item_id(link) or item_id(st.get("resolved_url")) or "-"
        title = compact(st.get("title") or "未检测", 70)
        resolved = str(st.get("resolved_url") or link)
        events = [h for h in hist if history_matches(h, link, key)]
        status_html = status_cell_html(st, events)
        row_cls = overview_status_class(st.get("status"), st.get("is_buyable"))
        check_count = st.get("check_count")
        check_count_text = str(check_count) if check_count not in (None, "") else "-"
        last_round_text = str(st.get("last_round_no")) if st.get("last_round_no") not in (None, "") else "-"
        first_checked_text = str(st.get("first_checked") or "-")
        trend_anchor = f"#trend-item-{iid}"
        rows.append(
            f'<tr class="item-row row-{escape(row_cls, quote=True)}">'
            f'<td><input type="checkbox" name="idx" value="{i}"></td>'
            f"<td>{i}</td>"
            f"<td><code>{escape(str(iid))}</code></td>"
            f'<td><a href="{escape(resolved, quote=True)}" target="_blank">{escape(title)}</a><br><small>{escape(compact(link, 96))}</small></td>'
            f"<td>{status_html}</td>"
            f"<td class='price-cell'>{price_cell_html(st, events)}</td>"
            f"<td><b>{escape(check_count_text)}</b><br><small>最近轮次：{escape(last_round_text)}</small><br><small>首次：{escape(first_checked_text)}</small></td>"
            f"<td>{escape(str(st.get('last_checked') or st.get('last_seen') or '-'))}<br><small>变化：{escape(str(st.get('last_changed') or '-'))}</small></td>"
            f'<td><a class="mini-btn" href="{escape(trend_anchor, quote=True)}">查看走势</a></td>'
            "</tr>"
        )
    return "\n".join(rows)


def history_rows(limit: int = 80) -> str:
    hist = read_history(limit)
    if not hist:
        return '<tr><td colspan="7" class="muted">暂无历史变化。第一次运行通常只建立基准，不写变化历史。</td></tr>'
    rows: list[str] = []
    for e in reversed(hist):
        url = str(e.get("resolved_url") or e.get("url") or "")
        rows.append(
            "<tr>"
            f"<td>{escape(str(e.get('time') or '-'))}</td>"
            f"<td>{event_badge(e.get('event'))}</td>"
            f"<td><a href=\"{escape(url, quote=True)}\" target=\"_blank\">{escape(compact(e.get('title') or '-', 58))}</a></td>"
            f"<td>{escape(str(e.get('old_status') or '-'))} → {escape(str(e.get('new_status') or '-'))}</td>"
            f"<td>{price(e.get('old_price'))} → {price(e.get('new_price'))}</td>"
            f"<td>{escape(compact(e.get('reason') or e.get('buyability_reason') or '', 78))}</td>"
            f"<td><small>{escape(compact(url, 52))}</small></td>"
            "</tr>"
        )
    return "\n".join(rows)


def last_round_html() -> str:
    data = read_json(LAST_ROUND_DEBUG, {})
    items = data.get("items") if isinstance(data, dict) else None
    if not isinstance(items, list) or not items:
        return '<p class="muted">暂无本轮调试摘要。运行一次检测后会生成。</p>'
    parts = [
        f"<p>历史总第 <b>{escape(str(data.get('round_no') or '-'))}</b> 轮；"
        f"时间：{escape(str(data.get('written_at') or '-'))}；数量：{escape(str(data.get('count') or len(items)))}</p>",
        '<div class="cards">',
    ]
    for item in items:
        if not isinstance(item, dict):
            continue
        debug = str(item.get("debug_json") or "")
        debug_href = f"/file?path={quote(debug)}" if debug else "#"
        parts.append(
            '<div class="card">'
            f"<div>{status_badge(item.get('status'), item.get('is_buyable'))} <b>{escape(compact(item.get('title') or '未识别', 56))}</b></div>"
            f"<div>价格：{price(item.get('price'))}</div>"
            f"<div><small>{escape(compact(item.get('buyability_reason'), 90))}</small></div>"
            f"<div><a href=\"{escape(debug_href, quote=True)}\" target=\"_blank\">debug JSON</a></div>"
            '</div>'
        )
    parts.append('</div>')
    return "\n".join(parts)


def tools_page_html() -> str:
    groups = [
        ("运行日志", [
            ("monitor.log", "logs/monitor.log"),
            ("web_background_monitor.log", "logs/web_background_monitor.log"),
        ]),
        ("运行状态 JSON", [
            ("runtime_status.json", "data/runtime_status.json"),
            ("state.json", "data/state.json"),
            ("history.jsonl", "data/history.jsonl"),
            ("run_meta.json", "data/run_meta.json"),
            ("monitor_control.json", "data/monitor_control.json"),
        ]),
        ("调试文件", [
            ("last_round_debug.json", "logs/last_round_debug.json"),
            ("last_candidates_debug.json", "logs/last_candidates_debug.json"),
            ("last_page_debug.html", "logs/last_page_debug.html"),
        ]),
    ]
    sections: list[str] = []
    for title, items in groups:
        links: list[str] = []
        for label, rel in items:
            path = ROOT / rel
            if path.exists():
                href = f"/file?path={quote(rel)}"
                links.append(f'<a class="button secondary" href="{escape(href, quote=True)}" target="_blank">{escape(label)}</a>')
        if not links:
            links.append('<span class="muted">暂无可用文件</span>')
        sections.append(f'<section><h2>{escape(title)}</h2><div class="row">{"".join(links)}</div></section>')
    sections_html = "".join(sections)
    return (
        '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>日志 / 状态文件合集</title><style>'
        'body{margin:0;background:#f6f7f9;color:#1f2937;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",Arial,sans-serif}'
        'main{max-width:1080px;margin:auto;padding:22px}'
        'section{background:white;border:1px solid #e5e7eb;border-radius:16px;padding:18px;margin-bottom:18px;box-shadow:0 8px 24px rgba(0,0,0,.04)}'
        'h1{margin:0 0 8px;font-size:26px}'
        'h2{margin:0 0 14px;font-size:18px}'
        '.muted{color:#6b7280}'
        '.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center}'
        '.button{border:0;border-radius:10px;padding:10px 14px;background:#4b5563;color:white;cursor:pointer;text-decoration:none;display:inline-block;font-size:14px}'
        '</style></head><body><main>'
        '<h1>日志 / 状态文件合集</h1>'
        '<p class="muted">这里汇总打开常用日志、运行状态和调试文件，避免主面板按钮过于分散。</p>'
        '<div class="row" style="margin-bottom:18px"><a class="button" href="/">返回主面板</a></div>'
        + sections_html +
        '</main></body></html>'
    )



def overview_status_class(status: Any, is_buyable: Any = None) -> str:
    status_text = str(status or "")
    if status_text == "NORMAL" and is_buyable is True:
        return "ok"
    if status_text in {"SOLD", "REMOVED"} or is_buyable is False:
        return "bad"
    if status_text in {"LOGIN_REQUIRED", "VERIFY_REQUIRED", "LOAD_FAILED", "UNKNOWN", "NETWORK_ERROR"}:
        return "warn"
    return "unknown"


def status_overview_html() -> str:
    links = link_manager.read_links()
    state = read_state()
    hist = read_history(5000)
    counts = {"ok": 0, "warn": 0, "bad": 0, "unknown": 0}
    changed_latest = 0
    for link in links:
        key, st = find_state_for_link(link, state)
        st = st or {}
        counts[overview_status_class(st.get("status"), st.get("is_buyable"))] += 1
        events = [h for h in hist if history_matches(h, link, key)]
        if last_detection_event(events, st):
            changed_latest += 1
    total = max(len(links), 1)
    ok_pct = counts["ok"] / total * 100
    warn_pct = counts["warn"] / total * 100
    bad_pct = counts["bad"] / total * 100
    unknown_pct = counts["unknown"] / total * 100
    return (
        '<section class="overview-section"><div class="section-title-row"><div><span class="eyebrow">Overview</span><h2>商品状态总览</h2></div>'
        '<p class="muted">用颜色先判断风险，再进表格或趋势图看细节。</p></div>'
        '<div class="health-strip" aria-label="商品状态占比">'
        f'<span class="health-ok" style="width:{ok_pct:.2f}%"></span>'
        f'<span class="health-warn" style="width:{warn_pct:.2f}%"></span>'
        f'<span class="health-bad" style="width:{bad_pct:.2f}%"></span>'
        f'<span class="health-unknown" style="width:{unknown_pct:.2f}%"></span>'
        '</div>'
        '<div class="overview-grid">'
        f'<div class="overview-card ok"><b>{counts["ok"]}</b><span>可购买</span><small>状态正常，价格可读取</small></div>'
        f'<div class="overview-card warn"><b>{counts["warn"]}</b><span>需关注</span><small>登录、验证、加载异常等</small></div>'
        f'<div class="overview-card bad"><b>{counts["bad"]}</b><span>已售 / 下架</span><small>不可购买或链接失效</small></div>'
        f'<div class="overview-card unknown"><b>{counts["unknown"]}</b><span>未建立状态</span><small>等待首次检测或数据为空</small></div>'
        f'<div class="overview-card accent"><b>{changed_latest}</b><span>上次检测有变动</span><small>以每个商品最近一次检测为准</small></div>'
        '</div></section>'
    )


def recent_activity_html(limit: int = 8) -> str:
    hist = read_history(limit)
    if not hist:
        return '<section><div class="section-title-row"><div><span class="eyebrow">Activity</span><h2>最近状态变动</h2></div></div><p class="muted">暂无历史变化。第一次运行通常只建立基准，不写变化历史。</p></section>'
    cards: list[str] = []
    for event in reversed(hist):
        title = escape(compact(event.get("title") or "未命名商品", 64))
        event_name = str(event.get("event") or "")
        delta = price_delta(event.get("old_price"), event.get("new_price"))
        delta_html = f'<strong>{escape(delta)}</strong>' if delta else '<strong>状态变化</strong>'
        url = escape(str(event.get("resolved_url") or event.get("url") or "#"), quote=True)
        reason = compact(event.get("reason") or event.get("buyability_reason") or "", 72)
        reason_html = f'<small>{escape(reason)}</small>' if reason else ''
        cards.append(
            '<a class="activity-card" href="' + url + '" target="_blank">'
            '<div class="activity-main">'
            f'<div class="activity-top">{event_badge(event_name)}<time>{escape(str(event.get("time") or "-"))}</time></div>'
            f'<b>{title}</b>{reason_html}'
            '</div>'
            f'<div class="activity-delta {escape(price_event_class(event_name))}">{delta_html}<span>{price(event.get("old_price"))} → {price(event.get("new_price"))}</span></div>'
            '</a>'
        )
    return (
        '<section><div class="section-title-row"><div><span class="eyebrow">Activity</span><h2>最近状态变动</h2></div>'
        '<p class="muted">价格和状态的最近变化入口，点击可打开商品。</p></div>'
        '<div class="activity-list">' + ''.join(cards) + '</div></section>'
    )

def dashboard(message: str = "") -> str:
    links = link_manager.read_links()
    state = read_state()
    hist = read_history(100000)
    meta = read_json(RUN_META_FILE, {})
    rt = api_runtime_payload()
    disabled = "disabled" if rt["button_disabled"] else ""
    stop_disabled = "" if rt["web_trigger_running"] else "disabled"
    msg = message or LAST_RUN_MESSAGE
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>xy-monitor 本地面板</title><style>
:root{{--bg:#eef3fb;--panel:#ffffff;--panel-2:#f8fbff;--text:#111827;--muted:#64748b;--line:#dbe4f0;--brand:#2563eb;--brand-2:#0ea5e9;--good:#16a34a;--good-bg:#dcfce7;--warn:#d97706;--warn-bg:#fef3c7;--bad:#dc2626;--bad-bg:#fee2e2;--shadow:0 18px 55px rgba(15,23,42,.10);--soft-shadow:0 10px 28px rgba(15,23,42,.07);--radius:22px;--radius-sm:14px}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;min-height:100vh;background:radial-gradient(circle at 12% -10%,#dbeafe 0,transparent 34%),radial-gradient(circle at 92% 0,#e0f2fe 0,transparent 30%),linear-gradient(180deg,#f8fbff 0,#eef3fb 58%,#f7f9fc 100%);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",Arial,sans-serif}}a{{color:#1d4ed8}}header.hero{{position:relative;overflow:hidden;color:white;background:linear-gradient(135deg,#0f172a 0%,#1e3a8a 48%,#0369a1 100%);padding:34px 28px 38px;box-shadow:var(--soft-shadow)}}header.hero::before{{content:"";position:absolute;inset:-90px -90px auto auto;width:300px;height:300px;border-radius:999px;background:rgba(255,255,255,.14);filter:blur(2px)}}header.hero::after{{content:"";position:absolute;left:8%;bottom:-95px;width:260px;height:260px;border-radius:999px;background:rgba(14,165,233,.18)}}.hero-inner{{position:relative;max-width:1280px;margin:auto;display:flex;align-items:flex-end;justify-content:space-between;gap:22px;z-index:1}}.brand-mark{{display:inline-flex;align-items:center;gap:9px;border:1px solid rgba(255,255,255,.22);border-radius:999px;padding:7px 11px;background:rgba(255,255,255,.12);backdrop-filter:blur(8px);font-size:13px;color:#dbeafe}}.brand-dot{{width:9px;height:9px;border-radius:999px;background:#67e8f9;box-shadow:0 0 18px #67e8f9}}h1{{margin:14px 0 8px;font-size:32px;line-height:1.15;letter-spacing:-.03em}}.hero-subtitle{{margin:0;color:#dbeafe;line-height:1.65;max-width:740px}}.hero-actions{{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}}main{{max-width:1280px;margin:auto;padding:24px 22px 34px}}section{{background:rgba(255,255,255,.88);border:1px solid rgba(219,228,240,.95);border-radius:var(--radius);padding:20px;margin-bottom:18px;box-shadow:var(--soft-shadow);backdrop-filter:blur(10px)}}section:hover{{border-color:#cbdaf0}}h2{{margin:0 0 14px;font-size:20px;letter-spacing:-.02em}}h3{{margin:4px 0 6px;font-size:16px}}.eyebrow,.settings-kicker{{display:inline-flex;align-items:center;width:max-content;border-radius:999px;padding:4px 10px;background:#eff6ff;color:#1d4ed8;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}}.section-title-row{{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px}}textarea{{width:100%;min-height:110px;box-sizing:border-box;border:1px solid var(--line);border-radius:18px;padding:14px 16px;font-size:14px;background:#fbfdff;color:var(--text);outline:none;transition:border-color .2s,box-shadow .2s}}textarea:focus{{border-color:#60a5fa;box-shadow:0 0 0 4px rgba(37,99,235,.12)}}button,.button{{border:0;border-radius:14px;padding:10px 15px;background:linear-gradient(135deg,var(--brand),var(--brand-2));color:white;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-size:14px;font-weight:800;box-shadow:0 8px 18px rgba(37,99,235,.22);transition:transform .15s,box-shadow .15s,opacity .15s}}button:hover,.button:hover{{transform:translateY(-1px);box-shadow:0 12px 24px rgba(37,99,235,.28)}}button.secondary,.button.secondary{{background:#334155;box-shadow:0 8px 18px rgba(51,65,85,.16)}}button.danger{{background:linear-gradient(135deg,#ef4444,#dc2626);box-shadow:0 8px 18px rgba(220,38,38,.20)}}button:disabled{{opacity:.52;cursor:not-allowed;transform:none;box-shadow:none}}.primary-action{{min-width:146px}}table{{width:100%;border-collapse:separate;border-spacing:0;font-size:14px;overflow:hidden}}th,td{{border-bottom:1px solid var(--line);padding:13px 12px;text-align:left;vertical-align:top}}th{{position:sticky;top:0;background:#f8fbff;color:#475569;font-size:12px;text-transform:uppercase;letter-spacing:.04em;z-index:1}}tbody tr{{transition:background .15s,transform .15s}}tbody tr:hover{{background:#f8fbff}}small,.muted{{color:var(--muted)}}.hint{{color:var(--muted);background:#f8fafc;border:1px dashed #cbd5e1;border-radius:14px;padding:10px 12px;font-size:13px;line-height:1.6}}code{{background:#edf2f7;padding:2px 6px;border-radius:8px;color:#334155}}.badge{{display:inline-flex;align-items:center;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:800;white-space:nowrap}}.ok{{background:var(--good-bg);color:#166534}}.bad{{background:var(--bad-bg);color:#991b1b}}.warn{{background:var(--warn-bg);color:#92400e}}.unknown{{background:#e5e7eb;color:#374151}}.row{{display:flex;gap:12px;flex-wrap:wrap;align-items:center}}.alert{{padding:13px 15px;border-radius:16px;margin-bottom:16px;background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;box-shadow:var(--soft-shadow)}}.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}.card{{border:1px solid var(--line);border-radius:18px;padding:15px;background:linear-gradient(180deg,#fff,#f8fbff)}}.runtime{{display:grid;grid-template-columns:minmax(0,2fr) minmax(280px,1fr);gap:16px}}@media(max-width:900px){{.runtime{{grid-template-columns:1fr}}.hero-inner{{align-items:flex-start;flex-direction:column}}.hero-actions{{justify-content:flex-start}}.section-title-row{{display:block}}}}.progress-wrap{{height:13px;background:#e2e8f0;border-radius:999px;overflow:hidden;box-shadow:inset 0 1px 2px rgba(15,23,42,.08)}}.progress-bar{{height:100%;width:0%;background:linear-gradient(90deg,#22c55e,#0ea5e9,#2563eb);transition:width .25s}}.details-lite{{margin-top:10px}}.details-lite summary{{cursor:pointer;color:#334155;font-weight:800}}.kv{{display:grid;grid-template-columns:110px minmax(0,1fr);gap:9px;font-size:14px}}.kv span{{color:var(--muted)}}.stats,.overview-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}}.stat,.overview-card{{position:relative;overflow:hidden;background:linear-gradient(180deg,#fff,#f8fbff);border:1px solid var(--line);border-radius:18px;padding:15px;box-shadow:0 8px 18px rgba(15,23,42,.04)}}.stat b,.overview-card b{{font-size:26px;display:block;letter-spacing:-.03em}}.stat span,.overview-card span{{display:block;margin-top:4px;font-weight:800}}.overview-card small{{display:block;margin-top:6px;line-height:1.35}}.overview-card.ok{{border-color:#bbf7d0}}.overview-card.warn{{border-color:#fde68a}}.overview-card.bad{{border-color:#fecaca}}.overview-card.accent{{border-color:#bfdbfe;background:linear-gradient(180deg,#eff6ff,#fff)}}.health-strip{{height:14px;border-radius:999px;overflow:hidden;display:flex;background:#e5e7eb;border:1px solid #dbe4f0;margin:-2px 0 14px}}.health-strip span{{display:block;min-width:0}}.health-ok{{background:#22c55e}}.health-warn{{background:#f59e0b}}.health-bad{{background:#ef4444}}.health-unknown{{background:#94a3b8}}.settings-section{{background:linear-gradient(180deg,rgba(255,255,255,.94),rgba(248,251,255,.94))}}.settings-wrap{{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:14px}}.notification-panel{{grid-column:1/-1}}.settings-grid.notification-grid{{grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}}.notification-main-grid{{grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}}.notification-advanced{{margin-top:12px;border:1px dashed #cbd5e1;border-radius:18px;background:#f8fafc;overflow:hidden}}.notification-advanced summary{{cursor:pointer;list-style:none;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 15px;font-weight:900;color:#334155}}.notification-advanced summary::-webkit-details-marker{{display:none}}.notification-advanced summary::after{{content:"展开";font-size:12px;color:#1d4ed8;background:#dbeafe;border-radius:999px;padding:4px 9px}}.notification-advanced[open] summary::after{{content:"收起"}}.notification-advanced summary small{{font-weight:600;color:var(--muted)}}.notification-advanced-grid{{padding:0 12px 12px}}.settings-panel{{border:1px solid var(--line);border-radius:20px;padding:16px;background:white;box-shadow:0 8px 20px rgba(15,23,42,.045)}}.settings-panel-head p{{margin:0 0 12px;color:var(--muted);font-size:13px;line-height:1.55}}.settings-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}.settings-grid.one{{grid-template-columns:1fr}}.switch-card{{position:relative;display:flex;gap:14px;align-items:center;justify-content:space-between;border:1px solid var(--line);border-radius:18px;padding:15px;background:#f8fbff;cursor:pointer;transition:border-color .2s,background .2s,box-shadow .2s,transform .2s}}.switch-card:hover{{transform:translateY(-1px);border-color:#93c5fd;background:#eff6ff;box-shadow:0 10px 22px rgba(37,99,235,.10)}}.switch-card-disabled{{opacity:.46;filter:grayscale(.25);cursor:not-allowed;background:#f1f5f9}}.switch-card-disabled:hover{{transform:none;border-color:var(--line);background:#f1f5f9;box-shadow:none}}.switch-card input{{position:absolute;opacity:0;pointer-events:none}}.switch-text{{display:block;min-width:0}}.switch-text b{{display:block;margin-bottom:5px}}.switch-text small{{display:block;line-height:1.55;color:var(--muted)}}.switch-text em{{display:inline-flex;margin-top:9px;font-style:normal;font-size:12px;font-weight:800;color:#1d4ed8;background:#dbeafe;border-radius:999px;padding:4px 8px}}.switch-ui{{position:relative;flex:0 0 auto;width:54px;height:31px;border-radius:999px;background:#cbd5e1;transition:background .2s,box-shadow .2s}}.switch-ui::after{{content:"";position:absolute;top:3px;left:3px;width:25px;height:25px;border-radius:50%;background:white;box-shadow:0 2px 7px rgba(0,0,0,.24);transition:transform .2s}}.switch-card input:checked + .switch-ui{{background:linear-gradient(135deg,var(--brand),var(--brand-2));box-shadow:0 0 0 4px rgba(37,99,235,.12)}}.switch-card input:checked + .switch-ui::after{{transform:translateX(23px)}}.activity-list{{display:grid;gap:10px}}.activity-card{{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:14px;align-items:center;padding:13px 14px;border:1px solid var(--line);border-radius:18px;background:#fff;text-decoration:none;color:inherit;transition:transform .15s,box-shadow .15s,border-color .15s}}.activity-card:hover{{transform:translateY(-1px);border-color:#bfdbfe;box-shadow:var(--soft-shadow)}}.activity-top{{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px}}.activity-top time{{color:var(--muted);font-size:12px}}.activity-main b{{display:block;margin-bottom:4px}}.activity-main small{{display:block;line-height:1.45}}.activity-delta{{text-align:right;min-width:140px}}.activity-delta strong{{display:block;font-size:18px}}.activity-delta span{{display:block;color:var(--muted);font-size:12px;margin-top:4px}}.activity-delta.price-up strong{{color:#dc2626}}.activity-delta.price-down strong{{color:#16a34a}}.mini-btn{{display:inline-flex;align-items:center;justify-content:center;padding:7px 11px;border-radius:999px;background:#eef2ff;color:#1d4ed8;text-decoration:none;font-size:12px;font-weight:800}}.status-event{{margin-top:8px;padding:7px 9px;border-radius:12px;background:#f3f4f6;color:#374151;font-size:12px;line-height:1.35;display:inline-block}}.price-up-box{{background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;font-weight:800}}.price-down-box{{background:#dcfce7;color:#166534;border:1px solid #bbf7d0;font-weight:800}}.status-stable{{background:#f8fafc;color:#64748b}}.status-base{{background:#eef2ff;color:#3730a3}}.status-error{{background:#fee2e2;color:#991b1b}}.table-scroll{{overflow:auto;border:1px solid var(--line);border-radius:18px;background:white}}.price-cell{{white-space:nowrap;min-width:128px}}.price-chip{{display:inline-flex;flex-direction:column;align-items:flex-start;justify-content:center;min-width:104px;border:1px solid #bfdbfe;border-radius:16px;padding:8px 12px;background:linear-gradient(180deg,#eff6ff,#ffffff);box-shadow:0 8px 18px rgba(37,99,235,.12)}}.price-chip strong{{font-size:23px;line-height:1;color:#0f172a;letter-spacing:-.04em}}.price-chip small{{font-size:11px;color:#64748b;margin-top:4px;font-weight:800}}.price-mini-delta{{margin-top:7px;display:inline-flex;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:900}}.price-mini-delta.up{{background:#fee2e2;color:#b91c1c}}.price-mini-delta.down{{background:#dcfce7;color:#166534}}.price-mini-delta.warn{{background:#fef3c7;color:#92400e}}.network-alert{{margin-top:12px;border:1px solid #fed7aa;background:#fff7ed;color:#9a3412;border-radius:15px;padding:10px 12px;font-size:13px;line-height:1.55;font-weight:700}}.item-row.row-ok td:first-child{{box-shadow:inset 4px 0 #22c55e}}.item-row.row-warn td:first-child{{box-shadow:inset 4px 0 #f59e0b}}.item-row.row-bad td:first-child{{box-shadow:inset 4px 0 #ef4444}}.item-row.row-unknown td:first-child{{box-shadow:inset 4px 0 #94a3b8}}.trend-board{{display:grid;gap:16px}}.trend-card{{border:1px solid var(--line);border-radius:22px;padding:16px;background:linear-gradient(180deg,#ffffff,#f8fbff);box-shadow:0 8px 22px rgba(15,23,42,.05)}}.trend-card:target{{outline:4px solid rgba(37,99,235,.16);border-color:#60a5fa}}.trend-head{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;flex-wrap:wrap;margin-bottom:12px}}.trend-title{{font-size:17px;font-weight:900;margin-bottom:5px;letter-spacing:-.01em}}.trend-title a{{color:#111827;text-decoration:none}}.trend-title a:hover{{color:#1d4ed8}}.trend-head-meta{{display:grid;gap:6px;text-align:right;background:white;border:1px solid var(--line);border-radius:16px;padding:10px 12px}}.mini-stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-bottom:12px}}.mini-stat{{background:white;border:1px solid var(--line);border-radius:15px;padding:10px}}.mini-stat b{{display:block;font-size:18px;letter-spacing:-.02em}}.mini-stat span{{font-size:12px;color:var(--muted)}}.trend-chart-wrap{{border:1px solid var(--line);border-radius:18px;padding:12px;background:white;overflow-x:auto}}.trend-svg{{width:100%;height:auto;display:block;min-width:720px}}.grid-line{{stroke:#e5e7eb;stroke-width:1}}.axis-line{{stroke:#94a3b8;stroke-width:1.2}}.axis-label{{fill:#64748b;font-size:11px}}.tick-line{{stroke:#cbd5e1;stroke-width:1}}.tick-label{{fill:#64748b;font-size:10px;font-weight:700}}.price-line{{fill:none;stroke:#2563eb;stroke-width:3;stroke-linejoin:round;stroke-linecap:round}}.price-dot{{stroke:#fff;stroke-width:1.5}}.price-up{{fill:#dc2626}}.price-down{{fill:#16a34a}}.price-neutral{{fill:#2563eb}}.status-seg.seg-ok{{fill:#bbf7d0}}.status-seg.seg-bad{{fill:#fecaca}}.status-seg.seg-warn{{fill:#fde68a}}.status-seg.seg-unknown{{fill:#e5e7eb}}.status-link{{stroke:#94a3b8;stroke-width:1;stroke-dasharray:3 2}}.status-marker{{fill:#7c3aed;stroke:white;stroke-width:1}}.trend-legend{{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-top:10px}}.trend-legend span{{display:inline-flex;align-items:center;gap:6px}}.legend-line{{display:inline-block;width:20px;height:0;border-top:3px solid #2563eb}}.legend-dot{{display:inline-block;width:10px;height:10px;border-radius:999px}}.legend-diamond{{display:inline-block;width:10px;height:10px;background:#7c3aed;transform:rotate(45deg)}}.legend-band{{display:inline-block;width:18px;height:10px;border-radius:4px}}.legend-band.seg-ok{{background:#bbf7d0}}.legend-band.seg-bad{{background:#fecaca}}.legend-band.seg-warn{{background:#fde68a}}.footer{{max-width:1280px;margin:0 auto 24px;color:var(--muted);font-size:12px;padding:16px 22px;text-align:center}}@media(max-width:720px){{main{{padding:16px 12px}}section{{padding:16px;border-radius:18px}}h1{{font-size:25px}}.activity-card{{grid-template-columns:1fr}}.activity-delta{{text-align:left}}.trend-head-meta{{text-align:left;width:100%}}}}
</style></head><body><header class="hero"><div class="hero-inner"><div><div class="brand-mark"><span class="brand-dot"></span>本地监控面板 · {PROGRAM_VERSION}</div><h1>闲鱼商品监控控制台</h1><p class="hero-subtitle">只监听 127.0.0.1。打开本面板后会自动启动后台长期监控；浏览器放到后台不会再自动关闭本地面板。</p></div><div class="hero-actions"><a class="button" href="#items">查看商品</a><a class="button secondary" href="#settings">设置中心</a><a class="button secondary" href="/tools" target="_blank">日志工具</a></div></div></header><main>
{f'<div class="alert">{escape(msg)}</div>' if msg else ''}
<section><div class="section-title-row"><div><span class="eyebrow">Runtime</span><h2>运行状态</h2></div><p class="muted">自动刷新；用于判断后台是否在跑、当前轮次是否卡住。浏览器后台心跳暂停不会再触发自动退出。</p></div><div class="runtime"><div class="card"><div class="row"><span id="rt-state" class="badge {escape(rt['state_class'])}">{escape(rt['state_label'])}</span><b id="rt-message">{escape(compact(rt['runtime'].get('last_message') or '-'))}</b></div><p class="muted">打开本面板后会自动启动后台长期监控；点击“立即检测一轮”会跳过下一轮等待，或在当前轮结束后马上再检测。</p><div class="progress-wrap"><div id="rt-progress" class="progress-bar" style="width:{rt['progress_percent']}%"></div></div><p class="muted"><span id="rt-progress-label">{escape(str(rt.get('progress_label') or "进度"))}</span></p><p><span id="rt-progress-text">{escape(str(rt.get('progress_text') or "-"))}</span></p><div id="rt-network-alert" class="network-alert" style="display:{'block' if rt.get('network_alert_active') else 'none'}"><span id="rt-network-alert-text">{escape(str(rt.get('network_alert_text') or ''))}</span></div></div><div class="card kv"><span>阶段</span><b id="rt-phase">{escape(str(rt['runtime'].get('phase_label') or '-'))}</b><span>本轮</span><b id="rt-round">{escape(str(rt['runtime'].get('round_no') or '-'))}</b><span>当前商品</span><b id="rt-current">{escape(compact(rt['runtime'].get('current_title') or rt['runtime'].get('current_item_id') or rt['runtime'].get('current_url') or '-', 54))}</b><span>当前等待</span><b id="rt-delay">{escape(str(rt.get('delay_remaining_text') or '-'))}</b><span>下次监测</span><b id="rt-next-round">{escape(str(rt.get('next_round_text') or '-'))}</b><span>状态更新</span><b id="rt-heartbeat">{escape(str(rt['last_update_text']))}</b></div></div></section>
<section><div class="section-title-row"><div><span class="eyebrow">Dashboard</span><h2>基础数据</h2></div><p class="muted">数字用于快速确认监控范围和历史积累。</p></div><div class="stats"><div class="stat"><b>{len(links)}</b><span>监控链接</span></div><div class="stat"><b>{len(state)}</b><span>历史状态基准</span></div><div class="stat"><b>{len(hist)}</b><span>历史事件</span></div><div class="stat"><b>{escape(str(meta.get('total_rounds') or 0))}</b><span>历史总轮次</span></div><div class="stat"><b id="rt-web">{'运行中' if rt['web_trigger_running'] else '未运行'}</b><span>后台长期监控</span></div></div><p class="muted">后台进程：开始 <span id="rt-web-start">{escape(LAST_RUN_STARTED_AT or '-')}</span>；结束 <span id="rt-web-end">{escape(LAST_RUN_FINISHED_AT or '-')}</span></p><div class="row"><form method="post" action="/run_once"><button id="run-once-btn" {disabled}>立即检测一轮 / 重置倒计时</button></form><form method="post" action="/stop_monitor" onsubmit="return confirm('确认停止网页面板管理的后台长期监控？');"><button class="secondary" id="stop-monitor-btn" {stop_disabled}>停止后台监控</button></form><a class="button secondary" href="/">刷新整页</a><a class="button secondary" href="/tools" target="_blank">打开日志 / 状态文件合集</a><form method="post" action="/shutdown" onsubmit="return confirm('关闭本地网页面板并停止后台监控？这不会删除任何文件。');"><button class="danger">关闭本地面板</button></form></div></section>
{status_overview_html()}
<section class="settings-section" id="settings"><div class="section-title-row"><div><span class="eyebrow">Settings</span><h2>设置中心</h2></div><p class="muted">通知和显示设置集中管理；所有开关都遵循“先调整，再保存，再刷新/生效”。</p></div><div class="settings-wrap">{notification_settings_html()}{browser_mode_settings_html()}</div></section>
<section><div class="section-title-row"><div><span class="eyebrow">Links</span><h2>添加链接</h2></div><p class="muted">支持分享文本、短链、商品链接和商品 ID。</p></div><form method="post" action="/add"><textarea name="text" placeholder="直接粘贴闲鱼分享文本、m.tb.cn 短链、goofish 商品链接，或商品 ID。支持一次粘贴多行。"></textarea><p><button>提取并添加</button></p></form></section>
<section id="items"><div class="section-title-row"><div><span class="eyebrow">Items</span><h2>当前监控商品</h2></div><p class="muted">左侧颜色条表示状态风险；“上次检测”显示最近一轮发生的事情。</p></div><form method="post" action="/delete"><div class="table-scroll"><table><thead><tr><th>选</th><th>#</th><th>商品ID</th><th>链接 / 标题</th><th>状态</th><th>价格</th><th>检测次数</th><th>检查时间</th><th>走势</th></tr></thead><tbody id="items-body">{item_rows()}</tbody></table></div><p><button class="danger">删除选中链接</button></p></form><form method="post" action="/clear" onsubmit="return confirm('确认清空所有监控链接？历史 data 不会删除。');"><button class="danger">清空所有链接</button></form></section>
<section><div class="section-title-row"><div><span class="eyebrow">Trends</span><h2>商品趋势看板</h2></div><p class="muted">价格变动与状态变动已整合到每个商品的趋势图中。</p></div><div id="trend-board" class="trend-board">{trend_cards_html()}</div></section>
<section><details class="details-lite"><summary>本轮调试摘要（按需展开）</summary>{last_round_html()}</details></section>
</main><div class="footer">本面板不写注册表、不创建服务、不设置开机自启。为避免浏览器后台误判退出，关闭浏览器标签页不会自动停止程序；请点击“停止后台监控”或“关闭本地面板”来结束。</div>
<script>
function sendPanelHeartbeat() {{
  fetch('/api/page_heartbeat', {{method: 'POST', cache: 'no-store'}}).catch(() => {{}});
}}
sendPanelHeartbeat();
setInterval(sendPanelHeartbeat, 5000);
// v0.7.4: do not auto-close the dashboard when the browser tab is hidden,
// backgrounded, memory-saved, or temporarily frozen. Use the close button to stop.
function updateSwitchText(input) {{
  const card = input.closest('.switch-card');
  const em = card ? card.querySelector('.switch-text em') : null;
  if (em) em.textContent = input.checked ? '已开启' : '已关闭';
}}
function syncNotificationSettings() {{
  const master = document.getElementById('notification_enabled_switch');
  const children = document.querySelectorAll('input[data-notification-child="1"]');
  const enabled = !master || master.checked;
  children.forEach((input) => {{
    const card = input.closest('.switch-card');
    if (!enabled) input.checked = false;
    input.disabled = !enabled;
    if (card) card.classList.toggle('switch-card-disabled', !enabled);
    updateSwitchText(input);
  }});
  if (master) updateSwitchText(master);
}}
document.querySelectorAll('#notification-panel .switch-card input[type="checkbox"]').forEach((input) => {{
  input.addEventListener('change', () => {{
    updateSwitchText(input);
    if (input.id === 'notification_enabled_switch') syncNotificationSettings();
  }});
}});
syncNotificationSettings();
function setText(id, text) {{ const el = document.getElementById(id); if (el) el.textContent = text; }}
function setBadge(id, text, cls) {{ const el = document.getElementById(id); if (el) {{ el.textContent = text; el.className = 'badge ' + cls; }} }}
async function updateRuntime() {{
  try {{
    const res = await fetch('/api/runtime_status', {{cache: 'no-store'}});
    const data = await res.json();
    const r = data.runtime || {{}};
    setBadge('rt-state', data.state_label || '-', data.state_class || 'unknown');
    setText('rt-message', r.last_message || '-');
    setText('rt-phase', r.phase_label || '-');
    setText('rt-round', r.round_no || '-');
    setText('rt-current', r.current_title || r.current_item_id || r.current_url || '-');
    setText('rt-delay', data.delay_remaining_text || '-');
    setText('rt-next-round', data.next_round_text || '-');
    setText('rt-heartbeat', data.last_update_text || '-');
    setText('rt-progress-label', data.progress_label || '进度');
    setText('rt-progress-text', data.progress_text || ((r.current_index || 0) + ' / ' + (r.total || 0)));
    setText('rt-web', data.web_trigger_running ? '运行中' : '未运行');
    setText('rt-web-start', data.last_run_started_at || '-');
    setText('rt-web-end', data.last_run_finished_at || '-');
    const bar = document.getElementById('rt-progress'); if (bar) bar.style.width = (data.progress_percent || 0) + '%';
    const netBox = document.getElementById('rt-network-alert');
    if (netBox) netBox.style.display = data.network_alert_active ? 'block' : 'none';
    setText('rt-network-alert-text', data.network_alert_text || '');
    const btn = document.getElementById('run-once-btn'); if (btn) btn.disabled = !!data.button_disabled;
    const stopBtn = document.getElementById('stop-monitor-btn'); if (stopBtn) stopBtn.disabled = !data.web_trigger_running;
  }} catch (err) {{}}
}}
async function updateItems() {{
  try {{
    const body = document.getElementById('items-body');
    if (!body) return;
    const checked = new Set(Array.from(body.querySelectorAll('input[name="idx"]:checked')).map(x => x.value));
    const res = await fetch('/api/items', {{cache: 'no-store'}});
    const data = await res.json();
    if (typeof data.rows === 'string') {{
      body.innerHTML = data.rows;
      for (const value of checked) {{
        const box = body.querySelector('input[name="idx"][value="' + CSS.escape(value) + '"]');
        if (box) box.checked = true;
      }}
    }}
  }} catch (err) {{}}
}}
async function updateTrends() {{
  try {{
    const board = document.getElementById('trend-board');
    if (!board) return;
    const res = await fetch('/api/trends', {{cache: 'no-store'}});
    const data = await res.json();
    if (typeof data.html === 'string') {{
      board.innerHTML = data.html;
    }}
  }} catch (err) {{}}
}}
updateRuntime();
updateItems();
updateTrends();
setInterval(updateRuntime, 1000);
setInterval(updateItems, 3000);
setInterval(updateTrends, 10000);
</script></body></html>'''


def safe_file(path_text: str) -> Path | None:
    path_text = unquote(path_text or "").replace("\\", "/")
    candidate = (ROOT / path_text).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except Exception:
        return None
    return candidate if candidate.exists() and candidate.is_file() else None


class Handler(BaseHTTPRequestHandler):
    server_version = "xy-monitor-dashboard/0.7.0-polished-ui"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def send_html(self, html: str, status: int = 200) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def redirect(self, msg: str = "") -> None:
        loc = "/" + (("?msg=" + quote(msg)) if msg else "")
        self.send_response(303)
        self.send_header("Location", loc)
        self.end_headers()

    def form(self) -> dict[str, list[str]]:
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length).decode("utf-8", errors="ignore")
        return parse_qs(raw, keep_blank_values=True)

    def do_GET(self) -> None:  # noqa: N802
        ensure_dirs()
        parsed = urlparse(self.path)
        if parsed.path == "/":
            msg = parse_qs(parsed.query).get("msg", [""])[0]
            self.send_html(dashboard(msg))
            return
        if parsed.path == "/api/runtime_status":
            self.send_json(api_runtime_payload())
            return
        if parsed.path == "/api/items":
            self.send_json(api_items_payload())
            return
        if parsed.path == "/api/trends":
            self.send_json(api_trends_payload())
            return
        if parsed.path == "/api/notification_settings":
            self.send_json(notification_settings_payload())
            return
        if parsed.path == "/api/browser_mode_settings":
            self.send_json(browser_mode_settings_payload())
            return
        if parsed.path == "/tools":
            self.send_html(tools_page_html())
            return
        if parsed.path == "/file":
            p = safe_file(parse_qs(parsed.query).get("path", [""])[0])
            if not p:
                self.send_html("<h1>文件不存在或路径不允许</h1>", HTTPStatus.NOT_FOUND)
                return
            text = p.read_text(encoding="utf-8", errors="ignore")
            rel = p.relative_to(ROOT)
            self.send_html(f"<!doctype html><meta charset='utf-8'><title>{escape(str(rel))}</title><style>body{{font-family:Consolas,monospace;padding:16px;white-space:pre-wrap}}</style><h2>{escape(str(rel))}</h2>{escape(text)}")
            return
        self.send_html("<h1>Not found</h1>", HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        ensure_dirs()
        parsed = urlparse(self.path)
        if parsed.path == "/api/page_heartbeat":
            try:
                self.rfile.read(int(self.headers.get("Content-Length") or 0))
            except Exception:
                pass
            record_page_heartbeat()
            self.send_json({"ok": True, "message": "heartbeat recorded"})
            return
        if parsed.path == "/api/page_closed":
            try:
                self.rfile.read(int(self.headers.get("Content-Length") or 0))
            except Exception:
                pass
            mark_page_closing()
            self.send_json({"ok": True, "message": "close noted"})
            return
        form = self.form()
        try:
            if parsed.path == "/add":
                text = "\n".join(form.get("text", []))
                added, skipped = link_manager.add_links_from_text(text)
                if added:
                    start_background_monitor("links_added")
                self.redirect(f"添加 {len(added)} 个链接，跳过重复 {len(skipped)} 个。" if (added or skipped) else "没有识别到有效链接或商品 ID。")
                return
            if parsed.path == "/delete":
                links = link_manager.read_links()
                nums = sorted({int(x) for x in form.get("idx", []) if str(x).isdigit()}, reverse=True)
                removed = 0
                for n in nums:
                    if 1 <= n <= len(links):
                        links.pop(n - 1)
                        removed += 1
                if removed:
                    link_manager.write_links(links)
                self.redirect(f"已删除 {removed} 个链接。")
                return
            if parsed.path == "/clear":
                link_manager.write_links([])
                self.redirect("已清空 links.txt。历史 data 没有删除。")
                return
            if parsed.path == "/notification_settings":
                config = read_config()
                master_enabled = "notification_enabled" in form
                for key, _title, _desc, _default in NOTIFICATION_SWITCHES:
                    if key == "notification_enabled":
                        config[key] = master_enabled
                    elif not master_enabled:
                        config[key] = False
                    else:
                        config[key] = key in form
                write_config(config)
                up_text = "开启" if config.get("notify_price_up") else "关闭"
                network_text = "开启" if config.get("notify_network_errors") else "关闭"
                popup_text = "开启" if config.get("notification_popup_fallback") else "关闭"
                master_text = "开启" if master_enabled else "关闭，其余通知已全部关闭"
                self.redirect(f"通知设置已保存：总开关 {master_text}；涨价通知 {up_text}；网络异常通知 {network_text}；重要弹窗兜底 {popup_text}。")
                return
            if parsed.path == "/browser_mode_settings":
                config = read_config()
                real_browser = "real_browser" in form
                config["headless"] = not real_browser
                if not real_browser:
                    config["silent_browser_strategy"] = "hidden_window"
                write_config(config)
                mode_text = "开启真实浏览器检测" if real_browser else "关闭真实浏览器，改为隐藏窗口静默检测"
                self.redirect(f"浏览器显示设置已保存：{mode_text}。黑色命令行窗口仍默认隐藏；若后台监控正在运行，新设置会在下一轮检测前生效。")
                return
            if parsed.path == "/run_once":
                self.redirect(request_immediate_round())
                return
            if parsed.path == "/stop_monitor":
                self.redirect(stop_current_monitor_from_dashboard())
                return
            if parsed.path == "/shutdown":
                stop_current_monitor_from_dashboard()
                self.send_html("<!doctype html><meta charset='utf-8'><title>正在关闭</title><body style='font-family:Microsoft YaHei,Arial;padding:24px'><h2>本地网页面板正在关闭</h2><p>后台监控也已请求停止，可以关闭这个浏览器标签页。</p></body>")
                threading.Thread(target=lambda: (time.sleep(0.3), self.server.shutdown()), daemon=True).start()
                return
            self.redirect("未知操作。")
        except Exception as exc:
            self.redirect(f"操作失败：{exc}")


def main() -> int:
    ensure_dirs()
    url = f"http://{HOST}:{PORT}/"
    print("=" * 70)
    print(f"xy-monitor local web dashboard {PROGRAM_VERSION}")
    print("=" * 70)
    print(f"Local URL: {url}")
    print("This dashboard only binds to 127.0.0.1.")
    print("The dashboard will start the long-running monitor automatically.")
    print("Keep this command window open while monitoring. To stop safely, click the dashboard close button or close this command window.")
    print("=" * 70)

    startup_cleanup_messages = cleanup_stale_monitor_artifacts("dashboard_startup")
    for msg in startup_cleanup_messages:
        print(f"[恢复] {msg}")

    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print()
        print(f"[提示] 无法监听 {HOST}:{PORT}：{exc}")
        print("本地面板可能已经在运行。将尝试打开已有面板：")
        print(url)
        try:
            webbrowser.open(url)
        except Exception:
            pass
        return 0

    record_page_heartbeat()
    start_background_monitor("dashboard_startup")
    threading.Thread(target=lambda: (time.sleep(0.8), webbrowser.open(url)), daemon=True).start()
    # v0.7.4: no heartbeat watchdog; background tabs must not shut down the app.
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        global SERVER_SHUTTING_DOWN
        SERVER_SHUTTING_DOWN = True
        stop_current_monitor_from_dashboard()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
