# app

这里存放核心 Python 程序。一般用户不需要直接进入此目录运行文件，直接双击根目录的 `.bat` 即可。

- `monitor.py`：核心监控
- `web_dashboard.py`：本地网页面板
- `link_manager.py`：链接管理
- `login.py`：保存登录态
- `test_notification.py`：测试通知
