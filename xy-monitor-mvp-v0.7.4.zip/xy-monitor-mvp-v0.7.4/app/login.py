from __future__ import annotations


def configure_console_utf8() -> None:
    """Prevent Windows GBK console/log redirection from crashing on Unicode text."""
    import os
    import sys
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


configure_console_utf8()


import json
import sys
from pathlib import Path
from typing import Any

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
DATA_DIR = ROOT / "data"
AUTH_STATE = DATA_DIR / "auth_state.json"
CONFIG_FILE = ROOT / "config.json"
GOOFISH_HOME = "https://www.goofish.com/"


def load_config() -> dict[str, Any]:
    default = {
        "headless": False,
        "page_timeout_ms": 60000,
        "post_load_wait_seconds": 3,
    }
    if not CONFIG_FILE.exists():
        return default
    try:
        user_config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(user_config, dict):
            default.update(user_config)
    except Exception as exc:
        print(f"[警告] config.json 读取失败，将使用默认配置：{exc}")
    return default


def save_storage_state(context) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    # Playwright 新版本支持 indexed_db=True。若用户本机版本较旧，则自动退回普通 storage_state。
    try:
        context.storage_state(path=str(AUTH_STATE), indexed_db=True)
    except TypeError:
        context.storage_state(path=str(AUTH_STATE))


def main() -> int:
    config = load_config()
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("闲鱼价格监控 MVP v0.6.4 - 登录态保存")
    print("=" * 70)
    print("即将打开浏览器。请在浏览器中完成闲鱼登录。")
    print("登录成功后，回到这个黑色窗口，按 Enter 保存登录状态。")
    print("注意：data/auth_state.json 等同于登录凭证，不要发给别人。")
    print()

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context(locale="zh-CN", viewport={"width": 1280, "height": 900})
        page = context.new_page()
        page.set_default_timeout(int(config["page_timeout_ms"]))

        try:
            page.goto(GOOFISH_HOME, wait_until="domcontentloaded", timeout=int(config["page_timeout_ms"]))
        except PlaywrightTimeoutError:
            print("[警告] 页面打开超时，但浏览器已打开。你仍可尝试手动刷新并登录。")

        input("确认已经登录后，按 Enter 保存登录状态；如果还没登录，请先在浏览器里完成登录：")
        save_storage_state(context)
        browser.close()

    if AUTH_STATE.exists():
        print(f"[完成] 登录状态已保存：{AUTH_STATE}")
        print("下一步：把商品链接放入 links.txt，然后运行 dashboard.bat；网页会自动启动长期监控。")
        return 0

    print("[失败] 未能生成 data/auth_state.json。")
    return 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[已取消] 用户中断。")
        raise SystemExit(130)
    except Exception as exc:
        print(f"\n[错误] login.py 运行失败：{exc}")
        raise SystemExit(1)
