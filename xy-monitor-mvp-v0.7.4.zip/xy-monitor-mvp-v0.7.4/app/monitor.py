from __future__ import annotations

import json
import os
import platform
import random
import re
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

try:
    from winotify import Notification, audio
    WINOTIFY_AVAILABLE = True
except Exception:
    Notification = None
    audio = None
    WINOTIFY_AVAILABLE = False

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright


def configure_console_utf8() -> None:
    """Prevent Windows GBK console/log redirection from crashing on Unicode text."""
    import os
    import sys
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


configure_console_utf8()

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
DATA_DIR = ROOT / "data"
LOG_DIR = ROOT / "logs"
AUTH_STATE = DATA_DIR / "auth_state.json"
CONFIG_FILE = ROOT / "config.json"
LINKS_FILE = ROOT / "links.txt"
DEBUG_HTML = LOG_DIR / "last_page_debug.html"
DEBUG_JSON = LOG_DIR / "last_candidates_debug.json"
LAST_ROUND_DEBUG = LOG_DIR / "last_round_debug.json"
DEBUG_ITEMS_DIR = LOG_DIR / "debug_items"
LOG_FILE = LOG_DIR / "monitor.log"
STATE_FILE = DATA_DIR / "state.json"
HISTORY_FILE = DATA_DIR / "history.jsonl"
NOTIFICATION_LOG_FILE = DATA_DIR / "notifications.jsonl"
RUN_META_FILE = DATA_DIR / "run_meta.json"
RUNTIME_STATUS_FILE = DATA_DIR / "runtime_status.json"
MONITOR_LOCK_FILE = DATA_DIR / "monitor.lock"
CONTROL_FILE = DATA_DIR / "monitor_control.json"
PROGRAM_VERSION = "v0.7.4"
MONITOR_LOCK_STALE_SECONDS = 15 * 60
_RUNTIME_STATUS: dict[str, Any] = {}
_LOCK_HELD = False
GOOFISH_HOME = "https://www.goofish.com/"
LOGIN_CHECK_DEBUG = LOG_DIR / "last_login_check_debug.json"

STATUS_NORMAL = "NORMAL"
STATUS_SOLD = "SOLD"
STATUS_REMOVED = "REMOVED"
STATUS_LOGIN_REQUIRED = "LOGIN_REQUIRED"
STATUS_VERIFY_REQUIRED = "VERIFY_REQUIRED"
STATUS_LOAD_FAILED = "LOAD_FAILED"
STATUS_UNKNOWN = "UNKNOWN"
STATUS_NETWORK_ERROR = "NETWORK_ERROR"

LOGIN_URL_KEYWORDS = ["login", "member", "passport", "taobao.com/member"]
LOGIN_TEXT_KEYWORDS = ["扫码登录", "密码登录", "手机号登录", "账号登录", "短信登录", "请先登录", "登录后查看", "立即登录"]
LOGIN_ACTION_KEYWORDS = ["登录", "登录/注册", "立即登录", "请登录", "扫码登录", "密码登录", "手机号登录", "账号登录", "短信登录", "淘宝登录", "支付宝登录"]
VERIFY_KEYWORDS = ["安全验证", "验证码", "拖动滑块", "滑块", "访问异常", "请完成验证", "人机验证", "验证中心"]
REMOVED_KEYWORDS = ["商品不存在", "宝贝不存在", "该商品已下架", "已下架", "页面不存在", "来晚了", "链接已失效"]
SOLD_KEYWORDS = [
    "已卖出", "已售", "卖掉了", "交易成功", "商品已被拍下", "该商品已售出",
    "宝贝已卖出", "该宝贝已卖出", "商品已卖出", "已被买走", "已售出啦",
    "商品已交易", "暂不可购买", "当前商品不可购买", "商品已售罄",
]
NORMAL_ACTION_KEYWORDS = ["立即购买", "APP下单", "App下单", "我想要", "聊一聊", "收藏"]

GENERIC_TITLES = {
    "为你推荐", "猜你喜欢", "相关推荐", "看了又看", "更多推荐", "相关商品",
    "首页", "搜索", "消息", "我的", "发布", "立即购买", "我想要", "闲鱼",
    "goofish", "goofish - 闲鱼", "闲鱼 - 闲不住？上闲鱼！",
}

BAD_TITLE_KEYWORDS = [
    "登录", "注册", "安全验证", "验证码", "为你推荐", "猜你喜欢", "相关推荐",
    "看了又看", "更多推荐", "相关商品", "打开 app", "下载 app",
]


@dataclass
class ProductSnapshot:
    url: str
    status: str
    title: str | None
    price: float | None
    reason: str
    captured_at: str
    is_buyable: bool | None = None
    buyability_reason: str | None = None


@dataclass
class LoginCheckResult:
    ok: bool
    status: str
    reason: str
    final_url: str
    evidence: dict[str, Any]


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    DEBUG_ITEMS_DIR.mkdir(parents=True, exist_ok=True)


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    ensure_dirs()
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def is_lock_stale(path: Path, stale_seconds: int = MONITOR_LOCK_STALE_SECONDS) -> bool:
    try:
        age = time.time() - path.stat().st_mtime
        return age > max(60, int(stale_seconds))
    except Exception:
        return True


def process_exists(pid: Any) -> bool | None:
    """Return whether a PID still exists.

    Used to clean monitor.lock left behind when the command window is closed
    while the monitor is sleeping between rounds.
    """
    try:
        pid_int = int(pid)
    except Exception:
        return None
    if pid_int <= 0:
        return None
    if pid_int == os.getpid():
        return True

    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            kernel32 = ctypes.windll.kernel32
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            SYNCHRONIZE = 0x00100000
            WAIT_TIMEOUT = 0x00000102
            WAIT_OBJECT_0 = 0x00000000
            WAIT_FAILED = 0xFFFFFFFF

            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid_int)
            if not handle:
                return kernel32.GetLastError() == 5
            try:
                rc = kernel32.WaitForSingleObject(handle, 0)
                if rc == WAIT_TIMEOUT:
                    return True
                if rc == WAIT_OBJECT_0:
                    return False
                if rc == WAIT_FAILED:
                    return None
                return None
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return None

    try:
        os.kill(pid_int, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return None


def touch_monitor_lock() -> None:
    if not _LOCK_HELD:
        return
    try:
        payload = {
            "program_version": PROGRAM_VERSION,
            "pid": os.getpid(),
            "updated_at": now_str(),
            "updated_ts": time.time(),
        }
        atomic_write_json(MONITOR_LOCK_FILE, payload)
    except Exception:
        pass


def write_runtime_status(**fields: Any) -> None:
    """Write a small runtime status file for the local dashboard.

    This only touches data/runtime_status.json inside the project folder.
    The dashboard reads it to show progress, countdowns and idle/error states.
    """
    global _RUNTIME_STATUS
    payload = dict(_RUNTIME_STATUS)
    payload.update(fields)

    phase = str(payload.get("phase") or "")
    if phase != "ROUND_DELAY":
        payload["next_round_at"] = ""
        payload["next_round_at_ts"] = 0
        payload["next_round_remaining_seconds"] = 0
    if phase not in {"ITEM_DELAY", "ROUND_DELAY"}:
        payload["delay_until_at"] = ""
        payload["delay_until_ts"] = 0

    payload.setdefault("running", True)
    payload.setdefault("program_version", PROGRAM_VERSION)
    payload["pid"] = os.getpid()
    payload["updated_at"] = now_str()
    payload["updated_ts"] = time.time()
    _RUNTIME_STATUS = payload
    try:
        atomic_write_json(RUNTIME_STATUS_FILE, payload)
        touch_monitor_lock()
    except Exception:
        # Runtime status is only for UI feedback; monitoring should continue even if it fails.
        pass




def read_control_file() -> dict[str, Any]:
    """Read dashboard control requests.

    The dashboard writes this small JSON file instead of starting a second
    monitor process. monitor.py consumes the request from the long-running loop.
    """
    try:
        if not CONTROL_FILE.exists():
            return {}
        data = json.loads(CONTROL_FILE.read_text(encoding="utf-8", errors="ignore"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_control_file(payload: dict[str, Any]) -> None:
    try:
        atomic_write_json(CONTROL_FILE, payload)
    except Exception as exc:
        log(f"[警告] 写入 monitor_control.json 失败：{exc}")


def has_immediate_round_request() -> bool:
    control = read_control_file()
    return bool(control.get("immediate_round_requested"))


def consume_immediate_round_request(message: str = "已收到手动立即检测请求") -> bool:
    """Consume one dashboard 'run now' request if present."""
    control = read_control_file()
    if not bool(control.get("immediate_round_requested")):
        return False
    control["immediate_round_requested"] = False
    control["last_consumed_at"] = now_str()
    control["last_consumed_ts"] = time.time()
    control["last_consume_message"] = message
    write_control_file(control)
    log(message)
    return True


def has_stop_request() -> bool:
    """Return whether the dashboard requested a safe stop.

    This is intentionally separate from killing the process.  It lets monitor.py
    finish the current safe checkpoint first, so opening the dashboard and
    immediately closing it will not leave all items as UNKNOWN/未识别.
    """
    control = read_control_file()
    return bool(control.get("stop_requested"))


def consume_stop_request(message: str = "已收到安全停止请求") -> bool:
    """Consume one dashboard safe-stop request if present."""
    control = read_control_file()
    if not bool(control.get("stop_requested")):
        return False
    control["stop_requested"] = False
    control["last_stop_consumed_at"] = now_str()
    control["last_stop_consumed_ts"] = time.time()
    control["last_stop_consume_message"] = message
    write_control_file(control)
    log(message)
    return True

def clear_runtime_status(exit_code: int = 0, message: str = "监控进程已停止") -> None:
    payload = dict(_RUNTIME_STATUS)
    payload.update({
        "running": False,
        "phase": "IDLE",
        "phase_label": "空闲",
        "last_message": message,
        "exit_code": exit_code,
        "delay_seconds": 0,
        "delay_remaining_seconds": 0,
        "finished_at": now_str(),
    })
    try:
        write_runtime_status(**payload)
    except Exception:
        pass


def acquire_monitor_lock() -> bool:
    """Prevent multiple monitor.py processes from writing state/history at the same time."""
    global _LOCK_HELD
    ensure_dirs()
    if MONITOR_LOCK_FILE.exists():
        try:
            info = json.loads(MONITOR_LOCK_FILE.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            info = {}
        updated = info.get("updated_at") or "未知时间"
        pid = info.get("pid") or "未知 PID"
        pid_alive = process_exists(pid)

        if is_lock_stale(MONITOR_LOCK_FILE) or pid_alive is False:
            try:
                MONITOR_LOCK_FILE.unlink()
                if pid_alive is False:
                    log(f"发现残留 monitor.lock：PID {pid} 已不存在，已自动清理。")
                else:
                    log("发现过期 monitor.lock，已自动清理。")
            except Exception as exc:
                log(f"[错误] monitor.lock 已失效但无法清理：{exc}")
                return False
        else:
            log(f"[错误] 已有 monitor.py 正在运行或刚刚运行过（PID: {pid}，最近状态更新: {updated}）。为避免重复写入，本次退出。")
            return False
    try:
        fd = os.open(str(MONITOR_LOCK_FILE), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        payload = {
            "program_version": PROGRAM_VERSION,
            "pid": os.getpid(),
            "created_at": now_str(),
            "created_ts": time.time(),
            "updated_at": now_str(),
            "updated_ts": time.time(),
        }
        os.write(fd, json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"))
        os.close(fd)
        _LOCK_HELD = True
        return True
    except FileExistsError:
        log("[错误] 已有 monitor.py 正在运行。")
        return False
    except Exception as exc:
        log(f"[错误] 创建 monitor.lock 失败：{exc}")
        return False


def release_monitor_lock() -> None:
    global _LOCK_HELD
    if not _LOCK_HELD:
        return
    try:
        MONITOR_LOCK_FILE.unlink(missing_ok=True)
    except Exception as exc:
        log(f"[警告] 删除 monitor.lock 失败：{exc}")
    finally:
        _LOCK_HELD = False


def log(message: str) -> None:
    ensure_dirs()
    line = f"[{now_str()}] {message}"
    print(line)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_json_file(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    if not path.exists():
        return dict(default)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            merged = dict(default)
            merged.update(value)
            return merged
        log(f"[警告] {path.name} 不是 JSON 对象，使用默认配置。")
    except Exception as exc:
        log(f"[警告] {path.name} 读取失败，使用默认配置：{exc}")
    return dict(default)


def load_config() -> dict[str, Any]:
    return load_json_file(
        CONFIG_FILE,
        {
            "headless": True,
            "silent_browser_strategy": "hidden_window",
            "page_timeout_ms": 60000,
            "post_load_wait_seconds": 3,
            "save_debug_html": True,
            "debug_html_max_chars": 300000,
            "interval_min_seconds": 300,
            "interval_max_seconds": 480,
            "per_item_delay_min_seconds": 3,
            "per_item_delay_max_seconds": 8,
            "browser_restart_every_rounds": 10,
            "max_failures_before_alert": 3,
            "run_once": False,
            "login_check_enabled": True,
            "login_check_url": GOOFISH_HOME,
            "login_check_wait_seconds": 2,
            "notification_enabled": True,
            "notify_status_change": True,
            "notify_price_down": True,
            "notify_price_up": True,
            "notify_title_change": True,
            "notify_sold": True,
            "notify_removed": True,
            "notify_login_required": True,
            "notify_verify_required": True,
            "notify_failures": True,
            "notify_network_errors": True,
            "notify_network_errors_every_round": True,
            "notification_popup_fallback": True,
            "notify_not_buyable": True,
            "notify_not_buyable_every_round": False,
            "notify_not_buyable_on_first_seen": True,
            "notify_not_buyable_for_load_failed": False,
            "notify_round_complete": True,
            "notification_add_open_button": True,
            "require_buy_button_for_normal": False,
            "debug_status_evidence": True,
            "save_per_item_debug": True,
            "save_last_round_debug": True,
        },
    )


def launch_monitor_browser(playwright, config: dict[str, Any]):
    """Launch Chromium according to the dashboard display setting.

    `headless=false` means the user explicitly wants to see the real browser.
    `headless=true` previously used Playwright's true headless mode, but the
    Xianyu/Goofish pages can render as abnormal there.  The safer quiet mode is
    therefore a real headed browser placed off-screen/minimized, so the page
    behaves like the visible mode while avoiding a distracting window.
    """
    logical_headless = bool(config.get("headless", True))
    if not logical_headless:
        return playwright.chromium.launch(headless=False)

    strategy = str(config.get("silent_browser_strategy") or "hidden_window").strip().lower()
    if strategy in {"hidden_window", "offscreen", "hidden", "minimized"}:
        args = [
            "--window-size=1280,900",
            "--window-position=-32000,-32000",
            "--start-minimized",
        ]
        return playwright.chromium.launch(headless=False, args=args)

    # Emergency fallback for users who explicitly want Playwright headless.
    return playwright.chromium.launch(headless=True)


def extract_url_from_line(line: str) -> str | None:
    """Extract the first http(s) URL from one links.txt line.

    Taobao / Xianyu share links sometimes look like:
    https://m.tb.cn/h.xxx?tk=abc CZ000

    The trailing code after the first whitespace is not part of the URL.
    """
    line = line.strip()
    if not line or line.startswith("#"):
        return None

    match = re.search(r"https?://[^\s]+", line, flags=re.I)
    if not match:
        return None

    url = match.group(0).strip().strip('"\'<>，。；;')
    return url or None


def read_links() -> list[str]:
    """Read all valid-looking URL lines from links.txt.

    Rules:
    - one link per line;
    - blank lines are ignored;
    - lines beginning with # are ignored;
    - only the first http(s) URL in each line is used, so share-code suffixes are ignored;
    - duplicate URLs are removed while preserving order.
    """
    if not LINKS_FILE.exists():
        return []

    links: list[str] = []
    seen: set[str] = set()
    for raw_line in LINKS_FILE.read_text(encoding="utf-8").splitlines():
        url = extract_url_from_line(raw_line)
        if not url or url in seen:
            continue
        seen.add(url)
        links.append(url)
    return links


def read_first_link() -> str | None:
    links = read_links()
    return links[0] if links else None


def validate_url(url: str) -> tuple[bool, str]:
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "链接格式无法解析"

    if parsed.scheme not in {"http", "https"}:
        return False, "链接必须以 http:// 或 https:// 开头"

    host = parsed.netloc.lower()
    allowed_hosts = (
        "goofish.com",
        "2.taobao.com",
        "xianyu.com",
        "idlefish",
        "m.tb.cn",
        "tb.cn",
        "taobao.com",
    )
    if not any(key in host for key in allowed_hosts):
        return False, "这不像闲鱼 / goofish / 淘宝短链，请检查 links.txt"

    return True, "OK"


def compact_text(text: str | None) -> str | None:
    if text is None:
        return None
    text = re.sub(r"\s+", " ", text).strip()
    text = text.strip("-|_—– ")
    return text or None


def normalize_title(text: str | None) -> str | None:
    text = compact_text(text)
    if not text:
        return None

    # Browser titles often end with site names.
    text = re.sub(r"\s*[-_—|]\s*(闲鱼|Goofish).*$", "", text, flags=re.I).strip()
    text = compact_text(text)
    if not text:
        return None

    lowered = text.lower()
    if lowered in {x.lower() for x in GENERIC_TITLES}:
        return None
    if any(key.lower() in lowered for key in BAD_TITLE_KEYWORDS):
        return None
    if len(text) <= 3:
        return None
    if len(text) > 160:
        text = text[:160] + "…"
    return text or None


def extract_title_from_combined_visible_text(text: str | None) -> str | None:
    """Extract product title from a combined visible block.

    Some Goofish pages render the main detail area as one large text block, for example:
    "¥ 410 包邮 11人想要 697浏览 Product Title 聊一聊 APP下单 收藏".
    This helper only uses text that already passed upper-page / non-feed filters.
    """
    text = compact_text(text)
    if not text:
        return None

    # Remove leading price and traffic/action prefixes.
    text = re.sub(r"^.*?(?:[0-9]+\s*浏览|[0-9]+\s*人想要)\s*", "", text)
    # Remove trailing action buttons and mobile-app hints.
    text = re.split(r"\s*(?:聊一聊|APP下单|App下单|立即购买|我想要|收藏|举报|担保交易)\s*", text)[0]
    return normalize_title(text)



def shorten_for_notify(text: str | None, max_len: int = 90) -> str:
    text = compact_text(text) or "未识别标题"
    # winotify ultimately renders XML/PowerShell content. Keep it boring and short.
    text = text.replace('"', '“').replace("'", "’")
    if len(text) > max_len:
        text = text[: max_len - 1] + "…"
    return text


def money(value: Any) -> str:
    try:
        if value is None:
            return "未识别"
        v = float(value)
        if v.is_integer():
            return f"¥{int(v)}"
        return f"¥{v:.2f}"
    except Exception:
        return str(value)


def price_delta_text(old_price: Any, new_price: Any) -> str:
    try:
        if old_price is None or new_price is None:
            return ""
        old_v = float(old_price)
        new_v = float(new_price)
        delta = new_v - old_v
        sign = "+" if delta >= 0 else "-"
        delta_abs = abs(delta)
        delta_text = money(delta_abs)
        if old_v:
            pct = abs(delta) / abs(old_v) * 100.0
            return f"{sign}{delta_text}（{pct:.1f}%）"
        return f"{sign}{delta_text}"
    except Exception:
        return ""


NETWORK_ERROR_KEYWORDS = (
    "ERR_INTERNET_DISCONNECTED",
    "ERR_NAME_NOT_RESOLVED",
    "ERR_NETWORK_CHANGED",
    "ERR_CONNECTION_RESET",
    "ERR_CONNECTION_REFUSED",
    "ERR_CONNECTION_TIMED_OUT",
    "ERR_ADDRESS_UNREACHABLE",
    "ERR_PROXY_CONNECTION_FAILED",
    "net::ERR",
    "getaddrinfo",
    "NameResolution",
    "Temporary failure in name resolution",
    "DNS",
)


def is_network_error_text(text: Any) -> bool:
    raw = str(text or "")
    if not raw:
        return False
    lowered = raw.lower()
    return any(key.lower() in lowered for key in NETWORK_ERROR_KEYWORDS)


def is_network_problem_snapshot(snapshot: "ProductSnapshot") -> bool:
    return snapshot.status == STATUS_LOAD_FAILED and is_network_error_text(snapshot.reason)


def network_reason_label(reason: Any) -> str:
    text = str(reason or "")
    if "ERR_INTERNET_DISCONNECTED" in text:
        return "网络已断开"
    if "ERR_NAME_NOT_RESOLVED" in text or "DNS" in text.upper() or "getaddrinfo" in text:
        return "DNS/域名解析失败，可能已断网"
    if "ERR_NETWORK_CHANGED" in text:
        return "网络连接发生变化"
    if "ERR_CONNECTION_TIMED_OUT" in text:
        return "连接超时，可能网络不稳定"
    if "ERR_CONNECTION_RESET" in text:
        return "连接被重置，可能网络不稳定"
    return "页面访问失败，疑似网络异常"


def status_label_text(status: Any) -> str:
    mapping = {
        "NORMAL": "可购买",
        "SOLD": "已售",
        "REMOVED": "下架/失效",
        "LOGIN_REQUIRED": "需要登录",
        "VERIFY_REQUIRED": "需要验证",
        "LOAD_FAILED": "加载失败",
        "UNKNOWN": "未知",
        "NETWORK_ERROR": "网络异常",
    }
    s = str(status or "")
    return mapping.get(s, s or "未识别")


def compose_notification_text(parts: list[str], max_len: int = 180) -> str:
    clean_parts = [compact_text(str(x or "")) for x in parts]
    clean_parts = [x for x in clean_parts if x]
    joined = " | ".join(clean_parts)
    return shorten_for_notify(joined, max_len)


def can_send_notifications(config: dict[str, Any]) -> bool:
    if not bool(config.get("notification_enabled", True)):
        return False
    if platform.system().lower() != "windows":
        return False
    return WINOTIFY_AVAILABLE


def append_notification_log(title: str, message: str, url: str | None, channel: str, ok: bool) -> None:
    try:
        DATA_DIR.mkdir(exist_ok=True)
        payload = {
            "time": now_str(),
            "title": title,
            "message": message,
            "url": url,
            "channel": channel,
            "ok": ok,
        }
        with NOTIFICATION_LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass


def send_popup_fallback(title: str, message: str, config: dict[str, Any]) -> bool:
    """Show a separate Windows message box for important alerts.

    Toast notifications can be suppressed by Focus Assist / notification settings
    while winotify still reports success.  The fallback is fire-and-forget in a
    child process, so the monitor loop is not blocked by the popup.
    """
    if not bool(config.get("notification_popup_fallback", True)):
        return False
    if platform.system().lower() != "windows":
        return False
    try:
        script = (
            "import ctypes, sys;"
            "title=sys.argv[1]; msg=sys.argv[2];"
            "ctypes.windll.user32.MessageBoxW(0, msg, title, 0x00001040)"
        )
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            [sys.executable, "-c", script, shorten_for_notify(title, 70), shorten_for_notify(message, 260)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=flags,
        )
        append_notification_log(title, message, None, "popup_fallback", True)
        return True
    except Exception as exc:
        log(f"[警告] 桌面弹窗兜底失败：{exc}")
        append_notification_log(title, message, None, "popup_fallback", False)
        return False


def send_windows_notification(title: str, message: str, url: str | None, config: dict[str, Any], *, critical: bool = False) -> bool:
    """Send a Windows Toast notification.

    Failure must never stop monitoring.  For important change/network alerts, a
    small desktop popup fallback is also shown because Windows Toast can be
    silently suppressed even when the library call itself succeeds.
    """
    if not bool(config.get("notification_enabled", True)):
        return False
    toast_ok = False
    if platform.system().lower() != "windows":
        log("通知跳过：当前系统不是 Windows。")
    elif not WINOTIFY_AVAILABLE or Notification is None:
        log("通知跳过：未安装 winotify。请重新运行 install.bat。")
    else:
        try:
            toast = Notification(
                app_id="xy-monitor",
                title=shorten_for_notify(title, 70),
                msg=shorten_for_notify(message, 180),
            )
            if audio is not None:
                try:
                    toast.set_audio(audio.Default, loop=False)
                except Exception:
                    pass
            if url and bool(config.get("notification_add_open_button", True)) and str(url).lower().startswith(("http://", "https://")) and len(str(url)) < 900:
                try:
                    toast.add_actions(label="打开商品页面", launch=str(url))
                except Exception as exc:
                    log(f"通知按钮添加失败，仍尝试发送普通通知：{exc}")
            toast.show()
            toast_ok = True
            log(f"通知已发送：{title}")
            append_notification_log(title, message, url, "toast", True)
        except Exception as exc:
            log(f"[警告] Windows 通知发送失败：{exc}")
            append_notification_log(title, message, url, "toast", False)

    popup_ok = False
    if critical:
        popup_ok = send_popup_fallback(title, message, config)
        if popup_ok:
            log(f"重要通知已启用桌面弹窗兜底：{title}")
    return bool(toast_ok or popup_ok)


NOTIFICATION_CONFIG_KEYS = {
    "notification_enabled",
    "notify_status_change",
    "notify_price_down",
    "notify_price_up",
    "notify_title_change",
    "notify_sold",
    "notify_removed",
    "notify_login_required",
    "notify_verify_required",
    "notify_failures",
    "notify_network_errors",
    "notify_network_errors_every_round",
    "notification_popup_fallback",
    "notify_not_buyable",
    "notify_not_buyable_every_round",
    "notify_not_buyable_on_first_seen",
    "notify_not_buyable_for_load_failed",
    "notify_round_complete",
    "notification_add_open_button",
}


def refresh_notification_config(config: dict[str, Any]) -> dict[str, Any]:
    """Reload notification-related config so dashboard switches take effect immediately.

    The long-running monitor used to load config.json only once at startup.
    That made the dashboard notification switches look saved while the active
    background process kept using old values.  This helper intentionally reloads
    only notification keys, avoiding mid-run changes to crawling intervals,
    browser options, or other core behavior.
    """
    try:
        latest = load_config()
    except Exception as exc:
        log(f"[警告] 重新读取通知设置失败，沿用本轮启动时配置：{exc}")
        return config
    merged = dict(config)
    for key in NOTIFICATION_CONFIG_KEYS:
        if key in latest:
            merged[key] = latest[key]
    return merged


def event_notification_enabled(event_type: str, config: dict[str, Any]) -> bool:
    if not bool(config.get("notify_status_change", True)):
        return False
    mapping = {
        "PRICE_DOWN": "notify_price_down",
        "PRICE_UP": "notify_price_up",
        "TITLE_CHANGED": "notify_title_change",
        "SOLD": "notify_sold",
        "REMOVED": "notify_removed",
        "LOGIN_REQUIRED": "notify_login_required",
        "VERIFY_REQUIRED": "notify_verify_required",
        "NOT_BUYABLE": "notify_not_buyable",
        "NETWORK_ERROR": "notify_network_errors",
        "RECOVERED": "notify_removed",
        "STATUS_CHANGED": "notify_removed",
    }
    key = mapping.get(event_type)
    return bool(config.get(key, True)) if key else True


def notify_history_event(event: dict[str, Any], config: dict[str, Any]) -> None:
    config = refresh_notification_config(config)
    event_type = str(event.get("event") or "")
    if not event_notification_enabled(event_type, config):
        log(f"通知按配置跳过：{event_type}")
        return

    title_text = shorten_for_notify(str(event.get("title") or "未识别标题"), 80)
    old_price = event.get("old_price")
    new_price = event.get("new_price")
    url = str(event.get("resolved_url") or event.get("url") or "") or None

    if event_type == "PRICE_DOWN":
        title = f"闲鱼降价：{money(old_price)} → {money(new_price)}"
        message = compose_notification_text([
            f"降幅 {price_delta_text(old_price, new_price)}",
            f"当前价 {money(new_price)}",
            f"商品 {title_text}",
        ])
    elif event_type == "PRICE_UP":
        title = f"闲鱼涨价：{money(old_price)} → {money(new_price)}"
        message = compose_notification_text([
            f"涨幅 {price_delta_text(old_price, new_price)}",
            f"当前价 {money(new_price)}",
            f"商品 {title_text}",
        ])
    elif event_type == "TITLE_CHANGED":
        title = "闲鱼标题变化"
        message = compose_notification_text([
            f"最新标题 {title_text}",
            f"当前价 {money(new_price)}" if new_price is not None else "",
        ])
    elif event_type == "SOLD":
        title = "闲鱼已售"
        message = compose_notification_text([
            "商品状态已变为已售",
            f"最近价格 {money(new_price)}" if new_price is not None else "",
            f"商品 {title_text}",
        ])
    elif event_type == "REMOVED":
        title = "闲鱼下架/失效"
        message = compose_notification_text([
            "商品链接可能已失效或被下架",
            f"最近价格 {money(new_price)}" if new_price is not None else "",
            f"商品 {title_text}",
        ])
    elif event_type == "LOGIN_REQUIRED":
        title = "闲鱼需要重新登录"
        message = compose_notification_text([
            "登录态失效，请先停止监控",
            "随后运行 login.bat 重新登录",
            f"来源 {title_text}",
        ])
    elif event_type == "VERIFY_REQUIRED":
        title = "闲鱼需要手动验证"
        message = compose_notification_text([
            "检测到安全验证，请手动处理",
            "不要尝试绕过验证",
            f"来源 {title_text}",
        ])
    elif event_type == "NOT_BUYABLE":
        title = "闲鱼不可购买/异常"
        reason = compact_text(str(event.get("buyability_reason") or event.get("reason") or "未识别到可购买证据")) or "未识别到可购买证据"
        message = compose_notification_text([
            f"状态 {status_label_text(event.get('new_status'))}",
            f"原因 {reason}",
            f"当前价 {money(new_price)}" if new_price is not None else "",
            f"商品 {title_text}",
        ])
    elif event_type == "NETWORK_ERROR":
        title = "闲鱼监控网络异常"
        reason = shorten_for_notify(str(event.get("reason") or "疑似断网/DNS失败"), 80)
        message = compose_notification_text([
            network_reason_label(reason),
            "本次不会覆盖原有可信价格/状态",
            "网络恢复后可点立即检测一轮",
        ], max_len=220)
    elif event_type == "RECOVERED":
        title = "闲鱼恢复正常"
        message = compose_notification_text([
            f"状态恢复为 {status_label_text(event.get('new_status') or 'NORMAL')}",
            f"当前价 {money(new_price)}" if new_price is not None else "",
            f"商品 {title_text}",
        ])
    else:
        title = "闲鱼状态变化"
        message = compose_notification_text([
            f"{status_label_text(event.get('old_status'))} → {status_label_text(event.get('new_status'))}",
            f"当前价 {money(new_price)}" if new_price is not None else "",
            f"商品 {title_text}",
        ])

    ok = send_windows_notification(title, message, url, config, critical=True)
    if not ok:
        print(f"[通知未弹出] {title} - {message}")


def notify_auth_problem(status: str, reason: str, url: str, config: dict[str, Any]) -> None:
    event = {
        "time": now_str(),
        "event": status,
        "url": url,
        "resolved_url": url,
        "title": "登录状态检查",
        "old_price": None,
        "new_price": None,
        "old_status": None,
        "new_status": status,
        "reason": reason,
    }
    append_history(event)
    notify_history_event(event, config)


def notify_failure_threshold(source_url: str, entry: dict[str, Any], config: dict[str, Any]) -> None:
    config = refresh_notification_config(config)
    if not bool(config.get("notify_status_change", True)):
        log("通知按配置跳过：连续访问失败（状态变动通知已关闭）")
        return
    if not bool(config.get("notify_failures", True)):
        return
    count = int(entry.get("failure_count") or 0)
    title = "闲鱼连续访问失败"
    reason = compact_text(str(entry.get("last_error_reason") or entry.get("last_error_status") or "未知原因")) or "未知原因"
    message = compose_notification_text([
        f"连续失败 {count} 次",
        f"原因 {reason}",
        f"链接 {source_url}",
    ])
    ok = send_windows_notification(title, message, source_url, config, critical=True)
    if not ok:
        print(f"[通知未弹出] {title} - {message}")

def parse_price_from_text(text: str) -> float | None:
    if not text:
        return None

    candidates: list[float] = []
    patterns = [
        r"(?:¥|￥)\s*([0-9]{1,7}(?:,[0-9]{3})*(?:\.[0-9]{1,2})?)",
        r"(?:价格|售价|现价|到手价|卖价|转让价)\s*[:：]?\s*(?:¥|￥)?\s*([0-9]{1,7}(?:,[0-9]{3})*(?:\.[0-9]{1,2})?)",
        r"([0-9]{1,7}(?:,[0-9]{3})*(?:\.[0-9]{1,2})?)\s*元",
    ]

    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.I):
            raw = match.group(1).replace(",", "")
            try:
                value = float(raw)
            except ValueError:
                continue
            if 0 < value < 10_000_000:
                candidates.append(value)

    return candidates[0] if candidates else None


def page_text_contains(text: str, keywords: list[str]) -> bool:
    lowered = text.lower()
    return any(keyword.lower() in lowered for keyword in keywords)


def classify_status(url: str, text: str, evidence: dict[str, Any] | None = None) -> tuple[str, str]:
    """Classify page status using conservative evidence.

    Important:
    - Seller profile text like "卖出4712件宝贝" is not product sold evidence.
    - If the target item still exposes a buy/create-order action, do not classify SOLD
      unless a strong sold/unavailable phrase is present.
    """
    evidence = evidence or {}
    current_url = url.lower()

    if any(key in current_url for key in LOGIN_URL_KEYWORDS) and page_text_contains(text, LOGIN_TEXT_KEYWORDS):
        return STATUS_LOGIN_REQUIRED, "页面疑似跳转到登录页"

    if page_text_contains(text, VERIFY_KEYWORDS):
        return STATUS_VERIFY_REQUIRED, "页面出现安全验证或验证码相关文案"

    if page_text_contains(text, LOGIN_TEXT_KEYWORDS) and not page_text_contains(text, ["价格", "¥", "￥"]):
        return STATUS_LOGIN_REQUIRED, "页面疑似要求重新登录"

    if page_text_contains(text, REMOVED_KEYWORDS):
        return STATUS_REMOVED, "页面出现下架/不存在相关文案"

    has_buy = bool(evidence.get("has_buy_action_for_target") or evidence.get("has_create_order_link_for_target"))
    sold_hit = page_text_contains(text, SOLD_KEYWORDS)
    evidence_hits = evidence.get("keyword_hits") or {}
    if isinstance(evidence_hits, dict) and evidence_hits.get("sold"):
        sold_hit = True

    if sold_hit:
        if has_buy:
            return STATUS_UNKNOWN, "页面同时出现已售/不可购买文案和购买入口，暂不直接判定已售；请查看调试证据"
        return STATUS_SOLD, "页面出现严格已售/不可购买相关文案"

    return STATUS_UNKNOWN, "尚未找到足够证据判断为正常商品页"


def auth_phase_label(status: str) -> str:
    if status == STATUS_LOGIN_REQUIRED:
        return "需要重新登录"
    if status == STATUS_VERIFY_REQUIRED:
        return "需要手动验证"
    if status == STATUS_NETWORK_ERROR:
        return "网络异常"
    return "登录检查异常"


def extract_login_check_evidence(page, final_url: str, body_text: str) -> dict[str, Any]:
    """Collect visible login/verify evidence before visiting product links."""
    evidence: dict[str, Any] = {
        "check_url": final_url,
        "pageTitle": "",
        "keyword_hits": {
            "login": [k for k in LOGIN_TEXT_KEYWORDS if k in body_text],
            "verify": [k for k in VERIFY_KEYWORDS if k in body_text],
        },
        "login_actions": [],
        "account_hints": [],
    }

    js = r"""
    () => {
      function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }
      function visible(el) {
        if (!el || el.nodeType !== 1) return false;
        const st = window.getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return st && st.visibility !== 'hidden' && st.display !== 'none' && r.width > 0 && r.height > 0;
      }
      const loginPattern = /^(登录|请登录|立即登录)$|登录\/注册|扫码登录|密码登录|手机号登录|账号登录|短信登录|淘宝登录|支付宝登录/i;
      const accountPattern = /退出登录|账号设置|个人主页|我的闲鱼|我的发布|卖家中心/i;
      const loginActions = [];
      const accountHints = [];
      const selectors = ['button', 'a', '[role="button"]', 'input[type="button"]', 'input[type="submit"]'];
      const seen = new Set();
      for (const selector of selectors) {
        for (const el of document.querySelectorAll(selector)) {
          if (!visible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.top < 0 || r.top > 780) continue;
          const text = clean(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || el.value || '');
          const href = el.getAttribute('href') || '';
          const key = selector + '|' + text + '|' + href + '|' + Math.round(r.top);
          if (!text || seen.has(key)) continue;
          seen.add(key);
          const item = {
            selector,
            text,
            href,
            top: Math.round(r.top),
            left: Math.round(r.left),
            disabled: !!(el.disabled || el.getAttribute('disabled') !== null || el.getAttribute('aria-disabled') === 'true')
          };
          if (loginPattern.test(text) && !/退出登录/.test(text)) loginActions.push(item);
          if (accountPattern.test(text)) accountHints.push(item);
        }
      }
      return {
        pageTitle: document.title || '',
        login_actions: loginActions.slice(0, 20),
        account_hints: accountHints.slice(0, 20)
      };
    }
    """
    try:
        dynamic = page.evaluate(js)
        if isinstance(dynamic, dict):
            evidence.update(dynamic)
    except Exception as exc:
        evidence["js_error"] = repr(exc)
    return evidence


def classify_login_check(final_url: str, body_text: str, evidence: dict[str, Any]) -> tuple[bool, str, str]:
    current_url = final_url.lower()
    hits = evidence.get("keyword_hits") if isinstance(evidence.get("keyword_hits"), dict) else {}
    login_hits = hits.get("login") if isinstance(hits, dict) else []
    verify_hits = hits.get("verify") if isinstance(hits, dict) else []
    login_actions = evidence.get("login_actions") if isinstance(evidence.get("login_actions"), list) else []
    account_hints = evidence.get("account_hints") if isinstance(evidence.get("account_hints"), list) else []

    if verify_hits:
        return False, STATUS_VERIFY_REQUIRED, "登录前置检查发现安全验证/验证码页面"

    if any(key in current_url for key in LOGIN_URL_KEYWORDS) and login_hits:
        return False, STATUS_LOGIN_REQUIRED, "登录前置检查疑似跳转到登录页"

    if login_hits and not page_text_contains(body_text, ["价格", "¥", "￥"]):
        return False, STATUS_LOGIN_REQUIRED, "登录前置检查页面出现登录提示"

    if login_actions and not account_hints:
        text = compact_text(str(login_actions[0].get("text") if isinstance(login_actions[0], dict) else "")) or "登录"
        return False, STATUS_LOGIN_REQUIRED, f"登录前置检查发现可见登录入口：{text}"

    return True, STATUS_NORMAL, "登录前置检查未发现登录页或安全验证"


def save_login_check_debug(evidence: dict[str, Any], config: dict[str, Any]) -> None:
    if not bool(config.get("debug_status_evidence", True)):
        return
    try:
        payload = {
            "written_at": now_str(),
            "evidence": evidence,
            "note": "This file records the pre-round login check evidence.",
        }
        LOGIN_CHECK_DEBUG.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        log(f"[警告] 保存登录前置检查调试 JSON 失败：{exc}")


def check_login_before_round(context, config: dict[str, Any], round_no: int) -> LoginCheckResult:
    if not bool(config.get("login_check_enabled", True)):
        return LoginCheckResult(True, STATUS_NORMAL, "登录前置检查已按配置关闭", str(config.get("login_check_url") or GOOFISH_HOME), {})

    check_url = str(config.get("login_check_url") or GOOFISH_HOME)
    captured_url = check_url
    page = context.new_page()
    page.set_default_timeout(int(config["page_timeout_ms"]))
    try:
        write_runtime_status(
            running=True,
            round_no=round_no,
            phase="LOGIN_CHECK",
            phase_label="正在检查登录状态",
            current_index=0,
            total=0,
            current_url=check_url,
            last_message="正在进行登录前置检查",
            delay_seconds=0,
            delay_remaining_seconds=0,
        )
        page.goto(check_url, wait_until="domcontentloaded", timeout=int(config["page_timeout_ms"]))
        captured_url = page.url or check_url
        wait_seconds = float(config.get("login_check_wait_seconds", 2))
        if wait_seconds > 0:
            time.sleep(wait_seconds)
        try:
            page.wait_for_load_state("networkidle", timeout=8000)
        except Exception:
            pass
        try:
            body_text = page.locator("body").inner_text(timeout=5000)
        except Exception:
            body_text = ""
        body_text = compact_text(body_text) or ""
        captured_url = page.url or captured_url
        evidence = extract_login_check_evidence(page, captured_url, body_text)
        save_login_check_debug(evidence, config)
        ok, status, reason = classify_login_check(captured_url, body_text, evidence)
        return LoginCheckResult(ok, status, reason, captured_url, evidence)
    except PlaywrightTimeoutError:
        reason = "登录前置检查打开页面超时，继续执行商品检测"
        log(f"[警告] {reason}")
        return LoginCheckResult(True, STATUS_UNKNOWN, reason, captured_url, {})
    except Exception as exc:
        reason = f"登录前置检查失败：{exc}"
        log(f"[警告] {reason}")
        if is_network_error_text(reason):
            return LoginCheckResult(False, STATUS_NETWORK_ERROR, reason, captured_url, {})
        return LoginCheckResult(True, STATUS_UNKNOWN, reason + "；继续执行商品检测", captured_url, {})
    finally:
        try:
            page.close()
        except Exception:
            pass


def get_item_id(url: str) -> str | None:
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        for key in ("id", "itemId", "item_id"):
            values = qs.get(key)
            if values and values[0]:
                return str(values[0])
    except Exception:
        return None
    return None


def safe_debug_name(url: str | None, fallback: str = "unknown") -> str:
    item_id = get_item_id(url or "")
    if item_id:
        return f"item_{item_id}"
    raw = compact_text(url) or fallback
    raw = re.sub(r"[^0-9A-Za-z._-]+", "_", raw)
    raw = raw.strip("._-") or fallback
    return raw[:80]


def debug_paths_for_url(url: str | None) -> tuple[Path, Path]:
    name = safe_debug_name(url)
    return (
        DEBUG_ITEMS_DIR / f"{name}_last_page_debug.html",
        DEBUG_ITEMS_DIR / f"{name}_last_candidates_debug.json",
    )


def make_state_key(source_url: str, resolved_url: str | None = None) -> str:
    """Return a stable key for state.json.

    Earlier versions used the full URL as the state key. That is fragile because
    Goofish links often contain changing tracking parameters such as spm and
    categoryId. v0.4.0 keys item pages by item id when possible, for example:
    item:1046480911089
    """
    item_id = get_item_id(resolved_url or "") or get_item_id(source_url or "")
    if item_id:
        return f"item:{item_id}"
    return source_url


def load_run_meta() -> dict[str, Any]:
    ensure_dirs()
    if not RUN_META_FILE.exists():
        return {"total_rounds": 0}
    try:
        value = json.loads(RUN_META_FILE.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            value.setdefault("total_rounds", 0)
            return value
        raise ValueError("run_meta.json root is not an object")
    except Exception as exc:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = DATA_DIR / f"run_meta.broken.{stamp}.json"
        try:
            shutil.copy2(RUN_META_FILE, backup)
        except Exception:
            pass
        log(f"[警告] run_meta.json 读取失败，已尝试备份为 {backup.name}，将重新计数：{exc}")
        return {"total_rounds": 0}


def save_run_meta(meta: dict[str, Any]) -> None:
    ensure_dirs()
    tmp = RUN_META_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(RUN_META_FILE)


def migrate_state_keys(state: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    """Migrate old full-URL state keys to stable item:<id> keys when possible."""
    migrated: dict[str, Any] = {}
    changed = False
    for old_key, value in state.items():
        if not isinstance(value, dict):
            migrated[old_key] = value
            continue
        source_url = str(value.get("url") or old_key)
        resolved_url = str(value.get("resolved_url") or "")
        new_key = make_state_key(source_url, resolved_url)
        if new_key != old_key:
            changed = True
        value = dict(value)
        value["state_key"] = new_key
        if new_key in migrated and isinstance(migrated[new_key], dict):
            old_checked = str(migrated[new_key].get("last_checked") or migrated[new_key].get("last_seen") or "")
            new_checked = str(value.get("last_checked") or value.get("last_seen") or "")
            if new_checked >= old_checked:
                migrated[new_key] = value
        else:
            migrated[new_key] = value
    return migrated, changed


def history_line_count() -> int:
    if not HISTORY_FILE.exists():
        return 0
    try:
        with HISTORY_FILE.open("r", encoding="utf-8") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def save_debug_html_if_needed(page, config: dict[str, Any], final_url: str | None = None) -> str | None:
    """Save debug HTML.

    Compatibility behavior:
    - logs/last_page_debug.html is still overwritten for quick inspection.
    - logs/debug_items/item_<id>_last_page_debug.html keeps a separate latest file per item.
    """
    if not config.get("save_debug_html", True):
        return None
    try:
        html = page.content()
        max_chars = int(config.get("debug_html_max_chars", 300000))
        payload = html[:max_chars]
        DEBUG_HTML.write_text(payload, encoding="utf-8")
        per_item_path = None
        if bool(config.get("save_per_item_debug", True)):
            per_html, _ = debug_paths_for_url(final_url)
            per_html.write_text(payload, encoding="utf-8")
            per_item_path = per_html
        return str(per_item_path or DEBUG_HTML)
    except Exception as exc:
        log(f"[警告] 保存调试 HTML 失败：{exc}")
        return None


def save_debug_candidates(candidates: dict[str, Any], config: dict[str, Any], final_url: str | None = None) -> str | None:
    """Save candidate debug JSON.

    Compatibility behavior:
    - logs/last_candidates_debug.json is still overwritten for quick inspection.
    - logs/debug_items/item_<id>_last_candidates_debug.json keeps a separate latest file per item.
    """
    if not config.get("save_debug_html", True):
        return None
    try:
        payload = json.dumps(candidates, ensure_ascii=False, indent=2)
        DEBUG_JSON.write_text(payload, encoding="utf-8")
        per_item_path = None
        if bool(config.get("save_per_item_debug", True)):
            _, per_json = debug_paths_for_url(final_url)
            per_json.write_text(payload, encoding="utf-8")
            per_item_path = per_json
        return str(per_item_path or DEBUG_JSON)
    except Exception as exc:
        log(f"[警告] 保存候选调试 JSON 失败：{exc}")
        return None


def extract_json_like_candidates(page, final_url: str) -> dict[str, list[dict[str, Any]]]:
    """Conservatively extract title/price from inline JSON-ish scripts.

    If the current item id exists, only snippets near that id are trusted. This reduces
    the chance of using recommended product data.
    """
    target_id = get_item_id(final_url)
    result: dict[str, list[dict[str, Any]]] = {"titles": [], "prices": []}

    try:
        scripts = page.evaluate(
            """
            () => Array.from(document.scripts)
              .map(s => s.textContent || '')
              .filter(t => t && t.length > 50)
              .slice(0, 80)
            """
        )
    except Exception:
        return result

    if not isinstance(scripts, list):
        return result

    title_patterns = [
        r'"(?:title|itemTitle|auctionTitle|subject|name)"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"',
        r"'(?:title|itemTitle|auctionTitle|subject|name)'\s*:\s*'([^'\\]*(?:\\.[^'\\]*)*)'",
    ]
    price_patterns = [
        r'"(?:price|salePrice|currentPrice|reservePrice|amount|soldPrice)"\s*:\s*"?([0-9]{1,8}(?:\.[0-9]{1,2})?)"?',
        r"'(?:price|salePrice|currentPrice|reservePrice|amount|soldPrice)'\s*:\s*'?([0-9]{1,8}(?:\.[0-9]{1,2})?)'?",
    ]

    def snippets_near_id(script: str) -> list[str]:
        if target_id:
            if target_id not in script:
                return []
            snippets: list[str] = []
            for match in re.finditer(re.escape(target_id), script):
                a = max(0, match.start() - 12000)
                b = min(len(script), match.end() + 12000)
                snippets.append(script[a:b])
                if len(snippets) >= 5:
                    break
            return snippets
        # Without item id, avoid huge app-state scripts because they often contain feeds.
        return [script[:20000]] if len(script) < 50000 else []

    for script in scripts:
        if not isinstance(script, str):
            continue
        if not any(key in script for key in ["item", "price", "title", "auction", "商品"]):
            continue
        for snippet in snippets_near_id(script):
            for pattern in title_patterns:
                for m in re.finditer(pattern, snippet, flags=re.I):
                    raw = m.group(1)
                    try:
                        raw = bytes(raw, "utf-8").decode("unicode_escape", errors="ignore")
                    except Exception:
                        pass
                    title = normalize_title(raw)
                    if title:
                        result["titles"].append({"text": title, "source": "script-near-item-id" if target_id else "script"})
            for pattern in price_patterns:
                for m in re.finditer(pattern, snippet, flags=re.I):
                    try:
                        value = float(m.group(1))
                    except Exception:
                        continue
                    # Some app-state values are cents. Convert only when it is very likely.
                    if value >= 10000 and value % 100 == 0:
                        maybe_yuan = value / 100
                        if 0 < maybe_yuan < 100000:
                            value = maybe_yuan
                    if 0 < value < 10_000_000:
                        result["prices"].append({"value": value, "source": "script-near-item-id" if target_id else "script"})
    return result


def extract_visible_candidates(page, final_url: str) -> dict[str, Any]:
    """Collect visible candidates from the upper product-detail area only.

    v0.1.3 searched the whole page and could pick a recommended item under '为你推荐'.
    v0.1.5 filters recommendation/feed/list areas and refuses to use lower-page data.
    """
    target_id = get_item_id(final_url)
    js = r"""
    (targetId) => {
      const badWords = ['为你推荐','猜你喜欢','相关推荐','看了又看','更多推荐','相关商品','搜索结果','商品推荐'];
      const badAttrWords = ['recommend','guess','related','waterfall','feed','searchfeed','search-feed','listitem','card'];
      const titleSelectors = [
        'meta[property="og:title"]','meta[name="twitter:title"]','h1','h2',
        '[class*="title"]','[class*="Title"]','[class*="name"]','[class*="Name"]'
      ];
      const priceSelectors = [
        '[class*="price"]','[class*="Price"]','[class*="amount"]','[class*="Amount"]',
        '[class*="money"]','[class*="Money"]','[class*="yen"]','[class*="Yen"]'
      ];
      function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }
      function visible(el) {
        if (!el || el.nodeType !== 1) return false;
        const st = window.getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return st && st.visibility !== 'hidden' && st.display !== 'none' && r.width > 0 && r.height > 0;
      }
      function attrs(el) {
        return clean(((el.className || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('data-spm') || '')).toString()).toLowerCase();
      }
      function inBadArea(el) {
        let cur = el;
        for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
          const a = attrs(cur);
          if (badAttrWords.some(w => a.includes(w))) return true;
          const selfText = clean(cur.innerText || cur.textContent || '');
          if (selfText.length <= 40 && badWords.some(w => selfText.includes(w))) return true;
          if (targetId && cur.tagName && cur.tagName.toLowerCase() === 'a') {
            const href = cur.getAttribute('href') || '';
            if (href.includes('/item') && !href.includes(targetId)) return true;
          }
        }
        return false;
      }
      function scoreElement(el, kind) {
        if (el.tagName && el.tagName.toLowerCase() === 'meta') return 1000;
        const r = el.getBoundingClientRect();
        let score = 0;
        if (r.top >= 0 && r.top < 720) score += 500 - Math.min(450, r.top / 2);
        if (r.width > 120) score += 30;
        if (kind === 'price' && r.top < 620) score += 80;
        if (kind === 'title' && r.top < 620) score += 60;
        return Math.round(score);
      }
      function collect(selectors, kind) {
        const out = [];
        for (const selector of selectors) {
          for (const el of document.querySelectorAll(selector)) {
            let text = '';
            let top = -1;
            let left = -1;
            let source = selector;
            if (el.tagName && el.tagName.toLowerCase() === 'meta') {
              text = clean(el.getAttribute('content') || '');
            } else {
              if (!visible(el)) continue;
              if (inBadArea(el)) continue;
              const r = el.getBoundingClientRect();
              top = Math.round(r.top);
              left = Math.round(r.left);
              if (r.top > 760) continue;
              text = clean(el.innerText || el.textContent || '');
            }
            if (!text) continue;
            if (kind === 'title' && (text.length < 4 || text.length > 220)) continue;
            if (kind === 'price' && !/[¥￥元]|价格|售价|现价|卖价|转让价/.test(text)) continue;
            out.push({text, source, top, left, score: scoreElement(el, kind)});
          }
        }
        if (kind === 'price') {
          for (const el of document.querySelectorAll('body *')) {
            if (!visible(el) || inBadArea(el)) continue;
            const r = el.getBoundingClientRect();
            if (r.top < 0 || r.top > 650) continue;
            const text = clean(el.innerText || el.textContent || '');
            if (text && text.length <= 80 && /[¥￥]|[0-9]+\s*元/.test(text)) {
              out.push({text, source: 'visible-upper-price-text', top: Math.round(r.top), left: Math.round(r.left), score: scoreElement(el, kind) - 20});
            }
          }
        }
        const seen = new Set();
        return out
          .filter(x => { const k = x.text + '|' + x.source + '|' + x.top; if (seen.has(k)) return false; seen.add(k); return true; })
          .sort((a,b) => b.score - a.score)
          .slice(0, 30);
      }
      return {
        targetId,
        pageTitle: document.title || '',
        titles: collect(titleSelectors, 'title'),
        prices: collect(priceSelectors, 'price')
      };
    }
    """
    try:
        values = page.evaluate(js, target_id)
    except Exception:
        return {"targetId": target_id, "titles": [], "prices": []}
    if not isinstance(values, dict):
        return {"targetId": target_id, "titles": [], "prices": []}
    return values




def extract_status_evidence(page, final_url: str, body_text: str) -> dict[str, Any]:
    """Collect page evidence for SOLD / NORMAL judgment.

    This does not change anything by itself. It makes false negatives debuggable:
    if the page still contains a target create-order link, the script should not
    invent a SOLD event merely because the user believes the app has sold it.
    """
    target_id = get_item_id(final_url)

    evidence: dict[str, Any] = {
        "targetId": target_id,
        "pageTitle": "",
        "keyword_hits": {
            "sold": [k for k in SOLD_KEYWORDS if k in body_text],
            "normal_actions": [k for k in NORMAL_ACTION_KEYWORDS if k in body_text],
            "removed": [k for k in REMOVED_KEYWORDS if k in body_text],
        },
        "has_buy_action_for_target": False,
        "has_create_order_link_for_target": False,
        "has_chat_action_for_target": False,
        "top_actions": [],
        "note": "",
    }

    js = r"""
    (targetId) => {
      function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }
      function visible(el) {
        if (!el || el.nodeType !== 1) return false;
        const st = window.getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return st && st.visibility !== 'hidden' && st.display !== 'none' && r.width > 0 && r.height > 0;
      }
      const actions = [];
      const selectors = [
        'a[href*="create-order"]',
        'a[href*="/im"]',
        '[data-spm="buy"] a',
        '[data-spm="want"] a',
        'button',
        '[role="button"]',
        'a'
      ];
      const seen = new Set();
      for (const selector of selectors) {
        for (const el of document.querySelectorAll(selector)) {
          if (!visible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.top < 0 || r.top > 760) continue;
          const text = clean(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '');
          const href = el.getAttribute('href') || '';
          const cls = (el.className || '').toString();
          const dataSpm = el.getAttribute('data-spm') || (el.parentElement && el.parentElement.getAttribute('data-spm')) || '';
          const key = selector + '|' + text + '|' + href + '|' + Math.round(r.top);
          if (seen.has(key)) continue;
          seen.add(key);
          actions.push({
            selector,
            text,
            href,
            className: cls.slice(0, 120),
            dataSpm,
            top: Math.round(r.top),
            left: Math.round(r.left),
            disabled: !!(el.disabled || el.getAttribute('disabled') !== null || el.getAttribute('aria-disabled') === 'true')
          });
        }
      }
      const hasCreateOrderForTarget = actions.some(a => a.href && a.href.includes('create-order') && (!targetId || a.href.includes(targetId)));
      const hasBuyForTarget = actions.some(a => {
        const t = (a.text || '') + ' ' + (a.dataSpm || '') + ' ' + (a.href || '') + ' ' + (a.className || '');
        return (/立即购买|APP下单|App下单|buy|create-order/.test(t)) && (!targetId || t.includes(targetId) || (a.href || '').includes(targetId));
      });
      const hasChatForTarget = actions.some(a => {
        const t = (a.text || '') + ' ' + (a.dataSpm || '') + ' ' + (a.href || '') + ' ' + (a.className || '');
        return (/聊一聊|我想要|want|im/.test(t)) && (!targetId || t.includes(targetId) || (a.href || '').includes(targetId));
      });
      return {
        pageTitle: document.title || '',
        top_actions: actions.slice(0, 40),
        has_buy_action_for_target: hasBuyForTarget,
        has_create_order_link_for_target: hasCreateOrderForTarget,
        has_chat_action_for_target: hasChatForTarget
      };
    }
    """
    try:
        dynamic = page.evaluate(js, target_id)
        if isinstance(dynamic, dict):
            evidence.update(dynamic)
    except Exception as exc:
        evidence["note"] = f"状态证据 JS 提取失败：{exc}"

    if evidence.get("has_create_order_link_for_target") or evidence.get("has_buy_action_for_target"):
        evidence["note"] = "页面仍暴露目标商品购买入口；除非出现强已售文案，否则不应判定 SOLD。"
    elif evidence["keyword_hits"].get("sold"):
        evidence["note"] = "页面出现严格已售/不可购买文案。"
    else:
        evidence["note"] = "未发现严格已售证据。"

    return evidence


def choose_title_price(page, final_url: str, config: dict[str, Any], status_evidence: dict[str, Any] | None = None) -> tuple[str | None, float | None, str]:
    script_candidates = extract_json_like_candidates(page, final_url)
    visible_candidates = extract_visible_candidates(page, final_url)
    debug = {"script": script_candidates, "visible": visible_candidates, "status_evidence": status_evidence or {}}
    save_debug_candidates(debug, config, final_url)

    title: str | None = None
    price: float | None = None
    source_notes: list[str] = []

    for item in script_candidates.get("titles", []):
        title = normalize_title(str(item.get("text", "")))
        if title:
            source_notes.append(f"标题来源：{item.get('source', 'script')}")
            break

    if not title:
        for item in visible_candidates.get("titles", []):
            title = normalize_title(str(item.get("text", "")))
            if title:
                source_notes.append(f"标题来源：{item.get('source', 'visible')}")
                break

    # v0.1.5: Goofish sometimes puts the actual product title only in document.title,
    # while the visible DOM candidate collector can see price but not a clean title node.
    if not title:
        page_title = visible_candidates.get("pageTitle")
        if isinstance(page_title, str):
            title = normalize_title(page_title)
            if title:
                source_notes.append("标题来源：document.title")

    # Extra fallback for the page shape observed in last_candidates_debug.json:
    # a single upper-page text block contains price + traffic counts + title + action buttons.
    if not title:
        for item in visible_candidates.get("prices", []):
            title = extract_title_from_combined_visible_text(str(item.get("text", "")))
            if title:
                source_notes.append(f"标题来源：价格区域组合文本/{item.get('source', 'visible')}")
                break

    for item in script_candidates.get("prices", []):
        value = item.get("value")
        if isinstance(value, (int, float)) and 0 < float(value) < 10_000_000:
            price = float(value)
            source_notes.append(f"价格来源：{item.get('source', 'script')}")
            break

    if price is None:
        for item in visible_candidates.get("prices", []):
            value = parse_price_from_text(str(item.get("text", "")))
            if value is not None:
                price = value
                source_notes.append(f"价格来源：{item.get('source', 'visible')}")
                break

    return title, price, "；".join(source_notes)


def inspect_product_page(page, url: str, config: dict[str, Any]) -> ProductSnapshot:
    captured_at = now_str()
    final_url = url

    try:
        page.goto(url, wait_until="domcontentloaded", timeout=int(config["page_timeout_ms"]))
        final_url = page.url or url
    except PlaywrightTimeoutError:
        return ProductSnapshot(final_url, STATUS_LOAD_FAILED, None, None, "页面加载超时", captured_at, False, "页面加载超时，无法确认可购买")
    except Exception as exc:
        return ProductSnapshot(final_url, STATUS_LOAD_FAILED, None, None, f"页面打开失败：{exc}", captured_at, False, "页面打开失败，无法确认可购买")

    wait_seconds = float(config.get("post_load_wait_seconds", 3))
    if wait_seconds > 0:
        time.sleep(wait_seconds)

    try:
        page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass

    save_debug_html_if_needed(page, config, final_url)

    try:
        body_text = page.locator("body").inner_text(timeout=5000)
    except Exception:
        body_text = ""

    body_text = compact_text(body_text) or ""
    final_url = page.url or final_url

    status_evidence = extract_status_evidence(page, final_url, body_text) if bool(config.get("debug_status_evidence", True)) else {}
    status, reason = classify_status(final_url, body_text, status_evidence)

    title, price, source_note = choose_title_price(page, final_url, config, status_evidence)

    has_buy_evidence = bool(status_evidence.get("has_buy_action_for_target") or status_evidence.get("has_create_order_link_for_target"))
    has_chat_evidence = bool(status_evidence.get("has_chat_action_for_target"))
    has_available_action_evidence = has_buy_evidence or has_chat_evidence
    require_buy = bool(config.get("require_buy_button_for_normal", True))

    if price is not None and title is not None and status == STATUS_UNKNOWN:
        if require_buy and not has_available_action_evidence:
            reason = "识别到标题和价格，但未发现目标商品购买入口，暂不判定为正常；请查看 status_evidence"
        else:
            status = STATUS_NORMAL
            reason = "识别到首屏主商品标题和价格，暂定为正常在售"
            if has_buy_evidence:
                reason += "；页面存在目标商品购买入口"
            elif has_chat_evidence:
                reason += "；页面存在我想要/聊一聊入口"
            elif not require_buy:
                reason += "；未强制要求识别购买按钮"
            if source_note:
                reason += "；" + source_note
    elif status == STATUS_UNKNOWN and (price is not None or title is not None):
        # Only one field is not enough. v0.1.3 proved that this can be recommendation data.
        reason = "只识别到部分商品信息，暂不判定为正常；请查看 logs/last_round_debug.json 和 logs/debug_items/ 下对应商品的调试文件"
    elif status == STATUS_UNKNOWN and not body_text:
        status = STATUS_LOAD_FAILED
        reason = "页面正文为空，可能未加载完成"

    is_buyable: bool | None
    if status == STATUS_NORMAL and has_buy_evidence:
        is_buyable = True
        buyability_reason = "识别到目标商品立即购买/create-order 入口"
    elif status == STATUS_NORMAL and has_chat_evidence:
        is_buyable = True
        buyability_reason = "识别到目标商品我想要/聊一聊入口"
    elif status == STATUS_NORMAL and not require_buy:
        is_buyable = True
        buyability_reason = "识别到标题和价格，且未发现已售/下架/登录/验证证据；当前配置不强制要求购买按钮"
    elif status == STATUS_NORMAL and not has_available_action_evidence:
        is_buyable = None
        buyability_reason = "状态为 NORMAL，但没有识别到目标商品购买入口"
    else:
        is_buyable = False
        if has_available_action_evidence:
            buyability_reason = f"状态为 {status}，但页面仍存在购买入口，需人工核对"
        else:
            buyability_reason = f"状态为 {status}，未识别到目标商品购买入口"

    return ProductSnapshot(final_url, status, title, price, reason, captured_at, is_buyable, buyability_reason)


def print_snapshot(snapshot: ProductSnapshot, index: int | None = None, total: int | None = None) -> None:
    label = "MVP v0.6.2 单商品识别结果"
    if index is not None and total is not None:
        label = f"MVP v0.6.2 识别结果 [{index}/{total}]"
    print("\n" + "=" * 70)
    print(label)
    print("=" * 70)
    print(f"链接：{snapshot.url}")
    print(f"状态：{snapshot.status}")
    print(f"标题：{snapshot.title or '未识别'}")
    print(f"价格：{('¥' + str(snapshot.price)) if snapshot.price is not None else '未识别'}")
    if snapshot.is_buyable is True:
        buyable_text = "是"
    elif snapshot.is_buyable is False:
        buyable_text = "否"
    else:
        buyable_text = "未知"
    print(f"可购买：{buyable_text}")
    if snapshot.buyability_reason:
        print(f"可购买判断：{snapshot.buyability_reason}")
    print(f"原因：{snapshot.reason}")
    print(f"时间：{snapshot.captured_at}")
    print("=" * 70)

    if snapshot.status == STATUS_UNKNOWN:
        print("\n[提示] 页面结构没有稳定识别。请查看 logs/last_round_debug.json 和 logs/debug_items/ 下对应商品的调试文件。")
    elif snapshot.status == STATUS_LOGIN_REQUIRED:
        print("\n[提示] 登录状态可能失效。请运行 login.bat 重新登录。")
    elif snapshot.status == STATUS_VERIFY_REQUIRED:
        print("\n[提示] 检测到安全验证。请在可见浏览器中手动处理，不建议尝试绕过。")


def load_state() -> dict[str, Any]:
    ensure_dirs()
    if not STATE_FILE.exists():
        return {}
    try:
        value = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            return value
        raise ValueError("state.json root is not an object")
    except Exception as exc:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = DATA_DIR / f"state.broken.{stamp}.json"
        try:
            shutil.copy2(STATE_FILE, backup)
        except Exception:
            pass
        log(f"[警告] state.json 读取失败，已尝试备份为 {backup.name}，将使用空状态：{exc}")
        return {}


def save_state(state: dict[str, Any]) -> None:
    ensure_dirs()
    tmp = STATE_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STATE_FILE)


def append_history(event: dict[str, Any]) -> None:
    ensure_dirs()
    with HISTORY_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def safe_float(value: Any) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    try:
        if value is None:
            return None
        return float(value)
    except Exception:
        return None


def make_history_event(
    event_type: str,
    source_url: str,
    snapshot: ProductSnapshot,
    old: dict[str, Any] | None,
    old_price: float | None = None,
    new_price: float | None = None,
) -> dict[str, Any]:
    old = old or {}
    return {
        "time": snapshot.captured_at,
        "event": event_type,
        "url": source_url,
        "resolved_url": snapshot.url,
        "title": snapshot.title or old.get("title"),
        "old_price": old_price if old_price is not None else old.get("price"),
        "new_price": new_price if new_price is not None else snapshot.price,
        "old_status": old.get("status"),
        "new_status": snapshot.status,
        "reason": snapshot.reason,
    }


_NETWORK_ALERTED_ROUNDS: set[int] = set()


def notify_network_problem(
    source_url: str,
    snapshot: ProductSnapshot,
    old: dict[str, Any] | None,
    entry: dict[str, Any],
    config: dict[str, Any],
    round_no: int | None = None,
) -> str | None:
    if not bool(config.get("notify_status_change", True)):
        return "检测到网络异常，但变化通知总开关已关闭"
    if not bool(config.get("notify_network_errors", True)):
        return "检测到网络异常，但网络异常通知已关闭"

    signature = compact_text(network_reason_label(snapshot.reason) + "|" + str(source_url)) or "NETWORK_ERROR"
    entry["last_network_error_at"] = snapshot.captured_at
    entry["last_network_error_reason"] = snapshot.reason

    if round_no is not None:
        try:
            entry["last_network_error_round_no"] = int(round_no)
        except Exception:
            entry["last_network_error_round_no"] = round_no
        if round_no in _NETWORK_ALERTED_ROUNDS:
            return "本轮已提醒过网络异常，不重复弹窗"

    if not bool(config.get("notify_network_errors_every_round", True)):
        old_signature = old.get("last_network_error_signature") if isinstance(old, dict) else None
        if old_signature == signature:
            return "仍是同一网络异常，不重复通知"

    event = make_history_event("NETWORK_ERROR", source_url, snapshot, old)
    event["network_error"] = True
    event["reason"] = snapshot.reason
    append_history(event)
    notify_history_event(event, config)
    entry["last_network_error_signature"] = signature
    if round_no is not None:
        _NETWORK_ALERTED_ROUNDS.add(int(round_no))

    write_runtime_status(
        phase=STATUS_NETWORK_ERROR,
        phase_label="网络异常",
        current_url=source_url,
        current_status=STATUS_NETWORK_ERROR,
        last_message=f"检测到网络异常：{network_reason_label(snapshot.reason)}",
        network_alert_active=True,
        last_network_error_at=snapshot.captured_at,
        last_network_error_ts=time.time(),
        last_network_error_reason=snapshot.reason,
    )
    return "检测到网络异常，已写入历史并尝试通知：NETWORK_ERROR"


def should_send_not_buyable_alert(snapshot: ProductSnapshot, config: dict[str, Any]) -> bool:
    """Return True for states that are not buyable and do not already have a dedicated alert."""
    if not bool(config.get("notify_not_buyable", True)):
        return False
    if snapshot.is_buyable is True:
        return False
    # These have their own explicit notifications, so do not duplicate them here.
    if snapshot.status in {STATUS_SOLD, STATUS_REMOVED, STATUS_LOGIN_REQUIRED, STATUS_VERIFY_REQUIRED}:
        return False
    if snapshot.status == STATUS_LOAD_FAILED and not bool(config.get("notify_not_buyable_for_load_failed", False)):
        return False
    return True


def maybe_notify_not_buyable(
    source_url: str,
    snapshot: ProductSnapshot,
    old: dict[str, Any] | None,
    entry: dict[str, Any],
    config: dict[str, Any],
) -> str | None:
    """Send a one-shot alert when the target item is not confirmed buyable."""
    if snapshot.is_buyable is True:
        entry["last_buyability"] = "BUYABLE"
        entry["last_not_buyable_notified_signature"] = None
        return None

    if not should_send_not_buyable_alert(snapshot, config):
        entry["last_buyability"] = "NOT_BUYABLE" if snapshot.is_buyable is False else "UNKNOWN"
        return None

    signature = compact_text(f"{snapshot.status}|{snapshot.reason}|{snapshot.buyability_reason}") or snapshot.status
    if len(signature) > 240:
        signature = signature[:240]

    old_signature = old.get("last_not_buyable_notified_signature") if isinstance(old, dict) else None
    is_first_seen = old is None or old.get("status") is None

    if is_first_seen and not bool(config.get("notify_not_buyable_on_first_seen", True)):
        entry["last_buyability"] = "NOT_BUYABLE"
        entry["last_not_buyable_notified_signature"] = signature
        return "首次发现不可购买/异常，但按配置不通知"

    if not bool(config.get("notify_not_buyable_every_round", False)) and old_signature == signature:
        entry["last_buyability"] = "NOT_BUYABLE"
        return "仍是同一不可购买/异常状态，不重复通知"

    event = make_history_event("NOT_BUYABLE", source_url, snapshot, old)
    event["buyability_reason"] = snapshot.buyability_reason
    append_history(event)
    notify_history_event(event, config)
    entry["last_buyability"] = "NOT_BUYABLE"
    entry["last_not_buyable_notified_signature"] = signature
    return "已写入不可购买/异常事件并尝试通知：NOT_BUYABLE"


TRUSTED_PRODUCT_STATUSES = {STATUS_NORMAL, STATUS_SOLD, STATUS_REMOVED}
META_PROBLEM_STATUSES = {STATUS_LOGIN_REQUIRED, STATUS_VERIFY_REQUIRED}
UNTRUSTED_FAILURE_STATUSES = {STATUS_LOAD_FAILED, STATUS_UNKNOWN}



def state_entry_quality_for_update(obj: dict[str, Any] | None) -> tuple[int, str]:
    if not isinstance(obj, dict):
        return (-1, "")
    status = str(obj.get("status") or "")
    score = 0
    if status in TRUSTED_PRODUCT_STATUSES:
        score += 100
    elif status in META_PROBLEM_STATUSES:
        score += 70
    elif status in UNTRUSTED_FAILURE_STATUSES or not status:
        score += 5
    else:
        score += 20
    if obj.get("title"):
        score += 25
    if obj.get("price") not in (None, ""):
        score += 20
    if str(obj.get("state_key") or "").startswith("item:"):
        score += 8
    if obj.get("last_error_status") and (status in UNTRUSTED_FAILURE_STATUSES or not status):
        score -= 15
    return (score, str(obj.get("last_checked") or obj.get("last_seen") or ""))


def find_best_previous_state_entry(
    state: dict[str, Any],
    state_key: str,
    source_url: str,
    resolved_url: str | None,
) -> tuple[str | None, dict[str, Any] | None]:
    """Find the best previous state for this source URL.

    A network outage before short-link redirect can create a transient entry
    under the original short URL. Later successful checks are stored under
    item:<id>. We need to prefer the real item entry when comparing and when
    displaying current state.
    """
    source_iid = get_item_id(source_url or "")
    resolved_iid = get_item_id(resolved_url or "")
    ids = {x for x in (source_iid, resolved_iid) if x}

    seen: set[str] = set()
    candidates: list[tuple[str, dict[str, Any]]] = []

    def add(k: Any, obj: Any) -> None:
        if not isinstance(k, str) or not isinstance(obj, dict) or k in seen:
            return
        seen.add(k)
        candidates.append((k, obj))

    add(state_key, state.get(state_key))
    add(source_url, state.get(source_url))
    add("url:" + source_url.strip(), state.get("url:" + source_url.strip()))

    for k, obj in state.items():
        if not isinstance(obj, dict):
            continue
        urls = [str(obj.get("url") or ""), str(obj.get("resolved_url") or "")]
        if source_url in urls or (resolved_url and resolved_url in urls):
            add(str(k), obj)
            continue
        if ids:
            id_sources = [str(k), *urls]
            if any(get_item_id(x) in ids for x in id_sources):
                add(str(k), obj)

    if not candidates:
        return None, None
    return max(candidates, key=lambda pair: state_entry_quality_for_update(pair[1]))


def cleanup_obsolete_source_state(state: dict[str, Any], source_url: str, active_key: str) -> None:
    """Remove stale short-link failure placeholders after a real item state exists."""
    for obsolete_key in {source_url, "url:" + source_url.strip()}:
        if obsolete_key and obsolete_key != active_key:
            old_obj = state.get(obsolete_key)
            if isinstance(old_obj, dict) and state_entry_quality_for_update(old_obj)[0] < 60:
                state.pop(obsolete_key, None)


def update_state_and_history(
    state: dict[str, Any],
    state_key: str,
    source_url: str,
    snapshot: ProductSnapshot,
    config: dict[str, Any],
    round_no: int | None = None,
) -> list[str]:
    """Update state.json data and append history.jsonl events when real changes happen.

    Important rule: LOAD_FAILED and UNKNOWN do not overwrite the last trusted title/price/status.
    This prevents network errors or selector failures from being treated as下架/降价.
    """
    messages: list[str] = []
    old_key, old = find_best_previous_state_entry(state, state_key, source_url, snapshot.url)

    # For transient network/selector failures, keep updating the best existing
    # product entry instead of creating or prioritizing a stale short-link
    # placeholder. For trusted snapshots, keep the canonical state_key
    # (usually item:<id>) but still compare against the best previous entry.
    if snapshot.status in UNTRUSTED_FAILURE_STATUSES and old_key:
        state_key = old_key

    previous_check_count = 0
    if isinstance(old, dict):
        try:
            previous_check_count = int(old.get("check_count") or old.get("total_checks") or 0)
        except Exception:
            previous_check_count = 0
    check_count = previous_check_count + 1
    first_checked = old.get("first_checked") if isinstance(old, dict) else None
    if not first_checked:
        first_checked = snapshot.captured_at

    if snapshot.status in UNTRUSTED_FAILURE_STATUSES:
        entry = dict(old or {"url": source_url})
        entry.setdefault("url", source_url)
        entry["state_key"] = state_key

        # Do not let a temporary outage replace a known good title/price/status.
        # Keep the previous resolved item URL unless the failed snapshot still
        # contains a useful item id.
        if get_item_id(snapshot.url) or not entry.get("resolved_url"):
            entry["resolved_url"] = snapshot.url
        entry["last_checked"] = snapshot.captured_at
        entry["check_count"] = check_count
        entry["last_round_no"] = round_no
        entry["first_checked"] = first_checked
        entry["last_error_status"] = snapshot.status
        entry["last_error_reason"] = snapshot.reason
        if not (old and str(old.get("status") or "") in TRUSTED_PRODUCT_STATUSES):
            entry["is_buyable"] = snapshot.is_buyable
            entry["buyability_reason"] = snapshot.buyability_reason
        else:
            entry["is_buyable"] = old.get("is_buyable")
            entry["buyability_reason"] = old.get("buyability_reason")
        entry["failure_count"] = int(entry.get("failure_count") or 0) + 1
        if is_network_problem_snapshot(snapshot):
            net_msg = notify_network_problem(source_url, snapshot, old, entry, config, round_no=round_no)
            if net_msg:
                messages.append(net_msg)
        nb_msg = maybe_notify_not_buyable(source_url, snapshot, old, entry, config)
        if nb_msg:
            messages.append(nb_msg)
        state[state_key] = entry
        cleanup_obsolete_source_state(state, source_url, state_key)

        threshold = int(config.get("max_failures_before_alert", 3))
        if entry["failure_count"] >= threshold:
            messages.append(f"连续失败 {entry['failure_count']} 次：{source_url}")
            if entry["failure_count"] == threshold:
                notify_failure_threshold(source_url, entry, config)
        else:
            messages.append(f"本次未更新状态：{snapshot.status}，失败计数 {entry['failure_count']}")
        return messages

    if snapshot.status in META_PROBLEM_STATUSES:
        entry = dict(old or {"url": source_url})
        entry.setdefault("url", source_url)
        entry["state_key"] = state_key
        entry["resolved_url"] = snapshot.url
        entry["last_checked"] = snapshot.captured_at
        entry["check_count"] = check_count
        entry["last_round_no"] = round_no
        entry["first_checked"] = first_checked
        entry["last_error_status"] = snapshot.status
        entry["last_error_reason"] = snapshot.reason
        entry["is_buyable"] = snapshot.is_buyable
        entry["buyability_reason"] = snapshot.buyability_reason
        entry["failure_count"] = int(entry.get("failure_count") or 0) + 1

        # Avoid writing the same LOGIN_REQUIRED/VERIFY_REQUIRED event every round.
        if old is None or old.get("last_error_status") != snapshot.status:
            event = make_history_event(snapshot.status, source_url, snapshot, old)
            append_history(event)
            notify_history_event(event, config)
            messages.append(f"已写入历史事件并尝试通知：{snapshot.status}")
        else:
            messages.append(f"仍然是 {snapshot.status}，不重复写入历史")
        nb_msg = maybe_notify_not_buyable(source_url, snapshot, old, entry, config)
        if nb_msg:
            messages.append(nb_msg)
        state[state_key] = entry
        return messages

    # Trusted product status.
    old_price = safe_float(old.get("price")) if old else None
    new_price = snapshot.price
    old_title = old.get("title") if old else None
    old_status = old.get("status") if old else None
    events: list[dict[str, Any]] = []

    if old is None or old_status not in TRUSTED_PRODUCT_STATUSES:
        messages.append("首次建立可信商品状态，不写入变化历史")
        last_changed = snapshot.captured_at
    else:
        last_changed = str(old.get("last_changed") or snapshot.captured_at)

        if old_status != snapshot.status:
            if snapshot.status == STATUS_SOLD:
                events.append(make_history_event("SOLD", source_url, snapshot, old))
            elif snapshot.status == STATUS_REMOVED:
                events.append(make_history_event("REMOVED", source_url, snapshot, old))
            elif old_status in {STATUS_SOLD, STATUS_REMOVED} and snapshot.status == STATUS_NORMAL:
                events.append(make_history_event("RECOVERED", source_url, snapshot, old))
            else:
                events.append(make_history_event("STATUS_CHANGED", source_url, snapshot, old))

        if snapshot.status == STATUS_NORMAL and old_status == STATUS_NORMAL:
            if old_price is not None and new_price is not None:
                if new_price < old_price:
                    events.append(make_history_event("PRICE_DOWN", source_url, snapshot, old, old_price, new_price))
                elif new_price > old_price:
                    events.append(make_history_event("PRICE_UP", source_url, snapshot, old, old_price, new_price))

            if old_title and snapshot.title and old_title != snapshot.title:
                events.append(make_history_event("TITLE_CHANGED", source_url, snapshot, old))

        if events:
            last_changed = snapshot.captured_at
            for event in events:
                append_history(event)
                notify_history_event(event, config)
                messages.append(f"已写入历史事件并尝试通知：{event['event']}")
        else:
            messages.append("与上次可信状态相比无变化")

    entry = dict(old or {})
    entry.update(
        {
            "state_key": state_key,
            "url": source_url,
            "resolved_url": snapshot.url,
            "title": snapshot.title if snapshot.title is not None else (old.get("title") if old else None),
            "price": snapshot.price if snapshot.price is not None else (old.get("price") if old else None),
            "status": snapshot.status,
            "last_seen": snapshot.captured_at,
            "last_checked": snapshot.captured_at,
            "last_changed": last_changed,
            "check_count": check_count,
            "last_round_no": round_no,
            "first_checked": first_checked,
            "failure_count": 0,
            "last_error_status": None,
            "last_error_reason": None,
            "is_buyable": snapshot.is_buyable,
            "buyability_reason": snapshot.buyability_reason,
        }
    )
    nb_msg = maybe_notify_not_buyable(source_url, snapshot, old, entry, config)
    if nb_msg:
        messages.append(nb_msg)
    state[state_key] = entry
    cleanup_obsolete_source_state(state, source_url, state_key)
    return messages


def sleep_random_seconds(
    min_seconds: float,
    max_seconds: float,
    label: str,
    *,
    phase: str = "DELAY",
    phase_label: str | None = None,
    interrupt_on_immediate_round: bool = False,
    **runtime_fields: Any,
) -> None:
    min_seconds = max(0.0, float(min_seconds))
    max_seconds = max(min_seconds, float(max_seconds))
    seconds = random.uniform(min_seconds, max_seconds)
    if seconds <= 0:
        return

    total = int(round(seconds))
    if total <= 0:
        total = 1
    log(f"等待 {seconds:.1f} 秒：{label}")

    end_at = time.time() + seconds
    delay_until_at = datetime.fromtimestamp(end_at).strftime("%Y-%m-%d %H:%M:%S")
    while True:
        remaining = max(0.0, end_at - time.time())
        remaining_int = int(round(remaining))
        extra_fields = dict(runtime_fields)
        extra_fields.update({
            "delay_until_at": delay_until_at,
            "delay_until_ts": end_at,
        })
        if phase == "ROUND_DELAY":
            extra_fields.update({
                "next_round_at": delay_until_at,
                "next_round_at_ts": end_at,
                "next_round_remaining_seconds": remaining_int,
            })
        write_runtime_status(
            phase=phase,
            phase_label=phase_label or label,
            last_message=f"{label}，剩余约 {remaining_int} 秒",
            delay_seconds=round(seconds, 1),
            delay_remaining_seconds=remaining_int,
            **extra_fields,
        )
        if interrupt_on_immediate_round and has_immediate_round_request():
            consume_immediate_round_request("收到网页立即检测请求，提前结束下一轮等待。")
            write_runtime_status(
                phase=phase,
                phase_label="收到立即检测请求",
                last_message="收到立即检测请求，马上开始下一轮。",
                delay_seconds=round(seconds, 1),
                delay_remaining_seconds=0,
                **extra_fields,
            )
            break
        if has_stop_request():
            write_runtime_status(
                phase=phase,
                phase_label="收到停止请求",
                last_message="收到停止请求，正在安全退出。",
                delay_seconds=round(seconds, 1),
                delay_remaining_seconds=0,
                **extra_fields,
            )
            break
        if remaining <= 0:
            break
        time.sleep(min(1.0, remaining))


def print_round_summary(round_no: int, snapshots: list[ProductSnapshot]) -> None:
    print("\n" + "#" * 70)
    print(f"第 {round_no} 轮完成，共检查 {len(snapshots)} 个链接")
    print("#" * 70)
    for i, snap in enumerate(snapshots, start=1):
        price = f"¥{snap.price}" if snap.price is not None else "未识别"
        title = snap.title or "未识别"
        if len(title) > 36:
            title = title[:36] + "…"
        if snap.is_buyable is True:
            buyable_mark = "可购买"
        elif snap.is_buyable is False:
            buyable_mark = "不可购买/异常"
        else:
            buyable_mark = "可购买未知"
        print(f"{i}. {snap.status:<16} {price:<12} {buyable_mark:<12} {title}")
    print("#" * 70)


def notify_round_complete(round_no: int, snapshots: list[ProductSnapshot], config: dict[str, Any]) -> None:
    config = refresh_notification_config(config)
    if not bool(config.get("notify_round_complete", True)):
        return
    total = len(snapshots)
    buyable_count = sum(1 for s in snapshots if s.is_buyable is True)
    not_buyable_count = sum(1 for s in snapshots if s.is_buyable is False)
    unknown_count = total - buyable_count - not_buyable_count
    status_counts: dict[str, int] = {}
    for snap in snapshots:
        status_counts[snap.status] = status_counts.get(snap.status, 0) + 1

    status_part = "，".join(f"{k}:{v}" for k, v in sorted(status_counts.items()))
    title = f"闲鱼监测完成：第 {round_no} 轮"
    message = f"共{total}个；可购买{buyable_count}；不可购买/异常{not_buyable_count}；未知{unknown_count}"
    if status_part:
        message += f"；{status_part}"

    abnormal = [s for s in snapshots if s.is_buyable is False]
    if abnormal:
        names = []
        for snap in abnormal[:2]:
            names.append(f"{snap.status}:{shorten_for_notify(snap.title, 22)}")
        message += "；" + " / ".join(names)
        if len(abnormal) > 2:
            message += f" 等{len(abnormal)}个"

    ok = send_windows_notification(title, message, None, config)
    if not ok:
        print(f"[通知未弹出] {title} - {message}")


def write_last_round_debug(round_no: int, snapshots: list[ProductSnapshot], source_urls: list[str], config: dict[str, Any]) -> None:
    if not bool(config.get("save_last_round_debug", True)):
        return
    try:
        items = []
        for i, snap in enumerate(snapshots):
            source_url = source_urls[i] if i < len(source_urls) else snap.url
            per_html, per_json = debug_paths_for_url(snap.url)
            items.append({
                "index": i + 1,
                "state_key": make_state_key(source_url, snap.url),
                "source_url": source_url,
                "resolved_url": snap.url,
                "status": snap.status,
                "title": snap.title,
                "price": snap.price,
                "is_buyable": snap.is_buyable,
                "buyability_reason": snap.buyability_reason,
                "reason": snap.reason,
                "captured_at": snap.captured_at,
                "debug_html": str(per_html.relative_to(ROOT)) if per_html.exists() else None,
                "debug_json": str(per_json.relative_to(ROOT)) if per_json.exists() else None,
            })
        payload = {
            "round_no": round_no,
            "written_at": now_str(),
            "count": len(items),
            "items": items,
            "note": "round_no is now a persistent global counter. last_page_debug.html / last_candidates_debug.json only show the last item. Use this file or logs/debug_items/ for per-link debugging.",
        }
        LAST_ROUND_DEBUG.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        log(f"[警告] 保存本轮汇总调试 JSON 失败：{exc}")


def validate_links(raw_links: list[str]) -> tuple[list[str], list[tuple[str, str]]]:
    valid: list[str] = []
    invalid: list[tuple[str, str]] = []
    for url in raw_links:
        ok, reason = validate_url(url)
        if ok:
            valid.append(url)
        else:
            invalid.append((url, reason))
    return valid, invalid


def run_one_round(round_no: int, browser, config: dict[str, Any], state: dict[str, Any]) -> tuple[list[ProductSnapshot], bool]:
    raw_links = read_links()
    valid_links, invalid_links = validate_links(raw_links)

    write_runtime_status(
        running=True,
        round_no=round_no,
        phase="ROUND_START",
        phase_label="本轮开始",
        total=len(valid_links),
        current_index=0,
        current_url="",
        current_item_id="",
        last_message=f"第 {round_no} 轮开始：有效 {len(valid_links)} 条，无效 {len(invalid_links)} 条",
        delay_seconds=0,
        delay_remaining_seconds=0,
    )
    log(f"第 {round_no} 轮开始：读取到 {len(raw_links)} 条链接，有效 {len(valid_links)} 条，无效 {len(invalid_links)} 条")
    for bad_url, reason in invalid_links:
        log(f"[警告] 跳过无效链接：{bad_url}；原因：{reason}")

    if not valid_links:
        write_runtime_status(
            phase="NO_LINKS",
            phase_label="没有有效链接",
            last_message="links.txt 中没有有效链接；后台监控会继续等待，添加链接后可点“立即检测一轮”。",
            total=0,
            current_index=0,
            delay_seconds=0,
            delay_remaining_seconds=0,
        )
        log("[提醒] links.txt 中没有有效链接；长期监控保持运行，等待添加链接或手动触发。")
        return [], True

    context = browser.new_context(
        storage_state=str(AUTH_STATE),
        locale="zh-CN",
        viewport={"width": 1280, "height": 900},
    )

    snapshots: list[ProductSnapshot] = []
    source_urls_seen: list[str] = []
    should_stop = False
    try:
        login_check = check_login_before_round(context, config, round_no)
        log(f"登录前置检查：{login_check.status}；{login_check.reason}；{login_check.final_url}")
        if not login_check.ok:
            notify_auth_problem(login_check.status, login_check.reason, login_check.final_url, config)
            write_runtime_status(
                running=False,
                round_no=round_no,
                phase=login_check.status,
                phase_label=auth_phase_label(login_check.status),
                network_alert_active=(login_check.status == STATUS_NETWORK_ERROR),
                last_network_error_at=now_str() if login_check.status == STATUS_NETWORK_ERROR else _RUNTIME_STATUS.get("last_network_error_at"),
                last_network_error_ts=time.time() if login_check.status == STATUS_NETWORK_ERROR else _RUNTIME_STATUS.get("last_network_error_ts", 0),
                last_network_error_reason=login_check.reason if login_check.status == STATUS_NETWORK_ERROR else _RUNTIME_STATUS.get("last_network_error_reason", ""),
                current_index=0,
                total=len(valid_links),
                current_url=login_check.final_url,
                last_message=f"{auth_phase_label(login_check.status)}：{login_check.reason}",
                exit_code=2,
                delay_seconds=0,
                delay_remaining_seconds=0,
                finished_at=now_str(),
            )
            return [], False

        page = context.new_page()
        page.set_default_timeout(int(config["page_timeout_ms"]))
        for index, url in enumerate(valid_links, start=1):
            write_runtime_status(
                running=True,
                round_no=round_no,
                phase="ITEM_START",
                phase_label="正在打开商品页面",
                current_index=index,
                total=len(valid_links),
                current_url=url,
                current_item_id=get_item_id(url) or "",
                last_message=f"正在检查第 {index}/{len(valid_links)} 个商品",
                delay_seconds=0,
                delay_remaining_seconds=0,
            )
            log(f"[{index}/{len(valid_links)}] 检查链接：{url}")
            if "m.tb.cn" in url.lower() or "tb.cn" in url.lower():
                log("检测到淘宝/闲鱼短链，将由浏览器自动跳转到最终商品页。")

            write_runtime_status(
                running=True,
                round_no=round_no,
                phase="ITEM_LOADING",
                phase_label="页面加载与信息提取中",
                current_index=index,
                total=len(valid_links),
                current_url=url,
                current_item_id=get_item_id(url) or "",
                last_message=f"第 {index}/{len(valid_links)} 个商品正在加载/提取",
            )
            snapshot = inspect_product_page(page, url, config)
            write_runtime_status(
                running=True,
                round_no=round_no,
                phase="ITEM_DONE",
                phase_label="当前商品检查完成",
                current_index=index,
                total=len(valid_links),
                current_url=snapshot.url,
                current_item_id=get_item_id(snapshot.url) or get_item_id(url) or "",
                current_status=snapshot.status,
                current_title=snapshot.title or "",
                current_price=snapshot.price,
                last_message=f"第 {index}/{len(valid_links)} 个商品完成：{snapshot.status}",
                delay_seconds=0,
                delay_remaining_seconds=0,
            )
            snapshots.append(snapshot)
            source_urls_seen.append(url)
            print_snapshot(snapshot, index, len(valid_links))
            log("识别结果：" + json.dumps(asdict(snapshot), ensure_ascii=False))

            state_key = make_state_key(url, snapshot.url)
            log(f"状态键：{state_key}")
            messages = update_state_and_history(state, state_key, url, snapshot, config, round_no=round_no)
            for message in messages:
                log(f"状态处理：{message}")
            save_state(state)

            if has_stop_request():
                consume_stop_request("收到停止请求，已完成当前商品保存后安全退出。")
                should_stop = True
                log("收到停止请求：当前商品状态已保存，本轮不再继续访问后续商品。")
                write_runtime_status(
                    running=False,
                    round_no=round_no,
                    phase="STOPPED_BY_USER",
                    phase_label="用户已停止",
                    current_index=index,
                    total=len(valid_links),
                    current_url=snapshot.url,
                    current_item_id=get_item_id(snapshot.url) or get_item_id(url) or "",
                    current_status=snapshot.status,
                    current_title=snapshot.title or "",
                    current_price=snapshot.price,
                    last_message="已在当前商品保存完成后安全停止，避免留下未识别状态。",
                    exit_code=0,
                    delay_seconds=0,
                    delay_remaining_seconds=0,
                    finished_at=now_str(),
                )
                break

            if snapshot.status in {STATUS_LOGIN_REQUIRED, STATUS_VERIFY_REQUIRED}:
                should_stop = True
                log(f"检测到 {snapshot.status}，本轮停止继续访问，避免增加风险。")
                write_runtime_status(
                    running=False,
                    round_no=round_no,
                    phase=snapshot.status,
                    phase_label=auth_phase_label(snapshot.status),
                    current_index=index,
                    total=len(valid_links),
                    current_url=snapshot.url,
                    current_item_id=get_item_id(snapshot.url) or get_item_id(url) or "",
                    current_status=snapshot.status,
                    current_title=snapshot.title or "",
                    current_price=snapshot.price,
                    last_message=f"{auth_phase_label(snapshot.status)}：{snapshot.reason}",
                    exit_code=2,
                    delay_seconds=0,
                    delay_remaining_seconds=0,
                    finished_at=now_str(),
                )
                break

            if index < len(valid_links):
                sleep_random_seconds(
                    float(config.get("per_item_delay_min_seconds", 3)),
                    float(config.get("per_item_delay_max_seconds", 8)),
                    "单商品间隔",
                    phase="ITEM_DELAY",
                    phase_label="正在等待下一个商品",
                    round_no=round_no,
                    current_index=index,
                    total=len(valid_links),
                    current_url=snapshot.url,
                    current_item_id=get_item_id(snapshot.url) or get_item_id(url) or "",
                )
    finally:
        context.close()

    if should_stop:
        print_round_summary(round_no, snapshots)
        write_last_round_debug(round_no, snapshots, source_urls_seen, config)
        return snapshots, False

    write_runtime_status(
        running=True,
        round_no=round_no,
        phase="ROUND_DONE",
        phase_label="本轮检查完成",
        current_index=len(snapshots),
        total=len(valid_links),
        last_message=f"第 {round_no} 轮完成，共检查 {len(snapshots)} 个商品",
        delay_seconds=0,
        delay_remaining_seconds=0,
    )
    print_round_summary(round_no, snapshots)
    write_last_round_debug(round_no, snapshots, source_urls_seen, config)
    notify_round_complete(round_no, snapshots, config)
    return snapshots, not should_stop


def main() -> int:
    ensure_dirs()
    config = load_config()
    run_once = bool(config.get("run_once", False)) or ("--once" in sys.argv)
    mode_label = "once" if run_once else "loop"

    log(f"启动 monitor.py {PROGRAM_VERSION}")

    if not acquire_monitor_lock():
        return 3

    exit_code = 0
    try:
        write_runtime_status(
            running=True,
            mode=mode_label,
            phase="STARTING",
            phase_label="启动中",
            current_index=0,
            total=0,
            last_message="监控进程启动中",
            started_at=now_str(),
            delay_seconds=0,
            delay_remaining_seconds=0,
        )

        if not AUTH_STATE.exists():
            exit_code = 1
            log("[错误] 未找到 data/auth_state.json。请先运行 login.bat。")
            write_runtime_status(phase="ERROR", phase_label="缺少登录态", last_message="未找到 data/auth_state.json，请先运行 login.bat")
            return exit_code

        state = load_state()
        state, migrated = migrate_state_keys(state)
        if migrated:
            save_state(state)
            log("已将旧版 state.json 的完整链接键迁移为稳定 item:<商品ID> 键。")

        log(f"已加载历史状态基准：{len(state)} 个商品；历史事件：{history_line_count()} 条。")
        if not state:
            log("[提醒] 当前 data/state.json 没有历史基准。本次将先建立基准；如果你刚升级版本，请确认已复制旧版 data 文件夹。")

        run_meta = load_run_meta()
        total_round_no = int(run_meta.get("total_rounds") or 0)
        run_meta["last_started_at"] = now_str()
        run_meta["program_version"] = PROGRAM_VERSION
        run_meta["state_items_at_start"] = len(state)
        save_run_meta(run_meta)

        browser_restart_every_rounds = max(1, int(config.get("browser_restart_every_rounds", 10)))
        session_round_no = 0

        with sync_playwright() as p:
            current_headless = bool(config.get("headless", True))
            browser = launch_monitor_browser(p, config)
            try:
                while True:
                    # Reload config before each round so dashboard switches can take
                    # effect without restarting the whole web panel.  If the user
                    # changes headless mode, restart only the Playwright browser.
                    latest_config = load_config()
                    latest_headless = bool(latest_config.get("headless", True))
                    browser_restart_every_rounds = max(1, int(latest_config.get("browser_restart_every_rounds", 10)))
                    if latest_headless != current_headless:
                        mode_text = "后台静默检测" if latest_headless else "真实浏览器检测"
                        write_runtime_status(phase="BROWSER_RESTART", phase_label="正在切换浏览器模式", last_message=f"正在切换为{mode_text}")
                        log(f"检测到浏览器显示设置变化，正在切换为{mode_text}。")
                        try:
                            browser.close()
                        except Exception:
                            pass
                        browser = launch_monitor_browser(p, latest_config)
                        current_headless = latest_headless
                    config = latest_config

                    session_round_no += 1
                    total_round_no += 1
                    write_runtime_status(
                        running=True,
                        mode=mode_label,
                        round_no=total_round_no,
                        session_round_no=session_round_no,
                        phase="ROUND_PREPARE",
                        phase_label="准备执行本轮",
                        current_index=0,
                        total=0,
                        last_message=f"准备执行历史总第 {total_round_no} 轮",
                        delay_seconds=0,
                        delay_remaining_seconds=0,
                    )
                    log(f"准备执行历史总第 {total_round_no} 轮（本次启动第 {session_round_no} 轮）。")
                    snapshots, can_continue = run_one_round(total_round_no, browser, config, state)
                    save_state(state)

                    run_meta["total_rounds"] = total_round_no
                    run_meta["last_session_round_no"] = session_round_no
                    run_meta["last_finished_at"] = now_str()
                    run_meta["state_items_after_round"] = len(state)
                    run_meta["last_round_item_count"] = len(snapshots)
                    save_run_meta(run_meta)

                    if not can_continue:
                        # STOPPED_BY_USER is a normal safe stop requested by the dashboard,
                        # not an authentication/error stop.
                        exit_code = 0 if str(_RUNTIME_STATUS.get("phase") or "") == "STOPPED_BY_USER" else 2
                        return exit_code
                    if not snapshots and run_once:
                        exit_code = 1
                        return exit_code
                    if run_once:
                        log("run_once=true，本次运行结束。")
                        exit_code = 0
                        return exit_code

                    if consume_immediate_round_request("收到网页立即检测请求，本轮结束后立即开始下一轮。"):
                        write_runtime_status(
                            running=True,
                            mode=mode_label,
                            round_no=total_round_no,
                            session_round_no=session_round_no,
                            phase="MANUAL_TRIGGER",
                            phase_label="手动触发下一轮",
                            current_index=0,
                            total=0,
                            last_message="手动检测请求已生效，马上开始下一轮。",
                            delay_seconds=0,
                            delay_remaining_seconds=0,
                        )
                        continue

                    if session_round_no % browser_restart_every_rounds == 0:
                        write_runtime_status(phase="BROWSER_RESTART", phase_label="正在重启浏览器", last_message="按配置重启浏览器，降低长期运行累积问题")
                        log("按配置重启浏览器，降低长期运行累积问题。")
                        browser.close()
                        current_headless = bool(config.get("headless", True))
                        browser = launch_monitor_browser(p, config)

                    if has_stop_request():
                        consume_stop_request("收到停止请求，本轮完成后退出长期监控。")
                        write_runtime_status(
                            running=False,
                            mode=mode_label,
                            round_no=total_round_no,
                            session_round_no=session_round_no,
                            phase="STOPPED_BY_USER",
                            phase_label="用户已停止",
                            current_index=len(snapshots),
                            total=len(snapshots),
                            last_message="本轮已完成，长期监控已安全停止。",
                            exit_code=0,
                            delay_seconds=0,
                            delay_remaining_seconds=0,
                            finished_at=now_str(),
                        )
                        exit_code = 0
                        return exit_code

                    sleep_random_seconds(
                        float(config.get("interval_min_seconds", 300)),
                        float(config.get("interval_max_seconds", 480)),
                        "下一轮轮询间隔",
                        phase="ROUND_DELAY",
                        phase_label="正在等待下一轮",
                        interrupt_on_immediate_round=True,
                        mode=mode_label,
                        round_no=total_round_no,
                        session_round_no=session_round_no,
                        current_index=0,
                        total=0,
                    )
                    if has_stop_request():
                        consume_stop_request("收到停止请求，已在下一轮等待阶段安全退出。")
                        write_runtime_status(
                            running=False,
                            mode=mode_label,
                            round_no=total_round_no,
                            session_round_no=session_round_no,
                            phase="STOPPED_BY_USER",
                            phase_label="用户已停止",
                            current_index=0,
                            total=0,
                            last_message="已在下一轮等待阶段安全停止。",
                            exit_code=0,
                            delay_seconds=0,
                            delay_remaining_seconds=0,
                            next_round_remaining_seconds=0,
                            finished_at=now_str(),
                        )
                        exit_code = 0
                        return exit_code
            finally:
                try:
                    browser.close()
                except Exception:
                    pass
    except KeyboardInterrupt:
        exit_code = 130
        write_runtime_status(
            running=False,
            phase="STOPPED_BY_USER",
            phase_label="用户已停止",
            last_message="监控进程已被用户中断",
            exit_code=exit_code,
            delay_seconds=0,
            delay_remaining_seconds=0,
            finished_at=now_str(),
        )
        raise
    except Exception as exc:
        exit_code = 1
        write_runtime_status(
            running=False,
            phase="ERROR",
            phase_label="运行出错",
            last_message=f"监控进程出错：{exc}",
            exit_code=exit_code,
            error_type=type(exc).__name__,
            error=repr(exc),
            delay_seconds=0,
            delay_remaining_seconds=0,
            finished_at=now_str(),
        )
        raise
    finally:
        # Do not overwrite explicit ERROR / STOPPED_BY_USER status with a generic idle message.
        if _RUNTIME_STATUS.get("phase") not in {"ERROR", "STOPPED_BY_USER", STATUS_LOGIN_REQUIRED, STATUS_VERIFY_REQUIRED, STATUS_NETWORK_ERROR}:
            clear_runtime_status(exit_code=exit_code, message="监控进程已停止" if exit_code == 0 else f"监控进程已停止，退出码 {exit_code}")
        release_monitor_lock()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[已取消] 用户中断。")
        raise SystemExit(130)
    except Exception as exc:
        log(f"[错误] monitor.py 运行失败：{exc}")
        raise SystemExit(1)
