from __future__ import annotations


def configure_console_utf8() -> None:
    """Prevent Windows GBK console/log redirection from crashing on Unicode text."""
    import os
    import sys
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


configure_console_utf8()


import platform
import sys


def main() -> int:
    if platform.system().lower() != "windows":
        print("[SKIP] This notification test only works on Windows.")
        return 0

    try:
        from winotify import Notification, audio
    except Exception as exc:
        print(f"[ERROR] winotify is not available: {exc}")
        print("Run install.bat again first.")
        return 1

    try:
        toast = Notification(
            app_id="xy-monitor",
            title="xy-monitor 通知测试",
            msg="如果你看到这条通知，说明 Windows Toast 通知可用。",
        )
        try:
            toast.set_audio(audio.Default, loop=False)
        except Exception:
            pass
        toast.add_actions(label="打开测试网页", launch="https://www.goofish.com/")
        toast.show()
        print("[OK] Notification sent. Check the lower-right notification area / action center.")
        return 0
    except Exception as exc:
        print(f"[ERROR] Failed to show notification: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
