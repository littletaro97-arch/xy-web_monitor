# -*- coding: utf-8 -*-
"""
xy-monitor link manager v0.6.2

This helper edits links.txt safely:
- paste Goofish links, m.tb.cn short links, share text, or item IDs
- normalize Goofish item links to https://www.goofish.com/item?id=<id>
- deduplicate by item ID when possible
- keep backups under logs/link_backups/
"""

from __future__ import annotations


def configure_console_utf8() -> None:
    """Prevent Windows GBK console/log redirection from crashing on Unicode text."""
    import os
    import sys
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


configure_console_utf8()


import argparse
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qs, urlsplit, urlunsplit


APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
LINKS_FILE = ROOT / "links.txt"
LOGS_DIR = ROOT / "logs"
BACKUP_DIR = LOGS_DIR / "link_backups"

URL_RE = re.compile(r"https?://[^\s，,。；;）)】》>\"'`]+", re.IGNORECASE)
ITEM_ID_RE = re.compile(r"(?:^|[?&/\s=])(?:id=)?(\d{10,20})(?:\D|$)")
TRAILING_PUNCT = " \t\r\n，,。；;！!？?）)]】》>\"'`"


def ensure_files() -> None:
    LOGS_DIR.mkdir(exist_ok=True)
    BACKUP_DIR.mkdir(exist_ok=True)
    if not LINKS_FILE.exists():
        LINKS_FILE.write_text(
            "# One Goofish / Xianyu item link per line.\n"
            "# You can manage this file with manage_links.bat.\n",
            encoding="utf-8",
        )


def read_raw_lines() -> list[str]:
    ensure_files()
    return LINKS_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()


def read_links() -> list[str]:
    links: list[str] = []
    for line in read_raw_lines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        links.append(stripped)
    return links


def extract_item_id(text: str) -> str | None:
    if not text:
        return None

    # Query parameter id=...
    try:
        parts = urlsplit(text)
        qs = parse_qs(parts.query)
        if "id" in qs and qs["id"]:
            value = qs["id"][0]
            if re.fullmatch(r"\d{10,20}", value):
                return value
    except Exception:
        pass

    # Common URL/text patterns
    patterns = [
        r"[?&]id=(\d{10,20})",
        r"/item[/?#].*?id=(\d{10,20})",
        r"/item/(\d{10,20})",
        r"\b(\d{10,20})\b",
    ]
    for pat in patterns:
        m = re.search(pat, text)
        if m:
            return m.group(1)
    return None


def clean_url(url: str) -> str:
    url = url.strip().strip(TRAILING_PUNCT)
    # Some share text may append invisible marks.
    url = url.replace("\u200b", "").replace("\ufeff", "")
    return url


def canonicalize_candidate(text: str) -> str | None:
    text = text.strip()
    if not text:
        return None

    url_match = URL_RE.search(text)
    if url_match:
        raw_url = clean_url(url_match.group(0))
        item_id = extract_item_id(raw_url)
        if item_id:
            return f"https://www.goofish.com/item?id={item_id}"

        try:
            parts = urlsplit(raw_url)
            # Preserve m.tb.cn short links because only the browser can resolve them reliably.
            if parts.netloc.lower().endswith("m.tb.cn"):
                return urlunsplit((parts.scheme, parts.netloc, parts.path, parts.query, ""))
            return urlunsplit((parts.scheme, parts.netloc, parts.path, parts.query, ""))
        except Exception:
            return raw_url

    # Accept bare item ID
    item_id = extract_item_id(text)
    if item_id:
        return f"https://www.goofish.com/item?id={item_id}"

    return None


def link_key(link: str) -> str:
    item_id = extract_item_id(link)
    if item_id:
        return f"item:{item_id}"
    return "url:" + link.strip()


def extract_links_from_text(text: str) -> list[str]:
    found: list[str] = []

    urls = URL_RE.findall(text)
    for url in urls:
        link = canonicalize_candidate(url)
        if link:
            found.append(link)

    # If no URL was found, still allow one or more bare item IDs.
    if not found:
        ids = re.findall(r"\b\d{10,20}\b", text)
        for item_id in ids:
            found.append(f"https://www.goofish.com/item?id={item_id}")

    # Preserve order while deduplicating within the pasted text.
    seen: set[str] = set()
    result: list[str] = []
    for link in found:
        key = link_key(link)
        if key not in seen:
            seen.add(key)
            result.append(link)
    return result


def backup_links_file() -> Path | None:
    ensure_files()
    if not LINKS_FILE.exists():
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = BACKUP_DIR / f"links_{ts}.txt"
    shutil.copy2(LINKS_FILE, dst)
    return dst


def write_links(links: list[str]) -> None:
    backup_links_file()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# xy-monitor links.txt",
        "# One item per line. You can use manage_links.bat to add/delete links.",
        f"# Last updated: {now}",
        "",
    ]
    lines.extend(links)
    lines.append("")
    LINKS_FILE.write_text("\n".join(lines), encoding="utf-8")


def add_links_from_text(text: str) -> tuple[list[str], list[str]]:
    existing = read_links()
    existing_by_key = {link_key(x): x for x in existing}

    candidates = extract_links_from_text(text)
    added: list[str] = []
    skipped: list[str] = []

    for link in candidates:
        key = link_key(link)
        if key in existing_by_key:
            skipped.append(link)
        else:
            existing.append(link)
            existing_by_key[key] = link
            added.append(link)

    if added:
        write_links(existing)

    return added, skipped


def print_links() -> None:
    links = read_links()
    print("\nCurrent monitored links:")
    if not links:
        print("  (empty)")
        return
    for i, link in enumerate(links, 1):
        item_id = extract_item_id(link)
        suffix = f"  [item {item_id}]" if item_id else ""
        print(f"  {i}. {link}{suffix}")


def prompt_multiline() -> str:
    print("\nPaste Goofish/Xianyu share text, short links, full links, or item IDs.")
    print("You may paste multiple lines. Press Enter on an empty line to finish.\n")
    chunks: list[str] = []
    while True:
        try:
            line = input("> ")
        except EOFError:
            break
        if not line.strip():
            break
        chunks.append(line)
    return "\n".join(chunks)


def quick_add() -> None:
    text = prompt_multiline()
    if not text.strip():
        print("No input.")
        return

    added, skipped = add_links_from_text(text)

    print("\nAdd result:")
    if added:
        print(f"  Added {len(added)} link(s):")
        for link in added:
            print(f"    + {link}")
    else:
        print("  Added 0 links.")

    if skipped:
        print(f"  Skipped duplicate {len(skipped)} link(s):")
        for link in skipped:
            print(f"    = {link}")

    if not added and not skipped:
        print("  No valid Goofish/Xianyu URL or item ID was detected.")


def delete_by_number() -> None:
    links = read_links()
    print_links()
    if not links:
        return

    raw = input("\nEnter number(s) to delete, for example 1 or 1,3,5. Empty to cancel: ").strip()
    if not raw:
        print("Cancelled.")
        return

    try:
        nums = sorted({int(x.strip()) for x in re.split(r"[,，\s]+", raw) if x.strip()}, reverse=True)
    except ValueError:
        print("Invalid number.")
        return

    bad = [n for n in nums if n < 1 or n > len(links)]
    if bad:
        print(f"Invalid index: {bad}")
        return

    removed = []
    for n in nums:
        removed.append(links.pop(n - 1))

    write_links(links)
    print("\nDeleted:")
    for link in removed:
        print(f"  - {link}")


def clear_links() -> None:
    links = read_links()
    if not links:
        print("links.txt is already empty.")
        return

    confirm = input(f"Clear all {len(links)} link(s)? Type YES to confirm: ").strip()
    if confirm != "YES":
        print("Cancelled.")
        return

    write_links([])
    print("All links cleared.")


def open_links_txt() -> None:
    ensure_files()
    try:
        if os.name == "nt":
            os.startfile(str(LINKS_FILE))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(LINKS_FILE)])
        print(f"Opened: {LINKS_FILE}")
    except Exception as exc:
        print(f"Could not open links.txt automatically: {exc}")
        print(f"File path: {LINKS_FILE}")


def menu() -> None:
    ensure_files()
    while True:
        print("\n" + "=" * 68)
        print("xy-monitor link manager v0.6.2")
        print("=" * 68)
        print("1. View current links")
        print("2. Add links by pasting share text / URL / item ID")
        print("3. Delete links by number")
        print("4. Clear all links")
        print("5. Open links.txt manually")
        print("0. Exit")
        choice = input("\nChoose: ").strip()

        if choice == "1":
            print_links()
        elif choice == "2":
            quick_add()
        elif choice == "3":
            delete_by_number()
        elif choice == "4":
            clear_links()
        elif choice == "5":
            open_links_txt()
        elif choice == "0":
            print("Bye.")
            return
        else:
            print("Unknown choice.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Manage xy-monitor links.txt")
    parser.add_argument("--add", action="store_true", help="quick add mode")
    parser.add_argument("--list", action="store_true", help="list links and exit")
    args = parser.parse_args()

    if args.list:
        print_links()
    elif args.add:
        quick_add()
    else:
        menu()


if __name__ == "__main__":
    main()
