# tools

这里存放低频使用的辅助工具。

- `add_links.bat`：只执行“添加链接”流程
- `test_notification.bat`：测试 Windows 通知

常用入口仍在项目根目录。
