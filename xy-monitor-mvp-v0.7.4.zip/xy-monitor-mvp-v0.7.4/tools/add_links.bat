@echo off
cd /d "%~dp0\.."

chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

where python >nul 2>nul
if %errorlevel%==0 (
    python -X utf8 app\link_manager.py --add
) else (
    py -3 -X utf8 app\link_manager.py --add
)

pause
