@echo off
setlocal
cd /d "%~dp0"

set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

chcp 65001 >nul

echo ============================================================
echo xy-monitor local web dashboard v0.7.4
echo ============================================================
echo This starts a local page at http://127.0.0.1:8765/
echo If the dashboard is already running, this will open the existing page.
echo Close this window to stop the dashboard.
echo.

set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
    echo [ERROR] Python was not found. Run install.bat first, or install Python and add it to PATH.
    pause
    exit /b 1
)

call %PYTHON_CMD% -X utf8 app\web_dashboard.py
if errorlevel 1 (
  echo.
  echo Dashboard failed. You can also try manually:
  echo py -3 app\web_dashboard.py
  echo.
  pause
)
