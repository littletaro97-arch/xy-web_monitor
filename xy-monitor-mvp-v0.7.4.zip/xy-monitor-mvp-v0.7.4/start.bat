@echo off
setlocal
cd /d "%~dp0"

set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

chcp 65001 >nul

echo ============================================================
echo xy-monitor v0.7.4
echo ============================================================
echo v0.7.4 起，dashboard.bat 仍是唯一推荐入口。
echo 这个 start.bat 会转到本地网页面板，并由网页自动启动长期监控。
echo.

call dashboard.bat
