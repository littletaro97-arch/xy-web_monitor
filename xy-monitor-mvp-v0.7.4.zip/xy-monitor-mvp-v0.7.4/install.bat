@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

chcp 65001 >nul

if not exist logs mkdir logs
if not exist data mkdir data
set "LOG_FILE=logs\install.log"

echo ===============================================
echo xy-monitor MVP v0.5.4 installer
echo ===============================================
echo This window should not close automatically.
echo If install fails, send logs\install.log to ChatGPT.
echo Current folder: %cd%
echo.

call :main > "%LOG_FILE%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

type "%LOG_FILE%"
echo.
if "%EXIT_CODE%"=="0" (
    echo [OK] Install finished. Next step: run login.bat
) else (
    echo [FAILED] Install failed.
    echo Please copy the error above or send logs\install.log.
)
echo.
pause
exit /b %EXIT_CODE%

:main
echo [INFO] Current folder: %cd%
echo [INFO] Checking Python...

set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo [ERROR] Python was not found.
    echo Install Python 3.10 or newer from python.org.
    echo IMPORTANT: during installation, check "Add python.exe to PATH".
    exit /b 1
)

echo [INFO] Python command: %PYTHON_CMD%
call %PYTHON_CMD% --version
if errorlevel 1 (
    echo [ERROR] Python exists but cannot run correctly.
    exit /b 1
)

echo.
echo [1/5] Checking pip...
call %PYTHON_CMD% -m pip --version
if errorlevel 1 (
    echo [WARN] pip is not available. Trying ensurepip...
    call %PYTHON_CMD% -m ensurepip --upgrade
    if errorlevel 1 (
        echo [ERROR] pip is not available and ensurepip failed.
        exit /b 1
    )
)

echo.
echo [2/5] Upgrading pip...
call %PYTHON_CMD% -m pip install --upgrade pip
if errorlevel 1 (
    echo [ERROR] Failed to upgrade pip.
    echo Possible reasons: network issue, permission issue, Python environment issue.
    exit /b 1
)

echo.
echo [3/5] Installing Python packages...
if not exist requirements.txt (
    echo [ERROR] requirements.txt was not found.
    echo Please extract the whole zip first. Do not run install.bat inside the zip preview window.
    exit /b 1
)
call %PYTHON_CMD% -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install packages from requirements.txt.
    echo Possible reason: cannot connect to PyPI.
    exit /b 1
)

echo.
echo [4/5] Installing Playwright Chromium...
call %PYTHON_CMD% -m playwright install chromium
if errorlevel 1 (
    echo [ERROR] Failed to install Playwright Chromium.
    echo Possible reasons: download blocked, proxy issue, firewall issue, unstable network.
    exit /b 1
)

echo.
echo [5/5] Creating folders...
if not exist data mkdir data
if not exist logs mkdir logs

echo.
echo [SUCCESS] All dependencies installed.
exit /b 0
